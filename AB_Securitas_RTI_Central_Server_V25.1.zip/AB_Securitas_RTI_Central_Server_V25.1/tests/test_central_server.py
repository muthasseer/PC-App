"""Central Server regression tests for V25.1: bug fixes, health probe, dashboard pairing, mobile proxy."""
import atexit
import importlib.util
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
_TEST_ROOT = tempfile.TemporaryDirectory(prefix="ab-rti-v25-tests-")
atexit.register(_TEST_ROOT.cleanup)
os.environ.setdefault("RTI_DATA_DIR", str(Path(_TEST_ROOT.name) / "data"))
os.environ.setdefault("RTI_BACKUP_DIR", str(Path(_TEST_ROOT.name) / "backups"))
os.environ.setdefault("RTI_SECRET_KEY", "automated-v25-tests-only")
sys.path.insert(0, str(ROOT / "Web"))

import app as web  # noqa: E402


def _stamp(value):
    return value.strftime("%Y-%m-%d %H:%M:%S")


class CentralServerFixTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        c = web.conn()
        try:
            c.execute("UPDATE users SET must_change_password=0 WHERE username='admin'")
            now = _stamp(datetime.now())
            c.execute("INSERT INTO companies(name,code,status,created_at) VALUES(?,?,?,?)",
                      ("V25 Test Company", "V25-TEST", "ACTIVE", now))
            cls.company_id = c.execute("SELECT id FROM companies WHERE code='V25-TEST'").fetchone()["id"]
            expiry = (datetime.now() + timedelta(days=30)).isoformat(timespec="seconds")
            c.execute("INSERT INTO licenses(company_id,license_key,license_type,duration_days,status,issued_at,start_date,expiry_date) VALUES(?,?,?,?,?,?,?,?)",
                      (cls.company_id, "V25-LICENSE-KEY-0001", "TEST", 30, "ACTIVE", now, now, expiry))
            for code, qr in (("V25-01", "V25-QR-1"), ("V25-02", "V25-QR-2")):
                c.execute("INSERT INTO points(company_id,point_code,name,qr_token,status,created_at) VALUES(?,?,?,?,?,?)",
                          (cls.company_id, code, code + " name", qr, "ACTIVE", now))
            cls.point_ids = [r["id"] for r in c.execute("SELECT id FROM points WHERE company_id=? ORDER BY id", (cls.company_id,))]
            c.execute("INSERT INTO inspectors(company_id,employee_id,name,login_username,status,created_at) VALUES(?,?,?,?,?,?)",
                      (cls.company_id, "EMP-V25", "V25 Inspector", "v25.inspector", "ACTIVE", now))
            cls.inspector_id = c.execute("SELECT id FROM inspectors WHERE employee_id='EMP-V25'").fetchone()["id"]
            c.execute("INSERT INTO devices(company_id,device_id,device_identifier,status,access_policy,created_at) VALUES(?,?,?,?,?,?)",
                      (cls.company_id, "DEV-V25", "DEV-V25", "ACTIVE", "OPEN", now))
            c.execute("INSERT INTO mobile_sessions(token,user_id,inspector_id,company_id,device_id,created_at,last_seen,status) VALUES(?,?,?,?,?,?,?,?)",
                      ("v25-mobile-token", 1, cls.inspector_id, cls.company_id, "DEV-V25", now, now, "ACTIVE"))
            c.commit()
        finally:
            c.close()

    def setUp(self):
        self.client = web.app.test_client()

    def admin(self):
        client = web.app.test_client()
        with client.session_transaction() as session:
            session["user_id"] = 1
            session["_csrf_token"] = "v25-csrf"
        return client

    def test_health_probe_is_public_and_sets_no_cookie(self):
        response = self.client.get("/api/mobile/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["ok"])
        self.assertNotIn("Set-Cookie", response.headers)
        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")

    def test_version_is_v25(self):
        self.assertTrue(web.APP_VERSION.startswith("25."))

    def test_offline_captured_session_is_history_not_a_live_session(self):
        event = {
            "event_id": "evt-v25-offline-0001", "qr_token": "V25-QR-1", "device_id": "DEV-V25",
            "offline_session_key": "OFF-V25-SESSION-A", "client_created_at": "2026-10-20 10:00:00",
            "inspector_record_id": self.inspector_id, "offline_queue": True,
        }
        headers = {"Authorization": "Bearer v25-mobile-token"}
        response = self.client.post("/api/mobile/sync", json={"events": [event]}, headers=headers)
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        self.assertEqual(len(response.get_json()["accepted"]), 1, response.get_json())
        c = web.conn()
        try:
            row = c.execute("SELECT status,ended_at FROM inspection_sessions WHERE session_token='OFF-V25-SESSION-A'").fetchone()
        finally:
            c.close()
        self.assertEqual(row["status"], "ENDED")
        self.assertTrue(row["ended_at"])
        state = self.client.get("/api/mobile/state", headers=headers).get_json()
        self.assertTrue(state["ok"], state)
        self.assertFalse(state["inspection_active"])
        self.assertEqual(state["inspection_session_token"], "")

    def test_legacy_active_offline_session_is_hidden_from_mobile_state(self):
        c = web.conn()
        try:
            c.execute("INSERT INTO inspection_sessions(session_token,company_id,inspector_id,device_id,started_at,status) VALUES(?,?,?,?,?,?)",
                      ("OFF-LEGACY-STALE", self.company_id, self.inspector_id, "DEV-V25", "2026-10-01 08:00:00", "ACTIVE"))
            c.commit()
        finally:
            c.close()
        state = self.client.get("/api/mobile/state", headers={"Authorization": "Bearer v25-mobile-token"}).get_json()
        self.assertFalse(state["inspection_active"])

    def test_new_schedule_never_reports_missed_occurrences_from_before_it_existed(self):
        c = web.conn()
        try:
            now = _stamp(datetime.now())
            c.execute("""INSERT INTO schedules(company_id,name,schedule_time,days,grace_minutes,checkpoint_ids,enabled,created_at,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?)""",
                      (self.company_id, "Brand new patrol", "00:01", "MON,TUE,WED,THU,FRI,SAT,SUN", 15, "[]", 1, now, now))
            schedule_id = c.execute("SELECT id FROM schedules WHERE name='Brand new patrol'").fetchone()["id"]
            c.commit()
        finally:
            c.close()
        response = self.admin().get("/api/notifications")
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        c = web.conn()
        try:
            rows = c.execute("SELECT source_key FROM notifications WHERE source_key LIKE ?", (f"schedule:{schedule_id}:%",)).fetchall()
        finally:
            c.close()
        self.assertEqual([r["source_key"] for r in rows if r["source_key"].endswith(":MISSED")], [])

    def test_older_schedule_still_reports_a_missed_inspection(self):
        c = web.conn()
        try:
            created = _stamp(datetime.now() - timedelta(days=3))
            c.execute("""INSERT INTO schedules(company_id,name,schedule_time,days,grace_minutes,checkpoint_ids,enabled,created_at,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?)""",
                      (self.company_id, "Established patrol", "00:01", "MON,TUE,WED,THU,FRI,SAT,SUN", 15, "[]", 1, created, created))
            schedule_id = c.execute("SELECT id FROM schedules WHERE name='Established patrol'").fetchone()["id"]
            c.commit()
        finally:
            c.close()
        self.admin().get("/api/notifications")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        c = web.conn()
        try:
            row = c.execute("SELECT 1 FROM notifications WHERE source_key=?", (f"schedule:{schedule_id}:{yesterday}:MISSED",)).fetchone()
        finally:
            c.close()
        self.assertIsNotNone(row)

    def test_checkpoint_code_clash_returns_409_not_a_server_error(self):
        first, second = self.point_ids
        response = self.admin().put(f"/api/points/{second}", json={"point_code": "v25-01", "status": "ACTIVE"},
                                    headers={"X-CSRFToken": "v25-csrf"})
        self.assertEqual(response.status_code, 409, response.get_data(as_text=True))
        self.assertFalse(response.get_json()["ok"])
        ok = self.admin().put(f"/api/points/{first}", json={"point_code": "V25-01", "name": "Renamed", "status": "ACTIVE"},
                              headers={"X-CSRFToken": "v25-csrf"})
        self.assertEqual(ok.status_code, 200, ok.get_data(as_text=True))

    def test_checkpoint_update_rejects_non_string_code(self):
        response = self.admin().put(f"/api/points/{self.point_ids[1]}", json={"point_code": ["x"], "status": "ACTIVE"},
                                    headers={"X-CSRFToken": "v25-csrf"})
        self.assertIn(response.status_code, (200, 400, 409))
        self.assertNotEqual(response.status_code, 500)

    def test_dashboard_pairing_creates_working_credentials_and_persists_them(self):
        env_file = Path(_TEST_ROOT.name) / "central-pairing.env"
        env_file.write_text("RTI_SECRET_KEY=test\nRTI_CLIENT_SYNC_TOKENS=\n", encoding="utf-8")
        keys = ("RTI_ENV_FILE", "RTI_CLIENT_SYNC_TOKENS", "RTI_CLIENT_NODE_TOKENS")
        saved = {key: os.environ.get(key) for key in keys}
        try:
            os.environ["RTI_ENV_FILE"] = str(env_file)
            os.environ.pop("RTI_CLIENT_SYNC_TOKENS", None)
            os.environ.pop("RTI_CLIENT_NODE_TOKENS", None)
            admin = self.admin()
            bad = admin.post("/api/admin/client-pairing", json={"company_id": str(self.company_id), "client_id": "bad id!"},
                             headers={"X-CSRFToken": "v25-csrf"})
            self.assertEqual(bad.status_code, 400)
            public_http = admin.post("/api/admin/client-pairing", json={
                "company_id": str(self.company_id), "client_id": "CLIENT-V25-0001", "central_url": "http://example.com"},
                headers={"X-CSRFToken": "v25-csrf"})
            self.assertEqual(public_http.status_code, 400)
            response = admin.post("/api/admin/client-pairing", json={
                "company_id": str(self.company_id), "client_id": "CLIENT-V25-0001",
                "central_url": "https://rti.example.com", "central_lan_url": "http://192.168.1.10:5200"},
                headers={"X-CSRFToken": "v25-csrf"})
            self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
            self.assertEqual(response.headers["Cache-Control"], "no-store")
            pairing = response.get_json()["pairing"]
            self.assertEqual(pairing["format"], "rti-client-pairing-v1")
            self.assertEqual(pairing["central_lan_url"], "http://192.168.1.10:5200")
            self.assertGreaterEqual(len(pairing["client_sync_token"]), 32)
            text = env_file.read_text(encoding="utf-8")
            self.assertIn(pairing["client_sync_token"], text)
            self.assertIn(f"{self.company_id}/CLIENT-V25-0001:{pairing['client_node_token']}", text)
            # The new credentials work immediately, with no restart.
            node = self.client.get(f"/api/client/bootstrap?company_id={self.company_id}&client_id=CLIENT-V25-0001",
                                   headers={"Authorization": "Bearer " + pairing["client_node_token"]})
            self.assertEqual(node.status_code, 200, node.get_data(as_text=True))
            sync = self.client.get(f"/api/client/events?company_id={self.company_id}&after_id=0&limit=5",
                                   headers={"Authorization": "Bearer " + pairing["client_sync_token"]})
            self.assertEqual(sync.status_code, 200, sync.get_data(as_text=True))
            # A second pairing for the same company reuses the company sync token.
            again = admin.post("/api/admin/client-pairing", json={
                "company_id": str(self.company_id), "client_id": "CLIENT-V25-0002", "central_url": "https://rti.example.com"},
                headers={"X-CSRFToken": "v25-csrf"}).get_json()["pairing"]
            self.assertEqual(again["client_sync_token"], pairing["client_sync_token"])
            self.assertNotEqual(again["client_node_token"], pairing["client_node_token"])
            self.assertEqual(again["central_lan_url"], "")
            # Only Super Admin may create pairings.
            anonymous = self.client.post("/api/admin/client-pairing", json={"company_id": "1", "client_id": "X"},
                                         headers={"X-CSRFToken": "v25-csrf"})
            self.assertIn(anonymous.status_code, (400, 401, 403))
            self.last_pairing = pairing
        finally:
            for key, value in saved.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class MobileProxyTests(unittest.TestCase):
    def test_proxy_can_bind_lan_and_exposes_health_only_as_get(self):
        with patch.dict(os.environ, {"RTI_MOBILE_PROXY_HOST": "0.0.0.0", "RTI_ENV_FILE": str(Path(_TEST_ROOT.name) / "no-such.env")}):
            proxy = _load("rti_proxy_v25_test", ROOT / "MobileApiProxy" / "proxy.py")
        self.assertEqual(proxy.HOST, "0.0.0.0")
        self.assertIn(("GET", "/api/mobile/health"), proxy.ALLOWED)
        self.assertNotIn(("POST", "/api/mobile/health"), proxy.ALLOWED)
        self.assertNotIn(("GET", "/"), proxy.ALLOWED)

    def test_proxy_reads_its_bind_address_from_the_central_env_file(self):
        env_file = Path(_TEST_ROOT.name) / "proxy-test.env"
        env_file.write_text("RTI_MOBILE_PROXY_HOST=0.0.0.0\nRTI_MOBILE_PROXY_PORT=5299\n", encoding="utf-8")
        with patch.dict(os.environ, {"RTI_ENV_FILE": str(env_file)}):
            os.environ.pop("RTI_MOBILE_PROXY_HOST", None)
            os.environ.pop("RTI_MOBILE_PROXY_PORT", None)
            proxy = _load("rti_proxy_v25_envfile", ROOT / "MobileApiProxy" / "proxy.py")
            os.environ.pop("RTI_MOBILE_PROXY_HOST", None)
            os.environ.pop("RTI_MOBILE_PROXY_PORT", None)
        self.assertEqual((proxy.HOST, proxy.PORT), ("0.0.0.0", 5299))

    def test_proxy_defaults_to_localhost(self):
        with patch.dict(os.environ, {"RTI_ENV_FILE": str(Path(_TEST_ROOT.name) / "no-such.env")}, clear=False):
            os.environ.pop("RTI_MOBILE_PROXY_HOST", None)
            proxy = _load("rti_proxy_v25_default", ROOT / "MobileApiProxy" / "proxy.py")
        self.assertEqual(proxy.HOST, "127.0.0.1")


if __name__ == "__main__":
    unittest.main()
