import atexit
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path


_TEST_ROOT = tempfile.TemporaryDirectory(prefix="ab-rti-filter-tests-")
atexit.register(_TEST_ROOT.cleanup)
os.environ.setdefault("RTI_DATA_DIR", str(Path(_TEST_ROOT.name) / "data"))
os.environ.setdefault("RTI_BACKUP_DIR", str(Path(_TEST_ROOT.name) / "backups"))
os.environ.setdefault("RTI_SECRET_KEY", "automated-filter-tests-only")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "Web"))

import app as web  # noqa: E402


class HistoryAndAuditFilterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        connection = web.conn()
        try:
            connection.execute("UPDATE users SET must_change_password=0 WHERE username='admin'")
            connection.execute(
                "INSERT INTO companies(name,code,status,created_at) VALUES(?,?,?,?)",
                ("Filter Test Company", "FILTER-TEST", "ACTIVE", "2026-10-15 09:00:00"),
            )
            cls.company_id = connection.execute(
                "SELECT id FROM companies WHERE code='FILTER-TEST'"
            ).fetchone()["id"]
            connection.execute(
                "INSERT INTO points(company_id,point_code,name,qr_token,status,created_at) VALUES(?,?,?,?,?,?)",
                (cls.company_id, "FLT-01", "North Gate", "FILTER-TEST-QR", "ACTIVE", "2026-10-15 09:00:00"),
            )
            cls.point_id = connection.execute(
                "SELECT id FROM points WHERE point_code='FLT-01'"
            ).fetchone()["id"]
            connection.execute(
                "INSERT INTO inspectors(company_id,employee_id,name,login_username,status,created_at) VALUES(?,?,?,?,?,?)",
                (cls.company_id, "EMP-FLT-77", "Filter Inspector", "filter.inspector", "ACTIVE", "2026-10-15 09:00:00"),
            )
            cls.inspector_id = connection.execute(
                "SELECT id FROM inspectors WHERE employee_id='EMP-FLT-77'"
            ).fetchone()["id"]
            connection.execute(
                "INSERT INTO devices(company_id,device_id,device_identifier,status,access_policy,created_at) VALUES(?,?,?,?,?,?)",
                (cls.company_id, "DEV-FLT-77", "DEV-FLT-77", "ACTIVE", "OPEN", "2026-10-15 09:00:00"),
            )
            cls.device_pk = connection.execute(
                "SELECT id FROM devices WHERE device_id='DEV-FLT-77'"
            ).fetchone()["id"]
            connection.execute(
                "INSERT INTO inspection_sessions(session_token,company_id,inspector_id,device_id,started_at,status,inspection_type,schedule_name,checkpoint_ids) VALUES(?,?,?,?,?,?,?,?,?)",
                ("FILTER-TEST-SESSION", cls.company_id, cls.inspector_id, "DEV-FLT-77", "2026-10-15 09:00:00", "ENDED", "SCHEDULED", "Morning Patrol", "[]"),
            )
            cls.session_id = connection.execute(
                "SELECT id FROM inspection_sessions WHERE session_token='FILTER-TEST-SESSION'"
            ).fetchone()["id"]
            connection.execute(
                "INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,scan_time,result,sync_source,inspection_session_id,repeat_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (cls.company_id, cls.point_id, "FLT-01", cls.inspector_id, "Filter Inspector", "DEV-FLT-77", "2026-10-15 09:15:00", "ACCEPTED", "OFFLINE_QUEUE", cls.session_id, 0),
            )
            cls.scan_id = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.execute(
                "INSERT INTO audit_logs(user_id,company_id,action,entity_type,entity_id,details,created_at) VALUES(?,?,?,?,?,?,?)",
                (1, cls.company_id, "CREATE", "INSPECTOR", "EMP-FLT-77", "Created filter test inspector", "2026-10-15 09:16:00"),
            )
            connection.commit()
        finally:
            connection.close()

    def setUp(self):
        self.client = web.app.test_client()
        with self.client.session_transaction() as session:
            session["user_id"] = 1
            session["_csrf_token"] = "filter-test-csrf"

    def test_history_suggestions_are_scoped_and_typeable(self):
        response = self.client.get(f"/api/history/options?company_id={self.company_id}")
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertIn({"code": "FLT-01", "name": "North Gate"}, payload["points"])
        self.assertTrue(any(row["employee_id"] == "EMP-FLT-77" for row in payload["inspectors"]))
        self.assertIn("DEV-FLT-77", payload["devices"])
        self.assertIn("Morning Patrol", payload["schedules"])

    def test_admin_device_history_and_schedule_pages_render(self):
        for path, marker in (
            ("/devices", "Device Access"),
            ("/history", "Scan History"),
            ("/reports", "Reports"),
            ("/audit", "Audit Logs"),
            ("/schedules", "Schedules & Client Access"),
        ):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200, response.get_data(as_text=True)[:500])
                self.assertIn(marker.encode(), response.data)

    def test_schedule_form_shows_weekday_choices_and_reports_save_errors(self):
        response = self.client.get("/schedules")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'name="scheduleDay"', response.data)
        self.assertIn(b"Schedule could not be saved", response.data)
        self.assertIn(b"Schedule created successfully", response.data)

    def test_history_refreshes_every_five_seconds_without_overwriting_search(self):
        response = self.client.get("/history")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"loadHistory()},5000);", response.data)
        self.assertIn(b"document.activeElement?.matches('input,select,textarea')", response.data)

    def test_schedule_creation_accepts_lowercase_day_and_all_active_clients(self):
        response = self.client.post(
            "/api/schedules",
            json={
                "name": "Lowercase weekday test",
                "company_id": self.company_id,
                "client_id": "",
                "schedule_time": "18:58",
                "days": "mon",
                "grace_minutes": 15,
                "checkpoint_ids": [],
            },
            headers={"X-CSRFToken": "filter-test-csrf"},
        )
        self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        schedules = self.client.get(f"/api/schedules?company_id={self.company_id}").get_json()
        created = next(row for row in schedules if row["id"] == response.get_json()["id"])
        self.assertEqual(created["days"], ["MON"])
        self.assertIsNone(created["client_id"])

    def test_company_directory_shows_numeric_company_id_without_copy_control(self):
        response = self.client.get("/companies")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Company ID", response.data)
        self.assertNotIn(b"copyCompanyId", response.data)
        self.assertNotIn(b"Copy ID", response.data)
        companies = self.client.get("/api/companies").get_json()
        self.assertTrue(all(isinstance(row.get("id"), int) for row in companies))

    def test_admin_license_and_history_pages_show_requested_copy_and_delete_actions(self):
        license_page = self.client.get("/licenses")
        self.assertEqual(license_page.status_code, 200)
        self.assertIn(b"copyLicenseKey", license_page.data)
        self.assertIn(b"Copy activation key", license_page.data)
        history_page = self.client.get("/history")
        self.assertEqual(history_page.status_code, 200)
        self.assertIn(b"Delete selected history", history_page.data)
        self.assertIn(b"historySelectAll", history_page.data)

    def test_super_admin_deleting_scan_history_writes_audit_and_preserves_other_scans(self):
        connection = web.conn()
        try:
            connection.execute(
                "INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,scan_time,result,sync_source,inspection_session_id,repeat_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (self.company_id, self.point_id, "FLT-01", self.inspector_id, "History Delete Test", "DEV-FLT-77", "2026-10-15 09:20:00", "REPEAT", "OFFLINE_QUEUE", self.session_id, 1),
            )
            scan_id = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.commit()
        finally:
            connection.close()
        response = self.client.post(
            "/api/history/delete", json={"ids": [scan_id]}, headers={"X-CSRFToken": "filter-test-csrf"}
        )
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        self.assertEqual(response.get_json()["deleted"], 1)
        connection = web.conn()
        try:
            self.assertIsNone(connection.execute("SELECT id FROM scans WHERE id=?", (scan_id,)).fetchone())
            audit_row = connection.execute(
                "SELECT action,entity_type,entity_id,details FROM audit_logs WHERE action='DELETE' AND entity_type='SCAN' AND entity_id=?",
                (str(scan_id),),
            ).fetchone()
            self.assertIsNotNone(audit_row)
            self.assertIn("History Delete Test", audit_row["details"])
            self.assertIsNotNone(connection.execute("SELECT id FROM scans WHERE id=?", (self.scan_id,)).fetchone())
        finally:
            connection.close()

    def test_permanent_inspector_delete_erases_credentials_and_keeps_scan_snapshot(self):
        connection = web.conn()
        try:
            connection.execute(
                "INSERT INTO inspectors(company_id,employee_id,name,phone,login_username,password_hash,password_secret,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (self.company_id, "EMP-PURGE-1", "Purged Inspector", "0770000000", "purged.user", "hashed-secret", "encrypted-secret", "ACTIVE", "2026-10-15 09:00:00"),
            )
            inspector_id = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.execute(
                "INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,scan_time,result,sync_source,inspection_session_id,repeat_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (self.company_id, self.point_id, "FLT-01", inspector_id, "Purged Inspector", "DEV-PURGE-1", "2026-10-15 09:30:00", "ACCEPTED", "LIVE", self.session_id, 0),
            )
            scan_id = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.commit()
        finally:
            connection.close()
        headers = {"X-CSRFToken": "filter-test-csrf"}
        self.assertEqual(self.client.delete(f"/api/inspectors/{inspector_id}", headers=headers).status_code, 200)
        response = self.client.delete(f"/api/inspectors/{inspector_id}/permanent", headers=headers)
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        connection = web.conn()
        try:
            inspector = connection.execute(
                "SELECT employee_id,name,phone,login_username,password_hash,password_secret,status,permanently_deleted FROM inspectors WHERE id=?",
                (inspector_id,),
            ).fetchone()
            self.assertEqual(inspector["employee_id"], f"REMOVED-{inspector_id}")
            self.assertNotIn("Purged Inspector", inspector["name"])
            self.assertEqual(inspector["phone"], "")
            self.assertEqual(inspector["login_username"], "")
            self.assertEqual(inspector["password_hash"], "")
            self.assertEqual(inspector["password_secret"], "")
            self.assertEqual(inspector["status"], "DELETED")
            self.assertEqual(inspector["permanently_deleted"], 1)
            scan = connection.execute("SELECT inspector_name FROM scans WHERE id=?", (scan_id,)).fetchone()
            self.assertEqual(scan["inspector_name"], "Purged Inspector")
            self.assertIsNotNone(connection.execute(
                "SELECT id FROM audit_logs WHERE entity_type='INSPECTOR' AND entity_id=? AND action='PERMANENT_DELETE'",
                (str(inspector_id),),
            ).fetchone())
        finally:
            connection.close()

    def test_permanent_device_delete_keeps_blocked_tombstone_and_scan_history(self):
        connection = web.conn()
        try:
            connection.execute(
                "INSERT INTO devices(company_id,device_id,device_identifier,status,access_policy,created_at) VALUES(?,?,?,?,?,?)",
                (self.company_id, "DEV-PURGE-1", "DEV-PURGE-1", "ACTIVE", "OPEN", "2026-10-15 09:00:00"),
            )
            device_pk = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.execute(
                "INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,scan_time,result,sync_source,inspection_session_id,repeat_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (self.company_id, self.point_id, "FLT-01", self.inspector_id, "Filter Inspector", "DEV-PURGE-1", "2026-10-15 09:40:00", "ACCEPTED", "LIVE", self.session_id, 0),
            )
            scan_id = connection.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            connection.commit()
        finally:
            connection.close()
        headers = {"X-CSRFToken": "filter-test-csrf"}
        self.assertEqual(self.client.delete(f"/api/devices/{device_pk}", headers=headers).status_code, 200)
        response = self.client.delete(f"/api/devices/{device_pk}/permanent", headers=headers)
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        connection = web.conn()
        try:
            device = connection.execute("SELECT device_id,status,permanently_deleted FROM devices WHERE id=?", (device_pk,)).fetchone()
            self.assertEqual(tuple(device), ("DEV-PURGE-1", "DELETED", 1))
            self.assertEqual(connection.execute("SELECT device_id FROM scans WHERE id=?", (scan_id,)).fetchone()["device_id"], "DEV-PURGE-1")
            self.assertIn("removed", web.ensure_device(connection, self.company_id, "DEV-PURGE-1").lower())
        finally:
            connection.close()

    def test_history_and_csv_accept_date_name_id_and_category_filters(self):
        query = (
            f"company_id={self.company_id}&start=2026-10-15&end=2026-10-15"
            "&point=North%20Gate&inspector_id=EMP-FLT-77&schedule=Morning"
            "&sync_source=OFFLINE_QUEUE&inspection_type=SCHEDULED"
        )
        response = self.client.get("/api/history?" + query)
        self.assertEqual(response.status_code, 200)
        records = response.get_json()
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["inspector_employee_id"], "EMP-FLT-77")

        csv_response = self.client.get(
            f"/api/report.csv?company_id={self.company_id}&inspector_id=EMP-FLT-77&start=2026-10-15&end=2026-10-15"
        )
        self.assertEqual(csv_response.status_code, 200)
        self.assertIn(b"Inspector ID", csv_response.data)
        self.assertIn(b"EMP-FLT-77", csv_response.data)
        self.assertIn(b"North Gate", csv_response.data)

    def test_audit_suggestions_and_filters_include_record_ids(self):
        options_response = self.client.get("/api/audit/options")
        self.assertEqual(options_response.status_code, 200)
        options = options_response.get_json()
        self.assertIn("CREATE", options["actions"])
        self.assertIn("INSPECTOR", options["entity_types"])
        self.assertIn("EMP-FLT-77", options["entity_ids"])

        query = (
            "start=2026-10-15&end=2026-10-15&username=admin"
            f"&company_id={self.company_id}&action=CREATE&entity_type=INSPECTOR&entity_id=EMP-FLT-77"
        )
        response = self.client.get("/api/audit?" + query)
        self.assertEqual(response.status_code, 200)
        records = response.get_json()
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["entity_id"], "EMP-FLT-77")
        self.assertTrue(records[0]["id"] > 0)

    def test_super_admin_can_assign_edit_block_and_remove_device_without_losing_scans(self):
        headers = {"X-CSRFToken": "filter-test-csrf"}
        connection = web.conn()
        try:
            connection.execute(
                "INSERT INTO mobile_sessions(token,user_id,inspector_id,company_id,device_id,created_at,last_seen,status) VALUES(?,?,?,?,?,?,?,?)",
                ("FILTER-LIVE-DEVICE-SESSION", 1, self.inspector_id, self.company_id, "DEV-FLT-77", "2026-10-15 09:00:00", "2026-10-15 09:00:00", "ACTIVE"),
            )
            connection.commit()
        finally:
            connection.close()
        update = self.client.put(
            f"/api/devices/{self.device_pk}",
            json={"device_id": "DEV-FLT-78", "status": "ACTIVE", "access_policy": "ASSIGNED", "inspector_ids": [self.inspector_id]},
            headers=headers,
        )
        self.assertEqual(update.status_code, 200)
        self.assertTrue(update.get_json()["ok"])
        connection = web.conn()
        try:
            inspector = connection.execute("SELECT device_id FROM inspectors WHERE id=?", (self.inspector_id,)).fetchone()
            device = connection.execute("SELECT device_id,status,access_policy FROM devices WHERE id=?", (self.device_pk,)).fetchone()
            old_scan = connection.execute("SELECT device_id FROM scans WHERE device_id='DEV-FLT-77'").fetchone()
        finally:
            connection.close()
        self.assertEqual(inspector["device_id"], "DEV-FLT-78")
        self.assertEqual(tuple(device), ("DEV-FLT-78", "ACTIVE", "ASSIGNED"))
        self.assertEqual(old_scan["device_id"], "DEV-FLT-77")
        blocked = self.client.put(
            f"/api/devices/{self.device_pk}",
            json={"status": "DISABLED", "device_id": "DEV-FLT-78", "access_policy": "ASSIGNED", "inspector_ids": [self.inspector_id]},
            headers=headers,
        )
        self.assertEqual(blocked.status_code, 200)
        blocked_session = self.client.get("/api/mobile/state", headers={"Authorization": "Bearer FILTER-LIVE-DEVICE-SESSION"})
        self.assertEqual(blocked_session.status_code, 401)
        connection = web.conn()
        try:
            self.assertEqual(connection.execute("SELECT status FROM devices WHERE id=?", (self.device_pk,)).fetchone()["status"], "DISABLED")
            message = web.ensure_device(connection, self.company_id, "DEV-FLT-78")
        finally:
            connection.close()
        self.assertIn("blocked", message.lower())
        removed = self.client.delete(f"/api/devices/{self.device_pk}", headers=headers)
        self.assertEqual(removed.status_code, 200)
        self.assertTrue(removed.get_json()["ok"])
        hidden = self.client.get("/api/devices")
        self.assertNotIn(self.device_pk, [item["id"] for item in hidden.get_json()])
        visible = self.client.get("/api/devices?include_deleted=1")
        self.assertEqual(next(item for item in visible.get_json() if item["id"] == self.device_pk)["status"], "DELETED")
        history = self.client.get("/api/history?device=DEV-FLT-77")
        self.assertEqual(len(history.get_json()), 1)
        restored = self.client.put(
            f"/api/devices/{self.device_pk}",
            json={"status": "ACTIVE", "device_id": "DEV-FLT-78", "access_policy": "ASSIGNED", "inspector_ids": [self.inspector_id]},
            headers=headers,
        )
        self.assertEqual(restored.status_code, 200)
        connection = web.conn()
        try:
            self.assertEqual(connection.execute("SELECT status FROM devices WHERE id=?", (self.device_pk,)).fetchone()["status"], "ACTIVE")
            self.assertIsNone(web.ensure_device(connection, self.company_id, "DEV-FLT-78"))
        finally:
            connection.close()

    def test_super_admin_can_rename_block_and_restore_client_pc(self):
        headers = {"X-CSRFToken": "filter-test-csrf"}
        connection = web.conn()
        try:
            connection.execute(
                "INSERT INTO client_nodes(company_id,client_id,display_name,schedule_permission,status,created_at,last_seen_at) VALUES(?,?,?,?,?,?,?)",
                (self.company_id, "CLIENT-NODE-TEST", "Test workstation", 1, "ACTIVE", "2026-10-15 10:00:00", "2026-10-15 10:00:00"),
            )
            node_id = connection.execute(
                "SELECT id FROM client_nodes WHERE company_id=? AND client_id=?",
                (self.company_id, "CLIENT-NODE-TEST"),
            ).fetchone()["id"]
            connection.commit()
        finally:
            connection.close()

        renamed = self.client.put(
            f"/api/admin/client-nodes/{node_id}",
            json={"display_name": "North Gate PC"}, headers=headers,
        )
        self.assertEqual(renamed.status_code, 200, renamed.get_data(as_text=True))
        self.assertEqual(renamed.get_json()["display_name"], "North Gate PC")
        blocked = self.client.put(
            f"/api/admin/client-nodes/{node_id}",
            json={"display_name": "North Gate PC", "status": "DISABLED"}, headers=headers,
        )
        self.assertEqual(blocked.status_code, 200)
        token_map = {"RTI_CLIENT_NODE_TOKENS": f"{self.company_id}/CLIENT-NODE-TEST:test-node-token"}
        with patch.dict(os.environ, token_map):
            response = self.client.get(
                f"/api/client/bootstrap?company_id={self.company_id}&client_id=CLIENT-NODE-TEST",
                headers={"Authorization": "Bearer test-node-token"},
            )
        self.assertEqual(response.status_code, 403)
        self.assertIn("disabled", response.get_json()["message"].lower())
        listed = self.client.get("/api/admin/client-nodes").get_json()
        row = next(item for item in listed if item["id"] == node_id)
        self.assertEqual(row["status"], "DISABLED")
        self.assertEqual(row["display_name"], "North Gate PC")
        self.assertEqual(row["schedule_permission"], 1)
        restored = self.client.put(
            f"/api/admin/client-nodes/{node_id}",
            json={"display_name": "North Gate PC", "status": "ACTIVE"}, headers=headers,
        )
        self.assertEqual(restored.status_code, 200)
        with patch.dict(os.environ, token_map):
            response = self.client.get(
                f"/api/client/bootstrap?company_id={self.company_id}&client_id=CLIENT-NODE-TEST",
                headers={"Authorization": "Bearer test-node-token"},
            )
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        self.assertEqual(response.get_json()["client_id"], "CLIENT-NODE-TEST")

    def test_super_admin_can_edit_schedule_grace_period(self):
        created = self.client.post("/api/schedules", json={
            "company_id": self.company_id,
            "name": "Grace Update Patrol",
            "schedule_time": "10:30",
            "days": ["MON", "WED"],
            "grace_minutes": 10,
            "inspector_id": self.inspector_id,
            "checkpoint_ids": [self.point_id],
        }, headers={"X-CSRFToken": "filter-test-csrf"})
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        schedule_id = created.get_json()["id"]
        updated = self.client.put(
            f"/api/schedules/{schedule_id}",
            json={"grace_minutes": 35},
            headers={"X-CSRFToken": "filter-test-csrf"},
        )
        self.assertEqual(updated.status_code, 200, updated.get_data(as_text=True))
        connection = web.conn()
        try:
            row = connection.execute("SELECT grace_minutes,name,schedule_time FROM schedules WHERE id=?", (schedule_id,)).fetchone()
            self.assertEqual(tuple(row), (35, "Grace Update Patrol", "10:30"))
        finally:
            connection.close()


if __name__ == "__main__":
    unittest.main()
