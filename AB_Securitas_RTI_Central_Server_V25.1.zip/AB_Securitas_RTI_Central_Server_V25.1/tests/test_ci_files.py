"""Consistency checks for the build/deployment files of this package (GitHub Actions, PyInstaller, Inno Setup, Docker).

The real builds only run on GitHub, so these tests catch the mistakes that would otherwise only show up there:
a workflow whose project-root markers do not exist in this package, a spec/installer pointing at a missing file, a
drifted copy of the project-root finder, and so on.
"""
import os
import re
import subprocess
import sys
import tempfile
import textwrap
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"
FINDER = ROOT / "scripts" / "ci" / "find_project_root.py"


def embedded_scripts(workflow_text):
    """Return (markers, script) for every `python[3] - <markers> <<'PY' ... PY` block of a workflow."""
    found = []
    lines = workflow_text.splitlines()
    index = 0
    while index < len(lines):
        match = re.match(r"\s*python3?\s+-\s+(.*?)\s*<<'PY'\s*$", lines[index])
        if match:
            body = []
            index += 1
            while index < len(lines) and lines[index].strip() != "PY":
                body.append(lines[index])
                index += 1
            found.append((match.group(1).split(), textwrap.dedent("\n".join(body)).strip()))
        index += 1
    return found


def workflow_files():
    return sorted(WORKFLOWS.glob("*.yml"))


class WorkflowFileTests(unittest.TestCase):
    def test_workflows_exist(self):
        self.assertTrue(workflow_files(), "no workflow in .github/workflows")

    def test_every_workflow_finds_this_package_by_marker_files(self):
        for workflow in workflow_files():
            blocks = embedded_scripts(workflow.read_text(encoding="utf-8"))
            self.assertTrue(blocks, f"{workflow.name} has no project-root finder step")
            for markers, _ in blocks:
                for marker in markers:
                    self.assertTrue((ROOT / marker).is_file(), f"{workflow.name}: marker file {marker} is not in this package")

    def test_all_embedded_finders_are_identical(self):
        scripts = []
        for workflow in workflow_files():
            scripts += [script for _, script in embedded_scripts(workflow.read_text(encoding="utf-8"))]
        reference = FINDER.read_text(encoding="utf-8").strip() if FINDER.is_file() else scripts[0]
        for script in scripts:
            self.assertEqual(reference, script, "an embedded project-root finder drifted")

    def test_workflows_are_valid_yaml(self):
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML is not installed")
        for workflow in workflow_files():
            data = yaml.safe_load(workflow.read_text(encoding="utf-8"))
            self.assertIn("jobs", data, workflow.name)
            self.assertTrue("on" in data or True in data, workflow.name)  # YAML 1.1 turns `on` into True
            for job_name, job in data["jobs"].items():
                self.assertIn("runs-on", job, f"{workflow.name}:{job_name}")
                for step in job["steps"]:
                    self.assertTrue("uses" in step or "run" in step, f"{workflow.name}:{job_name}:{step}")

    def test_workflow_commands_reference_existing_files(self):
        pattern = re.compile(r"(?:windows|deploy/docker|Android)[/\\][\w./\\-]+\.(?:spec|iss|txt|kts|py|ps1)\b")
        for workflow in workflow_files():
            for relative in pattern.findall(workflow.read_text(encoding="utf-8")):
                self.assertTrue((ROOT / relative.replace("\\", "/")).is_file(), f"{workflow.name}: {relative}")
        for workflow in workflow_files():
            text = workflow.read_text(encoding="utf-8")
            if "docker build -f" in text:
                self.assertTrue((ROOT / "deploy" / "docker" / "Dockerfile").is_file())

    def test_workflows_do_not_use_unpinned_action_refs(self):
        for workflow in workflow_files():
            for use in re.findall(r"uses:\s*([^\s#]+)", workflow.read_text(encoding="utf-8")):
                self.assertRegex(use, r"@v?\d", f"{workflow.name}: action {use} has no version")


@unittest.skipUnless((ROOT / "windows").is_dir(), "no Windows packaging in this package")
class PackagingFileTests(unittest.TestCase):
    def test_pyinstaller_specs_point_to_existing_files(self):
        specs = list((ROOT / "windows").glob("*.spec"))
        self.assertTrue(specs)
        for spec in specs:
            text = spec.read_text(encoding="utf-8")
            for match in re.findall(r'ROOT\s*/\s*"([^"]+)"(?:\s*/\s*"([^"]+)")?(?:\s*/\s*"([^"]+)")?', text):
                parts = [part for part in match if part]
                self.assertTrue(ROOT.joinpath(*parts).exists(), f"{spec.name}: {'/'.join(parts)}")

    def test_installer_scripts_match_the_specs(self):
        for script in (ROOT / "windows" / "installer").glob("*.iss"):
            text = script.read_text(encoding="utf-8")
            icon = re.search(r"SetupIconFile=(.+)", text).group(1).strip().replace("\\", "/")
            self.assertTrue((script.parent / icon).resolve().is_file(), f"{script.name}: {icon}")
            self.assertIn("{#MyAppVersion}", text)
            folder = re.search(r'Source: "\.\.\\\.\.\\dist\\([^\\]+)\\\*"', text).group(1)
            spec = ROOT / "windows" / ("rti-server.spec" if folder == "rti-server" else "rti-client-pc.spec")
            self.assertIn(f'name="{folder}"', spec.read_text(encoding="utf-8"))

    def test_build_requirements_cover_runtime_imports(self):
        requirements = (ROOT / "windows" / "requirements-build.txt").read_text(encoding="utf-8").lower()
        for package in ("flask", "python-dotenv", "waitress", "pyinstaller"):
            self.assertIn(package, requirements)

    def test_spec_hidden_imports_that_are_project_modules_exist(self):
        requirements = (ROOT / "windows" / "requirements-build.txt").read_text(encoding="utf-8").lower()
        for spec in (ROOT / "windows").glob("*.spec"):
            text = spec.read_text(encoding="utf-8")
            for name in re.findall(r'"(rti_[a-z_0-9]+)"', text):
                homes = [ROOT / folder / f"{name}.py" for folder in ("windows", "Web", "ClientPC", "MobileApiProxy")]
                self.assertTrue(any(home.is_file() for home in homes), f"{spec.name}: hidden import {name} has no file")
            if "pystray" in text:
                self.assertIn("pystray", requirements)

    def test_windowed_program_answers_are_read_from_a_file_by_the_workflow(self):
        for spec in (ROOT / "windows").glob("*.spec"):
            if "console=False" not in spec.read_text(encoding="utf-8"):
                continue
            exe = re.search(r'name="([^"]+)"', spec.read_text(encoding="utf-8")).group(1)
            workflows = [w for w in workflow_files() if f"dist\\{exe}\\{exe}.exe" in w.read_text(encoding="utf-8")]
            self.assertTrue(workflows, f"no workflow smoke-tests {exe}.exe")
            for workflow in workflows:
                self.assertIn("RTI_SELFTEST_OUT", workflow.read_text(encoding="utf-8"),
                              f"{workflow.name}: a windowed exe prints nothing to the console")

    def test_installer_code_section_has_no_semicolon_comment_lines(self):
        for script in (ROOT / "windows" / "installer").glob("*.iss"):
            text = script.read_text(encoding="utf-8")
            if "[Code]" in text:
                code = text.split("[Code]", 1)[1]
                self.assertFalse([line for line in code.splitlines() if line.startswith(";")],
                                 f"{script.name}: a line starting with ';' inside [Code] is not a comment in Pascal Script")

    def test_icons_are_real_icon_files(self):
        icons = list((ROOT / "windows" / "assets").glob("*.ico"))
        self.assertTrue(icons)
        for icon in icons:
            self.assertEqual(icon.read_bytes()[:4], b"\x00\x00\x01\x00", icon.name)

    def test_launchers_report_a_version_the_workflow_can_read(self):
        for workflow in workflow_files():
            text = workflow.read_text(encoding="utf-8")
            match = re.search(r"Get-Content (\S+) -Raw", text)
            if not match:
                continue
            source = (ROOT / match.group(1)).read_text(encoding="utf-8")
            self.assertRegex(source, r'APP_VERSION\s*=\s*"[^"]+"', match.group(1))


@unittest.skipUnless((ROOT / "deploy" / "docker").is_dir(), "no Docker deployment in this package")
class DockerFileTests(unittest.TestCase):
    docker = ROOT / "deploy" / "docker"

    def test_dockerfile_copies_existing_sources(self):
        text = (self.docker / "Dockerfile").read_text(encoding="utf-8")
        for line in text.splitlines():
            if line.startswith("COPY "):
                for source in line.split()[1:-1]:
                    self.assertTrue((ROOT / source).exists(), f"Dockerfile COPY source missing: {source}")
        self.assertIn("/api/mobile/health", text)

    def test_caddy_routes_device_api_to_proxy_and_rest_to_dashboard(self):
        text = (self.docker / "Caddyfile").read_text(encoding="utf-8")
        for needle in ("/api/mobile/*", "/api/client/*", "rti:5200", "rti:5000"):
            self.assertIn(needle, text)

    def test_compose_sets_proxy_and_secure_cookie_flags_and_no_empty_secret(self):
        text = (self.docker / "docker-compose.yml").read_text(encoding="utf-8")
        self.assertIn('RTI_TRUST_PROXY: "1"', text)
        self.assertIn('RTI_COOKIE_SECURE: "1"', text)
        self.assertNotIn("RTI_SECRET_KEY", text)  # an empty env var would stop the generated secret from being used
        try:
            import yaml
        except ImportError:
            return
        self.assertEqual(set(yaml.safe_load(text)["services"]), {"rti", "caddy"})

    def test_secrets_are_not_shipped_in_docker_context(self):
        ignore = (ROOT / ".dockerignore").read_text(encoding="utf-8")
        self.assertIn("**/.env", ignore)


class GitIgnoreTests(unittest.TestCase):
    def test_secrets_and_build_outputs_are_ignored(self):
        text = (ROOT / ".gitignore").read_text(encoding="utf-8")
        for pattern in (".env", "dist-apk/" if (ROOT / "Android").is_dir() else "dist/", "*.jks"):
            self.assertIn(pattern, text)
        if (ROOT / "windows").is_dir():
            for pattern in ("dist/", "dist-installers/", "private-client-pairings/"):
                self.assertIn(pattern, text)


@unittest.skipUnless(FINDER.is_file(), "project-root finder script is not part of this package")
class ProjectRootFinderTests(unittest.TestCase):
    markers = ["Web/app.py", "windows/rti_server_launcher.py"]

    def run_finder(self, workspace):
        env = dict(os.environ, GITHUB_WORKSPACE=str(workspace))
        env.pop("GITHUB_OUTPUT", None)
        return subprocess.run([sys.executable, "-I", str(FINDER), *self.markers], env=env, capture_output=True, text=True)

    def make_project(self, base):
        for relative in self.markers:
            target = Path(base) / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("# marker\n", encoding="utf-8")

    def test_finds_project_committed_directly_in_a_subfolder(self):
        with tempfile.TemporaryDirectory() as workspace:
            self.make_project(Path(workspace) / "Some_Project_Folder")
            result = self.run_finder(workspace)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(result.stdout.strip().endswith("Some_Project_Folder"))

    def test_extracts_newest_zip_when_only_a_zip_is_committed(self):
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as staging:
            self.make_project(Path(staging) / "Project")
            for name in ("Project_V24.zip", "Project_V25.zip"):
                with zipfile.ZipFile(Path(workspace) / name, "w") as archive:
                    for relative in self.markers:
                        archive.write(Path(staging) / "Project" / relative, f"Project/{relative}")
                    archive.writestr("Project/VERSION.txt", name)
            result = self.run_finder(workspace)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual((Path(result.stdout.strip()) / "VERSION.txt").read_text(), "Project_V25.zip")

    def test_zip_with_path_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as workspace:
            with zipfile.ZipFile(Path(workspace) / "evil.zip", "w") as archive:
                archive.writestr("Web/app.py", "x")
                archive.writestr("../escape.txt", "x")
            result = self.run_finder(workspace)
            self.assertEqual(result.returncode, 1)
            self.assertFalse((Path(workspace).parent / "escape.txt").exists())

    def test_reports_clear_error_when_nothing_found(self):
        with tempfile.TemporaryDirectory() as workspace:
            result = self.run_finder(workspace)
            self.assertEqual(result.returncode, 1)
            self.assertIn("Could not find", result.stderr)


if __name__ == "__main__":
    unittest.main()
