"""Tests for the Central Server desktop application (manager window, engine supervisor, control server, helpers).

The Windows-only parts (registry, tray icon, Edge window, installer) can only be proven by the GitHub build, which runs
the packaged program; everything else is exercised here with real processes, real sockets and real SQLite files.
"""
import http.client
import json
import os
import re
import socket
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
WINDOWS = ROOT / "windows"
sys.path.insert(0, str(WINDOWS))

import rti_app_control as control  # noqa: E402
import rti_app_data as data  # noqa: E402
import rti_app_supervisor as supervisor_module  # noqa: E402
import rti_app_system as system  # noqa: E402
import rti_app_ui as ui  # noqa: E402
import rti_common as common  # noqa: E402
import rti_server_app as server_app  # noqa: E402
from rti_version import APP_VERSION  # noqa: E402


def free_port() -> int:
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]


def request(port, path, method="GET", token=None, host=None, body=None, raw_body=None):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    headers = {"Host": host if host is not None else f"127.0.0.1:{port}"}
    if token is not None:
        headers["X-RTI-Token"] = token
    payload = raw_body if raw_body is not None else (json.dumps(body).encode() if body is not None else None)
    if payload is not None:
        headers["Content-Type"] = "application/json"
    connection.request(method, path, body=payload, headers=headers)
    response = connection.getresponse()
    text = response.read().decode("utf-8", "replace")
    connection.close()
    return response.status, text


class VersionTests(unittest.TestCase):
    def test_app_version_matches_the_dashboard_version(self):
        source = (ROOT / "Web" / "app.py").read_text(encoding="utf-8")
        self.assertEqual(re.search(r'APP_VERSION\s*=\s*"([^"]+)"', source).group(1), APP_VERSION)

    def test_version_flag_prints_the_version_and_writes_the_answer_file(self):
        with tempfile.TemporaryDirectory() as folder:
            answer = Path(folder) / "version.txt"
            result = subprocess.run([sys.executable, str(WINDOWS / "rti_server_app.py"), "--version"], capture_output=True,
                                    text=True, timeout=60, env={**os.environ, "RTI_SELFTEST_OUT": str(answer)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), APP_VERSION)
            self.assertEqual(answer.read_text(encoding="utf-8").strip(), APP_VERSION)


class CommonHelperTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.addCleanup(self._folder.cleanup)
        self.folder = Path(self._folder.name)

    def test_update_env_values_changes_one_key_and_keeps_everything_else(self):
        env = self.folder / "server.env"
        env.write_text("# header\nRTI_SECRET_KEY=abc\nRTI_WEB_HOST=127.0.0.1\nRTI_WEB_PORT=5000\n", encoding="utf-8")
        common.update_env_values(env, {"RTI_WEB_HOST": "0.0.0.0", "RTI_NEW": "1"})
        text = env.read_text(encoding="utf-8")
        self.assertIn("# header", text)
        self.assertIn("RTI_SECRET_KEY=abc", text)
        self.assertIn("RTI_WEB_HOST=0.0.0.0", text)
        self.assertNotIn("RTI_WEB_HOST=127.0.0.1", text)
        self.assertIn("RTI_WEB_PORT=5000", text)
        self.assertIn("RTI_NEW=1", text)
        self.assertEqual(common.read_env_values(env)["RTI_WEB_HOST"], "0.0.0.0")

    def test_update_env_values_rejects_bad_keys_and_multi_line_values(self):
        env = self.folder / "server.env"
        env.write_text("A=1\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            common.update_env_values(env, {"bad key": "1"})
        with self.assertRaises(ValueError):
            common.update_env_values(env, {"RTI_WEB_HOST": "0.0.0.0\nRTI_SECRET_KEY=stolen"})
        self.assertEqual(env.read_text(encoding="utf-8"), "A=1\n")

    def test_json_files_round_trip_and_bad_files_read_as_empty(self):
        target = self.folder / "engine.json"
        common.write_json_atomic(target, {"pid": 7, "text": "x"})
        self.assertEqual(common.read_json(target), {"pid": 7, "text": "x"})
        self.assertEqual(common.read_json(self.folder / "missing.json"), {})
        target.write_text("{not json", encoding="utf-8")
        self.assertEqual(common.read_json(target), {})
        self.assertEqual(list(self.folder.glob("*.tmp")), [])

    def test_pid_alive(self):
        self.assertTrue(common.pid_alive(os.getpid()))
        self.assertFalse(common.pid_alive(0))
        self.assertFalse(common.pid_alive(None))
        child = subprocess.Popen([sys.executable, "-c", "pass"])
        child.wait()
        self.assertFalse(common.pid_alive(child.pid))


class DataTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.addCleanup(self._folder.cleanup)
        self.folder = Path(self._folder.name)
        self.db = self.folder / "data" / "inspector.db"
        self.db.parent.mkdir()
        con = sqlite3.connect(self.db)
        con.executescript("""
            CREATE TABLE companies(id INTEGER PRIMARY KEY, name TEXT, status TEXT);
            CREATE TABLE inspectors(id INTEGER PRIMARY KEY, status TEXT);
            CREATE TABLE devices(id INTEGER PRIMARY KEY, status TEXT, deleted_at TEXT);
            CREATE TABLE schedules(id INTEGER PRIMARY KEY, enabled INTEGER);
            CREATE TABLE scans(id INTEGER PRIMARY KEY, scan_time TEXT);
            CREATE TABLE client_nodes(id INTEGER PRIMARY KEY, company_id INTEGER, client_id TEXT, display_name TEXT,
                                      status TEXT, last_seen_at TEXT);
            CREATE TABLE settings(id INTEGER PRIMARY KEY, company_id INTEGER, setting_key TEXT, setting_value TEXT);
        """)
        today = time.strftime("%Y-%m-%d")
        con.executemany("INSERT INTO companies(name,status) VALUES(?,?)", [("A", "ACTIVE"), ("B", "ACTIVE"), ("C", "INACTIVE")])
        con.executemany("INSERT INTO inspectors(status) VALUES(?)", [("ACTIVE",), ("ACTIVE",), ("INACTIVE",)])
        con.executemany("INSERT INTO devices(status,deleted_at) VALUES(?,?)", [("ACTIVE", None), ("ACTIVE", "2020-01-01"), ("BLOCKED", None)])
        con.executemany("INSERT INTO schedules(enabled) VALUES(?)", [(1,), (0,), (1,)])
        con.executemany("INSERT INTO scans(scan_time) VALUES(?)", [(today + " 10:00:00",), (today + " 11:00:00",), ("2001-01-01 00:00:00",)])
        con.execute("INSERT INTO client_nodes(company_id,client_id,display_name,status,last_seen_at) VALUES(1,'C1','Gate PC','ACTIVE',?)",
                    (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 30)),))
        con.execute("INSERT INTO client_nodes(company_id,client_id,display_name,status,last_seen_at) VALUES(2,'C2',NULL,'BLOCKED',NULL)")
        con.commit()
        con.close()

    def test_overview_counts_only_what_is_active(self):
        overview = data.build_overview(self.db)
        self.assertTrue(overview["available"])
        self.assertEqual((overview["companies"], overview["inspectors"], overview["devices"], overview["schedules"], overview["scans_today"]),
                         (2, 2, 1, 2, 2))
        gate, blocked = overview["client_pcs"][0], overview["client_pcs"][1]
        self.assertEqual((gate["name"], gate["company"], gate["blocked"]), ("Gate PC", "A", False))
        self.assertLess(gate["seen_seconds_ago"], 120)
        self.assertEqual((blocked["name"], blocked["blocked"], blocked["seen_seconds_ago"]), ("C2", True, None))

    def test_overview_is_unavailable_before_the_database_exists(self):
        self.assertEqual(data.build_overview(self.folder / "nope.db"), {"available": False})
        self.assertEqual(data.build_overview(None), {"available": False})

    def test_overview_never_writes_to_the_database(self):
        before = self.db.read_bytes()
        data.build_overview(self.db)
        self.assertEqual(self.db.read_bytes(), before)

    def test_backup_now_writes_a_verified_copy_with_a_restorable_name(self):
        destination = data.backup_now(self.db, self.folder / "backups")
        self.assertRegex(destination.name, r"^central_\d{8}T\d{6}\.\d+\.db$")
        copy = sqlite3.connect(destination)
        self.assertEqual(copy.execute("SELECT COUNT(*) FROM companies").fetchone()[0], 3)
        self.assertEqual(copy.execute("PRAGMA quick_check").fetchone()[0], "ok")
        copy.close()
        self.assertEqual(list((self.folder / "backups").glob("*.tmp")), [])

    def test_backup_uses_the_folder_chosen_in_the_dashboard_and_never_the_live_folder(self):
        chosen = self.folder / "chosen"
        con = sqlite3.connect(self.db)
        con.execute("INSERT INTO settings(company_id,setting_key,setting_value) VALUES(0,'backup_directory',?)", (str(chosen),))
        con.commit()
        con.close()
        self.assertEqual(data.backup_folder(self.db, self.folder / "default"), chosen.resolve())
        self.assertEqual(data.backup_now(self.db, self.folder / "default").parent, chosen.resolve())
        con = sqlite3.connect(self.db)
        con.execute("UPDATE settings SET setting_value=? WHERE setting_key='backup_directory'", (str(self.db.parent),))
        con.commit()
        con.close()
        with self.assertRaises(ValueError):
            data.backup_now(self.db, self.folder / "default")

    def test_backup_of_a_missing_database_explains_itself(self):
        with self.assertRaises(FileNotFoundError):
            data.backup_now(self.folder / "nope.db", self.folder / "backups")

    def test_tail_text_returns_the_last_lines_only(self):
        log = self.folder / "server.log"
        log.write_text("\n".join(f"line {i}" for i in range(1000)), encoding="utf-8")
        text = data.tail_text(log, 5)
        self.assertEqual(text.splitlines(), [f"line {i}" for i in range(995, 1000)])
        self.assertEqual(data.tail_text(self.folder / "missing.log", 5), "")


class ControlServerTests(unittest.TestCase):
    def setUp(self):
        self.calls = []

        def ok(body):
            self.calls.append(("ok", body))
            return {"message": "done"}

        def bad(body):
            raise ValueError("Nothing to change.")

        def boom(body):
            raise RuntimeError("The disk is full.")

        self.server = control.ControlServer("secret-token", lambda token: f"<html>token={token}</html>",
                                            lambda: {"state": "running"}, lambda which, lines: f"{which}:{lines}",
                                            {"ok": ok, "bad": bad, "boom": boom})
        self.server.start()
        self.addCleanup(self.server.stop)
        self.port = self.server.port

    def test_page_needs_the_token_and_sets_a_strict_policy(self):
        self.assertEqual(request(self.port, "/")[0], 403)
        self.assertEqual(request(self.port, "/?t=wrong")[0], 403)
        status, body = request(self.port, "/?t=secret-token")
        self.assertEqual((status, body), (200, "<html>token=secret-token</html>"))
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        connection.request("GET", "/?t=secret-token")
        response = connection.getresponse()
        response.read()
        self.assertIn("default-src 'none'", response.getheader("Content-Security-Policy"))
        self.assertEqual(response.getheader("Cache-Control"), "no-store")
        connection.close()

    def test_api_needs_the_token(self):
        self.assertEqual(request(self.port, "/api/state")[0], 403)
        self.assertEqual(request(self.port, "/api/state", token="nope")[0], 403)
        status, body = request(self.port, "/api/state", token="secret-token")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {"ok": True, "state": "running"})
        self.assertEqual(request(self.port, "/api/ping", token="secret-token")[0], 200)
        self.assertEqual(request(self.port, "/api/unknown", token="secret-token")[0], 404)

    def test_other_host_names_are_refused(self):
        for host in ("evil.example.com", f"evil.example.com:{self.port}", "127.0.0.1", ""):
            self.assertEqual(request(self.port, "/api/state", token="secret-token", host=host)[0], 403, host)
        self.assertEqual(request(self.port, "/api/state", token="secret-token", host=f"localhost:{self.port}")[0], 200)

    def test_log_endpoint_limits_the_line_count(self):
        self.assertEqual(json.loads(request(self.port, "/api/log?which=app&lines=5", token="secret-token")[1])["text"], "app:20")
        self.assertEqual(json.loads(request(self.port, "/api/log?which=server&lines=999999", token="secret-token")[1])["text"], "server:1000")
        self.assertEqual(json.loads(request(self.port, "/api/log?lines=abc", token="secret-token")[1])["text"], "server:300")

    def test_actions_run_with_a_json_body_and_report_failures_plainly(self):
        status, body = request(self.port, "/api/action/ok", "POST", "secret-token", body={"what": "x"})
        self.assertEqual((status, json.loads(body)), (200, {"ok": True, "message": "done"}))
        self.assertEqual(self.calls, [("ok", {"what": "x"})])
        status, body = request(self.port, "/api/action/bad", "POST", "secret-token", body={})
        self.assertEqual((status, json.loads(body)["message"]), (400, "Nothing to change."))
        status, body = request(self.port, "/api/action/boom", "POST", "secret-token", body={})
        self.assertEqual((status, json.loads(body)["message"]), (500, "The disk is full."))
        self.assertEqual(request(self.port, "/api/action/missing", "POST", "secret-token", body={})[0], 404)

    def test_actions_refuse_bad_callers_and_bad_bodies(self):
        self.assertEqual(request(self.port, "/api/action/ok", "POST", body={})[0], 403)
        self.assertEqual(request(self.port, "/api/action/ok", "POST", "wrong", body={})[0], 403)
        self.assertEqual(request(self.port, "/api/action/ok", "POST", "secret-token", raw_body=b"[1, 2]")[0], 400)
        self.assertEqual(request(self.port, "/api/action/ok", "POST", "secret-token", raw_body=b"{broken")[0], 400)
        self.assertEqual(request(self.port, "/api/action/ok", "POST", "secret-token", raw_body=b"{" + b" " * 20000 + b"}")[0], 413)
        self.assertEqual(self.calls, [])

    def test_the_server_listens_on_this_pc_only(self):
        self.assertEqual(self.server._httpd.server_address[0], "127.0.0.1")


class SystemHelperTests(unittest.TestCase):
    def test_app_window_command_opens_a_tab_less_window_with_its_own_profile(self):
        command = system.app_window_command("C:/Edge/msedge.exe", "http://127.0.0.1:1/?t=x", Path("profile"), (1000, 700))
        self.assertEqual(command[0], "C:/Edge/msedge.exe")
        self.assertIn("--app=http://127.0.0.1:1/?t=x", command)
        self.assertTrue(any(part.startswith("--user-data-dir=") and "profile" in part for part in command))
        self.assertIn("--window-size=1000,700", command)

    def test_browser_override_is_used_when_it_exists(self):
        with tempfile.NamedTemporaryFile() as fake, patch.dict(os.environ, {"RTI_BROWSER_PATH": fake.name}):
            self.assertEqual(system.find_browser(), fake.name)
        with patch.dict(os.environ, {"RTI_BROWSER_PATH": "/no/such/browser"}, clear=False):
            self.assertNotEqual(system.find_browser(), "/no/such/browser")

    def test_start_with_windows_is_offered_only_in_the_installed_windows_program(self):
        if os.name != "nt":
            self.assertFalse(system.autostart_supported())
            self.assertFalse(system.autostart_enabled())
            with self.assertRaises(RuntimeError):
                system.set_autostart(True)
        with patch.object(sys, "executable", r"C:\Program Files\RTI\rti-server.exe"):
            self.assertEqual(system.autostart_command(), '"C:\\Program Files\\RTI\\rti-server.exe" --background')

    def test_embedded_icon_is_a_real_png(self):
        png = system.decode_png(ui.ICON_PNG_B64)
        self.assertTrue(png.startswith(b"\x89PNG\r\n\x1a\n"))

    def test_manager_page_carries_the_token_and_no_leftover_placeholders(self):
        page = ui.render_manager("tok-123")
        self.assertIn('"tok-123"', page)
        self.assertNotIn("__TOKEN__", page)
        self.assertNotIn("__ICON__", page)
        self.assertIn("AB Securitas RTI Server", page)
        self.assertNotRegex(page, r'src="https?://|href="https?://')  # the page is self-contained

    def test_tray_is_silently_unavailable_without_a_tray_library(self):
        tray = system.Tray(system.decode_png(ui.ICON_PNG_B64), "title", lambda: None, lambda: None, lambda: None, lambda: None)
        with patch.dict(sys.modules, {"pystray": None}), patch.dict(os.environ, {"RTI_FORCE_TRAY": "1"}):
            self.assertFalse(tray.start())
        self.assertFalse(tray.available)
        tray.stop()
        tray.notify("nothing happens")


FAKE_ENGINE = textwrap.dedent('''
    """A stand-in for the real engine: answers /api/mobile/health on both ports and writes engine.json."""
    import json, os, sys, threading, time
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from pathlib import Path

    config = Path(os.environ["FAKE_CONFIG_DIR"])
    if os.environ.get("FAKE_MODE") == "crash":
        print("ERROR: Port 5000 is already in use", file=sys.stderr)
        (config / "logs").mkdir(parents=True, exist_ok=True)
        (config / "logs" / "server.log").write_text("2026-01-01 ERROR: Port 5000 is already in use\\n", encoding="utf-8")
        sys.exit(3)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            body = b'{"ok": true}'
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def log_message(self, *args):
            pass

    for key in ("RTI_WEB_PORT", "RTI_MOBILE_PROXY_PORT"):
        server = ThreadingHTTPServer(("127.0.0.1", int(os.environ[key])), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
    info = {"pid": os.getpid(), "started_at": time.time(), "web_port": int(os.environ["RTI_WEB_PORT"]),
            "proxy_port": int(os.environ["RTI_MOBILE_PROXY_PORT"]), "log_file": str(config / "logs" / "server.log")}
    (config / "engine.json").write_text(json.dumps(info), encoding="utf-8")
    while True:
        time.sleep(1)
''')


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.addCleanup(self._folder.cleanup)
        self.config = Path(self._folder.name) / "config"
        self.config.mkdir()
        self.script = Path(self._folder.name) / "fake_engine.py"
        self.script.write_text(FAKE_ENGINE, encoding="utf-8")
        self.web, self.api = free_port(), free_port()
        self.env = {**os.environ, "FAKE_CONFIG_DIR": str(self.config), "RTI_WEB_PORT": str(self.web),
                    "RTI_MOBILE_PROXY_PORT": str(self.api), "RTI_WEB_HOST": "127.0.0.1", "RTI_MOBILE_PROXY_HOST": "127.0.0.1"}
        for key in ("RTI_WEB_PORT", "RTI_MOBILE_PROXY_PORT", "RTI_WEB_HOST", "RTI_MOBILE_PROXY_HOST"):
            patcher = patch.dict(os.environ, {key: self.env[key]})
            patcher.start()
            self.addCleanup(patcher.stop)
        self.messages = []

    def make(self, mode="ok"):
        env = dict(self.env, FAKE_MODE=mode)
        supervisor = supervisor_module.EngineSupervisor(self.config, [sys.executable, str(self.script)], env=env,
                                                        log=self.messages.append)
        supervisor.start_thread()
        self.addCleanup(supervisor.shutdown)
        return supervisor

    def test_start_reports_running_when_both_ports_answer_and_stop_closes_them(self):
        supervisor = self.make()
        supervisor.start()
        self.assertTrue(supervisor.wait_until(supervisor_module.RUNNING, 30), supervisor.snapshot())
        self.assertTrue(supervisor_module.probe(self.web) and supervisor_module.probe(self.api))
        snapshot = supervisor.snapshot()
        self.assertIsNotNone(snapshot["uptime_seconds"])
        self.assertTrue(snapshot["web_ok"] and snapshot["api_ok"])
        supervisor.stop()
        self.assertEqual(supervisor.snapshot()["state"], supervisor_module.STOPPED)
        self.assertFalse(supervisor_module.probe(self.web, 1))
        self.assertFalse(supervisor_module.probe(self.api, 1))

    def test_restart_replaces_the_engine_process(self):
        supervisor = self.make()
        supervisor.start()
        self.assertTrue(supervisor.wait_until(supervisor_module.RUNNING, 30))
        first_pid = supervisor.engine_info()["pid"]
        supervisor.restart()
        self.assertTrue(supervisor.wait_until(supervisor_module.RUNNING, 30))
        deadline = time.time() + 15
        while supervisor.engine_info().get("pid") == first_pid and time.time() < deadline:
            time.sleep(0.2)
        self.assertNotEqual(supervisor.engine_info()["pid"], first_pid)
        self.assertFalse(common.pid_alive(first_pid))

    def test_an_engine_that_dies_is_started_again_by_itself(self):
        supervisor = self.make()
        supervisor.start()
        self.assertTrue(supervisor.wait_until(supervisor_module.RUNNING, 30))
        first_pid = supervisor.engine_info()["pid"]
        os.kill(first_pid, 9 if os.name != "nt" else 15)
        deadline = time.time() + 40
        while time.time() < deadline:
            snapshot = supervisor.snapshot()
            if snapshot["restarts"] >= 1 and snapshot["state"] == supervisor_module.RUNNING:
                break
            time.sleep(0.3)
        snapshot = supervisor.snapshot()
        self.assertGreaterEqual(snapshot["restarts"], 1)
        self.assertEqual(snapshot["state"], supervisor_module.RUNNING)
        self.assertNotEqual(supervisor.engine_info()["pid"], first_pid)

    def test_an_engine_that_cannot_start_ends_in_an_error_that_names_the_reason(self):
        with patch.object(supervisor_module, "BACKOFF_SECONDS", (0,)), patch.object(supervisor_module, "MAX_QUICK_FAILURES", 3):
            supervisor = self.make("crash")
            supervisor.start()
            self.assertTrue(supervisor.wait_until(supervisor_module.ERROR, 40), supervisor.snapshot())
        snapshot = supervisor.snapshot()
        self.assertIn("Port 5000 is already in use", snapshot["message"])
        self.assertIn("press Start", snapshot["message"])
        self.assertFalse(supervisor.desired_running)

    def test_a_server_left_running_is_adopted_not_started_twice(self):
        first = subprocess.Popen([sys.executable, str(self.script)], env=dict(self.env, FAKE_MODE="ok"))
        self.addCleanup(lambda: first.poll() is None and (first.kill(), first.wait()))
        deadline = time.time() + 20
        while time.time() < deadline and not supervisor_module.probe(self.web):
            time.sleep(0.2)
        supervisor = self.make()
        supervisor.start()
        self.assertTrue(supervisor.wait_until(supervisor_module.RUNNING, 30))
        self.assertTrue(supervisor.snapshot()["adopted"])
        self.assertEqual(supervisor.engine_info()["pid"], first.pid)
        supervisor.stop()
        first.wait(timeout=15)
        self.assertFalse(common.pid_alive(first.pid))

    def test_runtime_endpoints_prefer_the_environment_then_the_file_then_defaults(self):
        env_file = self.config / "server.env"
        env_file.write_text("RTI_WEB_PORT=6001\nRTI_MOBILE_PROXY_HOST=0.0.0.0\n", encoding="utf-8")
        with patch.dict(os.environ, {"RTI_WEB_PORT": "", "RTI_MOBILE_PROXY_HOST": "", "RTI_WEB_HOST": "", "RTI_MOBILE_PROXY_PORT": ""}):
            endpoints = supervisor_module.runtime_endpoints(env_file)
        self.assertEqual(endpoints, {"web_host": "127.0.0.1", "web_port": 6001, "proxy_host": "0.0.0.0", "proxy_port": 5200})
        with patch.dict(os.environ, {"RTI_WEB_PORT": "7002"}):
            self.assertEqual(supervisor_module.runtime_endpoints(env_file)["web_port"], 7002)

    def test_engine_command_for_source_and_for_the_packaged_exe(self):
        script = Path("/x/rti_server_app.py")
        self.assertEqual(supervisor_module.engine_command(script), [sys.executable, str(script), "--engine"])
        with patch.object(common, "is_frozen", return_value=True):
            self.assertEqual(supervisor_module.engine_command(script), [sys.executable, "--engine"])


class DesktopAppTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.addCleanup(self._folder.cleanup)
        folder = Path(self._folder.name)
        patcher = patch.dict(os.environ, {"RTI_CONFIG_DIR": str(folder / "config"), "RTI_DATA_DIR": str(folder / "data"),
                                          "RTI_BACKUP_DIR": str(folder / "backups"), "RTI_WEB_PORT": "", "RTI_WEB_HOST": "",
                                          "RTI_MOBILE_PROXY_HOST": "", "RTI_MOBILE_PROXY_PORT": ""})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.app = server_app.DesktopApp(background=True)
        self.addCleanup(self.app.control.stop)

    def test_first_start_creates_the_settings_file_with_private_secrets(self):
        values = common.read_env_values(self.app.env_file)
        self.assertGreaterEqual(len(values["RTI_SECRET_KEY"]), 32)
        self.assertEqual(values["RTI_WEB_HOST"], "127.0.0.1")
        self.assertEqual(values["RTI_MOBILE_PROXY_PORT"], "5200")

    def test_state_has_everything_the_window_reads(self):
        state = self.app.state()
        for key in ("state", "message", "uptime_seconds", "restarts", "pulse", "version", "addresses", "overview", "settings", "paths"):
            self.assertIn(key, state)
        self.assertEqual(state["version"], APP_VERSION)
        self.assertEqual(state["addresses"]["dashboard"], "http://127.0.0.1:5000/")
        self.assertTrue(state["addresses"]["api_lan_enabled"])  # the packaged default lets phones connect
        self.assertEqual(state["addresses"]["dashboard_lan"], [])
        self.assertFalse(state["overview"]["available"])
        json.dumps(state)  # must be serialisable

    def test_state_lists_the_dashboard_for_other_pcs_only_when_it_is_opened_to_the_network(self):
        common.update_env_values(self.app.env_file, {"RTI_WEB_HOST": "0.0.0.0", "RTI_MOBILE_PROXY_HOST": "127.0.0.1"})
        with patch.object(common, "lan_addresses", return_value=["192.168.1.20"]):
            state = self.app.state()
        self.assertEqual(state["addresses"]["dashboard_lan"], ["http://192.168.1.20:5000/"])
        self.assertFalse(state["addresses"]["api_lan_enabled"])
        self.assertEqual(state["addresses"]["lan"], [])

    def test_network_switch_edits_the_settings_file_and_restarts_the_server(self):
        with patch.object(self.app.supervisor, "restart") as restart:
            message = self.app.a_settings({"lan_dashboard": True})["message"]
            self.assertEqual(common.read_env_values(self.app.env_file)["RTI_WEB_HOST"], "0.0.0.0")
            self.app.a_settings({"lan_dashboard": False})
            self.assertEqual(common.read_env_values(self.app.env_file)["RTI_WEB_HOST"], "127.0.0.1")
            self.assertEqual(restart.call_count, 2)
        self.assertIn("network", message)
        with self.assertRaises(ValueError):
            self.app.a_settings({})

    def test_actions_report_clear_errors(self):
        with self.assertRaises(ValueError):
            self.app.a_open({"what": "registry"})
        with self.assertRaises(FileNotFoundError):
            self.app.a_backup({})

    def test_second_copy_hands_over_to_the_running_one(self):
        self.app.control.start()
        common.write_json_atomic(self.app.app_file, {"pid": os.getpid(), "port": self.app.control.port, "token": self.app.token})
        shown = []
        with patch.object(self.app, "open_manager", lambda: shown.append(True)):
            second = server_app.DesktopApp(background=False)
            self.addCleanup(second.control.stop)
            self.assertTrue(second.another_instance_running())
            self.assertEqual(shown, [True])  # the running copy was asked to bring its window forward
            quiet = server_app.DesktopApp(background=True)
            self.addCleanup(quiet.control.stop)
            self.assertTrue(quiet.another_instance_running())
            self.assertEqual(shown, [True])  # a background start (Start with Windows) must not pop a window up

    def test_no_other_copy_is_assumed_when_the_record_is_stale(self):
        self.assertFalse(self.app.another_instance_running())
        common.write_json_atomic(self.app.app_file, {"pid": 999999, "port": 1, "token": "x"})
        self.assertFalse(self.app.another_instance_running())
        common.write_json_atomic(self.app.app_file, {"pid": os.getpid(), "port": free_port(), "token": "x"})
        self.assertFalse(self.app.another_instance_running())


class EndToEndTests(unittest.TestCase):
    def test_packaged_style_self_test_passes(self):
        """Runs the same `--selftest` the GitHub build runs on the packaged exe, here against the Python sources."""
        with tempfile.TemporaryDirectory() as folder:
            answer = Path(folder) / "selftest.txt"
            result = subprocess.run([sys.executable, str(WINDOWS / "rti_server_app.py"), "--selftest"], capture_output=True,
                                    text=True, timeout=240, env={**os.environ, "RTI_SELFTEST_OUT": str(answer)})
            written = answer.read_text(encoding="utf-8") if answer.exists() else ""
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("SELFTEST OK", written)
            self.assertNotIn("FAIL", written)


if __name__ == "__main__":
    unittest.main()
