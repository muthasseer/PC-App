import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SOURCE_ROOT = Path(__file__).resolve().parents[1]


class RegisterClientPCTests(unittest.TestCase):
    def run_registration(self, central_url_input="", configured_url=None):
        temporary = tempfile.TemporaryDirectory(prefix="ab-rti-register-client-")
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "scripts").mkdir()
        (root / "Web").mkdir()
        script = root / "scripts" / "register_client_pc.py"
        script.write_bytes((SOURCE_ROOT / "scripts" / "register_client_pc.py").read_bytes())
        default_url = configured_url or "https://lkabsatml005.tail6bfc97.ts.net"
        env_file = root / "Web" / ".env"
        env_file.write_text(
            "RTI_CLIENT_SYNC_TOKENS=\n"
            "RTI_CLIENT_NODE_TOKENS=\n"
            f"RTI_CENTRAL_FUNNEL_URL={default_url}\n",
            encoding="utf-8",
        )
        result = subprocess.run(
            [sys.executable, str(script)],
            input=f"7\nCLIENT-TEST-0001\n{central_url_input}\n",
            cwd=root,
            text=True,
            capture_output=True,
            check=False,
        )
        pairing_path = root / "private-client-pairings" / "Company-7_CLIENT-TEST-0001.json"
        return result, pairing_path, env_file, default_url

    def test_registration_uses_prefilled_default_when_enter_is_pressed(self):
        result, pairing_path, env_file, default_url = self.run_registration()
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn(f"Central HTTPS Funnel origin [{default_url}]", result.stdout)
        pairing = json.loads(pairing_path.read_text(encoding="utf-8"))
        self.assertEqual(pairing["central_url"], default_url)
        self.assertIn(f"RTI_CENTRAL_FUNNEL_URL={default_url}", env_file.read_text(encoding="utf-8"))

    def test_registration_keeps_user_edited_central_domain(self):
        custom_url = "https://custom-central.tail6bfc97.ts.net"
        result, pairing_path, env_file, _ = self.run_registration(custom_url)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        pairing = json.loads(pairing_path.read_text(encoding="utf-8"))
        self.assertEqual(pairing["central_url"], custom_url)
        self.assertIn(f"RTI_CENTRAL_FUNNEL_URL={custom_url}", env_file.read_text(encoding="utf-8"))

    def test_old_placeholder_domain_is_replaced_by_the_configured_default(self):
        result, pairing_path, _, _ = self.run_registration(
            configured_url="https://your-device.tailnet.ts.net"
        )
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        pairing = json.loads(pairing_path.read_text(encoding="utf-8"))
        self.assertEqual(pairing["central_url"], "https://lkabsatml005.tail6bfc97.ts.net")


if __name__ == "__main__":
    unittest.main()
