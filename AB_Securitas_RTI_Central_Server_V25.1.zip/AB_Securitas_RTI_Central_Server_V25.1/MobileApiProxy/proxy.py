"""Allow-list reverse proxy for the mobile API and Client PC sync.

Default bind is localhost (published online by Tailscale Funnel / a reverse proxy). Set
RTI_MOBILE_PROXY_HOST=0.0.0.0 to ALSO serve Android phones and Client PCs on the same
Wi-Fi/LAN directly. The Central dashboard is never exposed here: only the required mobile
routes and the token-protected Client PC sync routes are forwarded to Flask on port 5000;
all other APIs are denied.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from collections import defaultdict, deque
import json
import os
import sys
import threading
import time
from pathlib import Path



def _load_environment():
    """Pick up RTI_MOBILE_PROXY_* / RTI_LOCAL_BACKEND from the same .env as the Central web app."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    override = os.environ.get("RTI_ENV_FILE", "").strip()
    if override:
        candidates = [Path(override).expanduser()]
    else:
        here = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
        candidates = [here / ".env", here.parent / "Web" / ".env"]
    for candidate in candidates:
        if candidate.is_file():
            load_dotenv(candidate)
            return


_load_environment()
BACKEND = (os.environ.get("RTI_LOCAL_BACKEND") or f"http://127.0.0.1:{os.environ.get('RTI_WEB_PORT', '5000').strip() or '5000'}").rstrip("/")
HOST = os.environ.get("RTI_MOBILE_PROXY_HOST", "127.0.0.1").strip() or "127.0.0.1"
PORT = int(os.environ.get("RTI_MOBILE_PROXY_PORT", "5200"))
MAX_BODY = 256 * 1024
MAX_RESPONSE = 1024 * 1024
ALLOWED = {
    ("POST", "/api/mobile/login"),
    ("POST", "/api/mobile/logout"),
    ("POST", "/api/mobile/start-inspection"),
    ("POST", "/api/mobile/end-inspection"),
    ("POST", "/api/mobile/scan"),
    ("POST", "/api/mobile/sync"),
    ("GET", "/api/mobile/state"),
    ("GET", "/api/mobile/health"),
    ("GET", "/api/client/events"),
    ("POST", "/api/client/events"),
    ("GET", "/api/client/bootstrap"),
    ("GET", "/api/client/schedules"),
    ("POST", "/api/client/schedules"),
}
LOGIN_FAILURE_LIMIT = 12
LOGIN_WINDOW_SECONDS = 600
MAX_RATE_LIMIT_USERS = 4096
_failures = defaultdict(deque)
_lock = threading.Lock()


def _reply_json(handler, status, payload):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Connection", "close")
    handler.end_headers()
    handler.wfile.write(body)


class MobileApiProxy(BaseHTTPRequestHandler):
    server_version = "RTIMobileProxy/1.0"

    def log_message(self, fmt, *args):
        # Never log request bodies, passwords, or bearer tokens.
        # The desktop app checks /api/mobile/health every few seconds: successful checks are not worth a log line.
        if args and "/api/mobile/health" in str(args[0]) and len(args) > 1 and str(args[1]) == "200":
            return
        print("[MOBILE-PROXY] " + (fmt % args))

    @staticmethod
    def _login_key(body):
        try:
            payload = json.loads(body or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            return ""
        if not isinstance(payload, dict):
            return ""
        value = payload.get("user_id", payload.get("username", ""))
        return str(value).strip().casefold()[:128]

    def _is_rate_limited(self, key):
        if not key:
            return False
        now = time.monotonic()
        with _lock:
            attempts = _failures.get(key)
            if attempts is None:
                return False
            while attempts and now - attempts[0] > LOGIN_WINDOW_SECONDS:
                attempts.popleft()
            if not attempts:
                _failures.pop(key, None)
                return False
            return len(attempts) >= LOGIN_FAILURE_LIMIT

    def _record_login_result(self, key, status):
        if not key:
            return
        now = time.monotonic()
        with _lock:
            attempts = _failures[key]
            while attempts and now - attempts[0] > LOGIN_WINDOW_SECONDS:
                attempts.popleft()
            if status == 401:
                attempts.append(now)
                if len(_failures) > MAX_RATE_LIMIT_USERS:
                    oldest = min(_failures, key=lambda user: _failures[user][-1] if _failures[user] else float("-inf"))
                    _failures.pop(oldest, None)
            elif 200 <= status < 300:
                _failures.pop(key, None)

    def _handle(self):
        parsed = urlsplit(self.path)
        route = (self.command.upper(), parsed.path)
        dynamic_client_schedule = (
            parsed.path.startswith("/api/client/schedules/")
            and parsed.path.rsplit("/", 1)[-1].isdigit()
            and route[0] in ("PUT", "DELETE")
        )
        if route not in ALLOWED and not dynamic_client_schedule:
            _reply_json(self, 404, {"ok": False, "message": "Endpoint is not exposed by the mobile-only gateway."})
            return

        body = b""
        if self.command.upper() in ("POST", "PUT", "PATCH"):
            try:
                size = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                _reply_json(self, 400, {"ok": False, "message": "Invalid Content-Length."})
                return
            if size < 0 or size > MAX_BODY:
                _reply_json(self, 413, {"ok": False, "message": "Request body is too large."})
                return
            body = self.rfile.read(size) if size else b""

        login_key = self._login_key(body) if route == ("POST", "/api/mobile/login") else ""
        if login_key and self._is_rate_limited(login_key):
            _reply_json(self, 429, {"ok": False, "message": "Too many failed login attempts for this User ID. Wait 10 minutes and try again."})
            return

        headers = {"Accept": "application/json"}
        if self.headers.get("Content-Type"):
            headers["Content-Type"] = self.headers["Content-Type"]
        if self.headers.get("Authorization"):
            headers["Authorization"] = self.headers["Authorization"]
        if self.headers.get("X-RTI-Client-ID"):
            headers["X-RTI-Client-ID"] = self.headers["X-RTI-Client-ID"]

        upstream_url = BACKEND + parsed.path + (("?" + parsed.query) if parsed.query else "")
        request = Request(upstream_url, data=body if self.command.upper() in ("POST", "PUT", "PATCH") else None,
                          headers=headers, method=self.command.upper())
        try:
            with urlopen(request, timeout=20) as response:
                status = response.status
                data = response.read(MAX_RESPONSE + 1)
                content_type = response.headers.get("Content-Type", "application/json; charset=utf-8")
        except HTTPError as exc:
            status = exc.code
            data = exc.read(MAX_RESPONSE + 1)
            content_type = exc.headers.get("Content-Type", "application/json; charset=utf-8") if exc.headers else "application/json; charset=utf-8"
        except (URLError, TimeoutError, OSError) as exc:
            print("[MOBILE-PROXY] Central API unavailable:", type(exc).__name__)
            _reply_json(self, 502, {"ok": False, "message": "Central server is unavailable. Check that port 5000 is running."})
            return

        if len(data) > MAX_RESPONSE:
            _reply_json(self, 502, {"ok": False, "message": "Central API returned an oversized response."})
            return
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)

        if route == ("POST", "/api/mobile/login") and login_key:
            self._record_login_result(login_key, status)

    do_GET = _handle
    do_POST = _handle
    do_PUT = _handle
    do_DELETE = _handle


def main():
    server = ThreadingHTTPServer((HOST, PORT), MobileApiProxy)
    server.daemon_threads = True
    scope = "this PC only (localhost)" if HOST in ("127.0.0.1", "::1", "localhost") else "the local network (LAN) as well"
    print(f"[MOBILE-PROXY] Listening on http://{HOST}:{PORT} - reachable from {scope}")
    print(f"[MOBILE-PROXY] Forwarding allowed mobile API routes to {BACKEND}")
    print("[MOBILE-PROXY] Dashboard/admin pages and other endpoints are blocked.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[MOBILE-PROXY] Stopping...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
