from flask import Blueprint, jsonify, request, redirect, url_for
from datetime import datetime, timedelta, timezone
import hmac, ipaddress, json, os, re, secrets, sqlite3, threading, time
from pathlib import Path
from urllib.parse import urlsplit


def register_v15(app, deps):
    conn = deps["conn"]
    now_str = deps["now_str"]
    get_user = deps["get_user"]
    license_is_active = deps["license_is_active"]
    shell = deps["shell"]
    bp = Blueprint("rti_v15", __name__)

    def server_time_utc():
        return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

    def configured_node_token(company_id, client_id):
        key = f"{company_id}/{client_id}"
        for entry in os.getenv("RTI_CLIENT_NODE_TOKENS", "").split(";"):
            configured, separator, token = entry.partition(":")
            if separator and configured.strip() == key:
                return token.strip()
        return ""

    def configured_company_token(company_id):
        for entry in os.getenv("RTI_CLIENT_SYNC_TOKENS", "").split(";"):
            configured, separator, token = entry.partition(":")
            if separator and configured.strip() == str(company_id):
                return token.strip()
        return ""

    def add_column(c, table, name, declaration):
        columns = {r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}
        if name not in columns:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")

    def migrate():
        c = conn()
        try:
            add_column(c, "scans", "event_id", "TEXT")
            add_column(c, "scans", "offline_session_key", "TEXT")
            add_column(c, "scans", "client_created_at", "TEXT")
            add_column(c, "scans", "server_received_at", "TEXT")
            add_column(c, "scans", "time_source", "TEXT NOT NULL DEFAULT 'SERVER'")
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_scans_event_id ON scans(event_id) WHERE event_id IS NOT NULL AND event_id!=''")
            c.execute("""CREATE TABLE IF NOT EXISTS client_nodes(
                id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL, client_id TEXT NOT NULL,
                display_name TEXT NOT NULL DEFAULT '', schedule_permission INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'ACTIVE', created_at TEXT NOT NULL, last_seen_at TEXT,
                UNIQUE(company_id,client_id), FOREIGN KEY(company_id) REFERENCES companies(id))""")
            c.execute("""CREATE TABLE IF NOT EXISTS schedules(
                id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL, client_id TEXT, name TEXT NOT NULL,
                inspector_id INTEGER, schedule_time TEXT NOT NULL, days TEXT NOT NULL DEFAULT 'MON,TUE,WED,THU,FRI,SAT,SUN',
                grace_minutes INTEGER NOT NULL DEFAULT 15, checkpoint_ids TEXT NOT NULL DEFAULT '[]',
                enabled INTEGER NOT NULL DEFAULT 1, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                FOREIGN KEY(company_id) REFERENCES companies(id), FOREIGN KEY(inspector_id) REFERENCES inspectors(id))""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_schedules_company_enabled ON schedules(company_id,enabled)")
            c.execute("""CREATE TABLE IF NOT EXISTS notifications(
                id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL, kind TEXT NOT NULL,
                title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', source_key TEXT UNIQUE,
                occurred_at TEXT NOT NULL, created_at TEXT NOT NULL, acknowledged_at TEXT,
                FOREIGN KEY(company_id) REFERENCES companies(id))""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_notifications_company_created ON notifications(company_id,id DESC)")
            # Older builds left offline-captured sessions ACTIVE forever; close them once.
            c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=COALESCE(ended_at,started_at) WHERE status='ACTIVE' AND session_token LIKE 'OFF-%'")
            c.commit()
        finally:
            c.close()

    migrate()


    PRIVATE_NAME_SUFFIXES = (".local", ".lan", ".home", ".internal", ".home.arpa", ".localdomain")

    def normalize_origin(raw):
        """https for any host; plain http only for private/LAN hosts. Returns the origin or None."""
        value = str(raw or "").strip().rstrip("/")
        if not value:
            return None
        try:
            parsed = urlsplit(value)
            host = (parsed.hostname or "").lower()
            port = parsed.port
            if (parsed.scheme not in ("http", "https") or not host or parsed.username or parsed.password
                    or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
                return None
        except ValueError:
            return None
        if parsed.scheme == "http":
            try:
                address = ipaddress.ip_address(host)
                private = address.is_private or address.is_loopback or address.is_link_local
            except ValueError:
                private = "." not in host or host.endswith(PRIVATE_NAME_SUFFIXES)
            if not private:
                return None
        shown = f"[{host}]" if ":" in host else host
        return f"{parsed.scheme}://{shown}" + (f":{port}" if port else "")

    def parse_token_map(raw):
        result = {}
        for entry in str(raw or "").split(";"):
            key, separator, value = entry.partition(":")
            if separator and key.strip() and value.strip():
                result[key.strip()] = value.strip()
        return result

    def persist_environment(values):
        """Write KEY=value pairs into the Central .env (atomic) and apply them to this running process."""
        path = Path(deps["env_file"]()) if deps.get("env_file") else None
        if path is None:
            raise OSError("No Central configuration file is available")
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
        remaining = dict(values)
        output = []
        for line in lines:
            key, separator, _ = line.partition("=")
            if separator and key.strip() in remaining:
                output.append(f"{key.strip()}={remaining.pop(key.strip())}")
            else:
                output.append(line)
        for key, value in remaining.items():
            output.append(f"{key}={value}")
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
        if os.name != "nt":
            temporary.chmod(0o600)
        temporary.replace(path)
        for key, value in values.items():
            os.environ[key] = value

    def actor():
        user = get_user()
        if not user:
            return None, (jsonify(ok=False, message="Login required"), 401)
        if user.get("must_change_password"):
            return None, (jsonify(ok=False, message="Change the first-run password before using the application."), 403)
        return user, None

    def super_admin():
        user, error = actor()
        if error:
            return None, error
        if user.get("role") != "SUPER_ADMIN":
            return None, (jsonify(ok=False, message="Super Admin access required"), 403)
        return user, None

    def parse_company_client(c, *, token_kind="node", payload=None, query=True, require_permission=False):
        payload = payload or {}
        company_value = payload.get("company_id") if payload else None
        if query:
            company_value = company_value or request.args.get("company_id")
        client_id = (payload.get("client_id") if payload else None) or request.headers.get("X-RTI-Client-ID", "")
        if query:
            client_id = client_id or request.args.get("client_id", "")
        try:
            company_id = int(company_value)
        except (TypeError, ValueError):
            return None, (jsonify(ok=False, message="A numeric company_id is required"), 400)
        client_id = str(client_id or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", client_id):
            return None, (jsonify(ok=False, message="A valid client_id is required"), 400)
        expected = configured_node_token(company_id, client_id) if token_kind == "node" else configured_company_token(company_id)
        scheme, sep, supplied = request.headers.get("Authorization", "").partition(" ")
        if not expected or not sep or scheme.lower() != "bearer" or not hmac.compare_digest(supplied.strip(), expected):
            return None, (jsonify(ok=False, message="Client authentication failed"), 401)
        company = c.execute("SELECT id,name,status FROM companies WHERE id=?", (company_id,)).fetchone()
        if not company or company["status"] != "ACTIVE":
            return None, (jsonify(ok=False, message="Company is not active"), 403)
        node = c.execute("SELECT * FROM client_nodes WHERE company_id=? AND client_id=?", (company_id, client_id)).fetchone()
        if not node:
            stamp = now_str()
            c.execute("INSERT INTO client_nodes(company_id,client_id,display_name,schedule_permission,status,created_at,last_seen_at) VALUES(?,?,?,?,?,?,?)",
                      (company_id, client_id, client_id, 0, "ACTIVE", stamp, stamp))
            c.commit()
            node = c.execute("SELECT * FROM client_nodes WHERE company_id=? AND client_id=?", (company_id, client_id)).fetchone()
        elif node["status"] != "ACTIVE":
            return None, (jsonify(ok=False, message="Client PC is disabled"), 403)
        else:
            c.execute("UPDATE client_nodes SET last_seen_at=? WHERE id=?", (now_str(), node["id"]))
            c.commit()
        if require_permission and not node["schedule_permission"]:
            return None, (jsonify(ok=False, message="Super Admin has not granted schedule permission to this Client PC"), 403)
        return {"company_id": company_id, "client_id": client_id, "company_name": company["name"], "node": dict(node)}, None

    def schedule_payload(d, company_id, client_id=None, current=None):
        d = d or {}
        name = str(d.get("name", current["name"] if current else "")).strip()[:120]
        schedule_time = str(d.get("schedule_time", current["schedule_time"] if current else "")).strip()
        days_raw = d.get("days", None)
        if days_raw is None:
            days = (current["days"].split(",") if current else ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"])
        elif isinstance(days_raw, str):
            days = days_raw.split(",")
        elif isinstance(days_raw, list):
            days = days_raw
        else:
            days = []
        days = sorted({str(item).strip().upper()[:3] for item in days if str(item).strip()})
        allowed = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"}
        try:
            grace = int(d.get("grace_minutes", current["grace_minutes"] if current else 15))
        except (TypeError, ValueError):
            grace = -1
        checkpoint_ids = d.get("checkpoint_ids", None)
        if checkpoint_ids is None:
            checkpoints = json.loads(current["checkpoint_ids"] or "[]") if current else []
        elif isinstance(checkpoint_ids, list):
            checkpoints = [int(value) for value in checkpoint_ids if str(value).isdigit()]
        elif checkpoint_ids in ("", "ALL", "all"):
            checkpoints = []
        else:
            checkpoints = []
        inspector_id = d.get("inspector_id", current["inspector_id"] if current else None)
        inspector_id = int(inspector_id) if str(inspector_id or "").isdigit() else None
        enabled = 1 if str(d.get("enabled", current["enabled"] if current else 1)).lower() not in ("false", "0", "off", "no") else 0
        if not name or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", schedule_time):
            return None, "Schedule name and 24-hour time are required"
        if not days or set(days) - allowed or grace < 0 or grace > 1440:
            return None, "Choose valid weekdays and a grace period from 0 to 1440 minutes"
        return {"company_id": company_id, "client_id": client_id, "name": name, "inspector_id": inspector_id,
                "schedule_time": schedule_time, "days": ",".join(days), "grace_minutes": grace,
                "checkpoint_ids": json.dumps(sorted(set(checkpoints))), "enabled": enabled}, None

    def serialize_schedule(row):
        item = dict(row)
        try:
            item["days"] = item["days"].split(",")
            item["checkpoint_ids"] = json.loads(item["checkpoint_ids"] or "[]")
        except (AttributeError, json.JSONDecodeError):
            item["days"], item["checkpoint_ids"] = [], []
        return item

    def validate_schedule_refs(c, item):
        if item["inspector_id"] and not c.execute(
            "SELECT id FROM inspectors WHERE id=? AND company_id=? AND status='ACTIVE'",
            (item["inspector_id"], item["company_id"])
        ).fetchone():
            return "Inspector is not active in this company"
        ids = json.loads(item["checkpoint_ids"] or "[]")
        if ids:
            marks = ",".join("?" for _ in ids)
            count = c.execute(
                f"SELECT COUNT(*) n FROM points WHERE company_id=? AND status='ACTIVE' AND id IN ({marks})",
                [item["company_id"], *ids]
            ).fetchone()["n"]
            if count != len(set(ids)):
                return "Every selected checkpoint must be active in this company"
        return None

    def notify(c, company_id, kind, title, body, source_key):
        stamp = now_str()
        c.execute("INSERT OR IGNORE INTO notifications(company_id,kind,title,body,source_key,occurred_at,created_at) VALUES(?,?,?,?,?,?,?)",
                  (company_id, kind, title, body, source_key, stamp, stamp))

    def generate_schedule_alerts(c):
        now = datetime.now()
        rows = c.execute("SELECT * FROM schedules WHERE enabled=1").fetchall()
        for row in rows:
            try:
                selected_points = json.loads(row["checkpoint_ids"] or "[]")
            except (TypeError, ValueError):
                selected_points = []
            try:
                hour, minute = map(int, row["schedule_time"].split(":"))
            except (TypeError, ValueError):
                continue
            # A schedule must never raise alerts for occurrences that happened before it
            # was created or last edited (otherwise a new schedule instantly reports a week of "missed").
            baseline = None
            for stamp_column in ("updated_at", "created_at"):
                try:
                    baseline = datetime.strptime(str(row[stamp_column])[:19], "%Y-%m-%d %H:%M:%S")
                    break
                except (TypeError, ValueError, IndexError):
                    continue
            for days_ago in range(0, 8):
                occurrence_date = (now - timedelta(days=days_ago)).date()
                day = occurrence_date.strftime("%a").upper()[:3]
                if day not in (row["days"] or "").split(","):
                    continue
                scheduled = datetime.combine(occurrence_date, datetime.min.time()).replace(hour=hour, minute=minute)
                diff = (now - scheduled).total_seconds() / 60
                day_key = scheduled.strftime("%Y-%m-%d")
                if diff < -5:
                    continue
                if baseline is not None and scheduled < baseline:
                    continue
                point_ids = selected_points or [r["id"] for r in c.execute(
                    "SELECT id FROM points WHERE company_id=? AND status='ACTIVE'", (row["company_id"],)).fetchall()]
                if not point_ids:
                    continue
                sessions = c.execute("""SELECT * FROM inspection_sessions WHERE company_id=? AND schedule_id=? AND started_at>=? AND started_at<=?
                    AND (? IS NULL OR inspector_id=?) ORDER BY id""",
                    (row["company_id"], row["id"], (scheduled - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S"),
                     (scheduled + timedelta(minutes=row["grace_minutes"])).strftime("%Y-%m-%d %H:%M:%S"),
                     row["inspector_id"], row["inspector_id"])).fetchall()
                completed = False
                for session in sessions:
                    scanned = {r["point_id"] for r in c.execute(
                        "SELECT DISTINCT point_id FROM scans WHERE inspection_session_id=? AND result='ACCEPTED'",
                        (session["id"],)).fetchall()}
                    if point_ids and set(point_ids).issubset(scanned):
                        completed = True
                        break
                if completed:
                    notify(c, row["company_id"], "INSPECTION_COMPLETED", "Scheduled inspection completed",
                           f"{row['name']} was completed for {day_key}", f"schedule:{row['id']}:{day_key}:COMPLETED")
                elif diff <= 0:
                    notify(c, row["company_id"], "INSPECTION_DUE", "Inspection due soon",
                           f"{row['name']} starts at {row['schedule_time']}", f"schedule:{row['id']}:{day_key}:DUE")
                elif diff <= row["grace_minutes"]:
                    notify(c, row["company_id"], "INSPECTION_LATE", "Inspection is late",
                           f"{row['name']} has not been completed yet", f"schedule:{row['id']}:{day_key}:LATE")
                else:
                    notify(c, row["company_id"], "INSPECTION_MISSED", "Inspection missed",
                           f"{row['name']} passed its grace period on {day_key}", f"schedule:{row['id']}:{day_key}:MISSED")
        stale_before = (now - timedelta(minutes=2)).strftime("%Y-%m-%d %H:%M:%S")
        offline_rows = c.execute("""SELECT ms.id,ms.company_id,ms.device_id,ms.last_seen,i.name inspector_name
            FROM mobile_sessions ms LEFT JOIN inspectors i ON i.id=ms.inspector_id
            WHERE ms.status='ACTIVE' AND ms.last_seen<?""", (stale_before,)).fetchall()
        for device in offline_rows:
            notify(c, device["company_id"], "DEVICE_OFFLINE", "Inspector device offline",
                   f"{device['inspector_name'] or 'Inspector'} · {device['device_id']} has not checked in for two minutes",
                   f"mobile-session:{device['id']}:OFFLINE:{device['last_seen']}")
        c.commit()

    def ingest_event(c, company_id, event, mobile_user=None):
        if not isinstance(event, dict):
            return {"ok": False, "message": "Each event must be an object"}
        event_id = str(event.get("event_id", "")).strip()
        qr_token = str(event.get("qr_token", "")).strip()
        device_id = str(event.get("device_id", "")).strip()[:128]
        session_key = str(event.get("offline_session_key", event.get("inspection_session_key", ""))).strip()[:128]
        created_at = str(event.get("client_created_at", event.get("scan_time", ""))).strip()[:40]
        inspection_type = str(event.get("inspection_type", "MANUAL")).strip().upper()
        if inspection_type not in ("MANUAL", "SCHEDULED"):
            inspection_type = "MANUAL"
        try:
            schedule_id = int(event.get("schedule_id")) if event.get("schedule_id") not in (None, "", 0, "0") else None
        except (TypeError, ValueError):
            schedule_id = None
        schedule_name = str(event.get("schedule_name", "")).strip()[:120]
        try:
            checkpoint_ids = sorted(set(int(value) for value in event.get("checkpoint_ids", []) if str(value).isdigit()))
        except (TypeError, ValueError):
            checkpoint_ids = []
        if not checkpoint_ids and schedule_id:
            schedule = c.execute("SELECT name,checkpoint_ids FROM schedules WHERE id=? AND company_id=?", (schedule_id, company_id)).fetchone()
            if schedule:
                schedule_name = schedule_name or schedule["name"]
                try: checkpoint_ids = sorted(set(int(value) for value in json.loads(schedule["checkpoint_ids"] or "[]")))
                except (TypeError, ValueError, json.JSONDecodeError): checkpoint_ids=[]
        try:
            inspector_id = int(event.get("inspector_record_id", 0))
        except (TypeError, ValueError):
            inspector_id = 0
        if not re.fullmatch(r"[A-Za-z0-9_.:-]{8,128}", event_id) or not qr_token or not device_id or not session_key or not created_at or inspector_id <= 0:
            return {"ok": False, "event_id": event_id, "message": "Event ID, QR token, device, inspector and timestamps are required"}
        try:
            datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return {"ok": False, "event_id": event_id, "message": "Client timestamp must use YYYY-MM-DD HH:MM:SS"}
        duplicate = c.execute("SELECT id,result,point_code,scan_time FROM scans WHERE event_id=?", (event_id,)).fetchone()
        if duplicate:
            return {"ok": True, "duplicate": True, "event_id": event_id, "result": duplicate["result"], "point_code": duplicate["point_code"]}
        inspector = c.execute("SELECT id,company_id,name,status FROM inspectors WHERE id=?", (inspector_id,)).fetchone()
        if not inspector or inspector["company_id"] != company_id or inspector["status"] != "ACTIVE":
            return {"ok": False, "event_id": event_id, "message": "Inspector is inactive or belongs to another company"}
        if mobile_user and (mobile_user.get("company_id") != company_id or mobile_user.get("inspector_id") != inspector_id):
            return {"ok": False, "event_id": event_id, "message": "Event does not match the authenticated inspector"}
        point = c.execute("SELECT id,point_code,name FROM points WHERE qr_token=? AND company_id=? AND status='ACTIVE'", (qr_token, company_id)).fetchone()
        if not point:
            return {"ok": False, "event_id": event_id, "message": "QR code is invalid or belongs to another company"}
        count = c.execute("SELECT COUNT(*) n FROM scans WHERE company_id=? AND point_id=? AND offline_session_key=? AND result IN ('ACCEPTED','REPEAT')",
                          (company_id, point["id"], session_key)).fetchone()["n"]
        max_repeats = max(0, int(deps.get("max_repeats", 1)))
        result = "REPEAT_ALERT" if count >= max_repeats + 1 else ("ACCEPTED" if count == 0 else "REPEAT")
        stamp = now_str()
        session = c.execute("SELECT id,company_id,inspector_id,device_id,inspection_type,schedule_id,schedule_name,checkpoint_ids FROM inspection_sessions WHERE session_token=?",
                            (session_key,)).fetchone()
        if session:
            if (session["company_id"] != company_id or session["inspector_id"] != inspector_id
                    or session["device_id"] != device_id):
                return {"ok": False, "event_id": event_id, "message": "Inspection session does not match this company, inspector and device"}
            inspection_session_id = session["id"]
        else:
            try:
                # A session that Central never started (offline/LAN capture) is history, not a live
                # session: leaving it ACTIVE made /api/mobile/state hand a stale OFF-* session to the phone.
                c.execute("INSERT INTO inspection_sessions(session_token,company_id,inspector_id,device_id,started_at,ended_at,status,inspection_type,schedule_id,schedule_name,scheduled_for,checkpoint_ids) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                          (session_key, company_id, inspector_id, device_id, created_at, stamp, "ENDED",inspection_type,schedule_id,schedule_name,created_at[:10] if schedule_id else "",json.dumps(checkpoint_ids)))
            except sqlite3.IntegrityError:
                session = c.execute("SELECT id,company_id,inspector_id,device_id,inspection_type,schedule_id,schedule_name,checkpoint_ids FROM inspection_sessions WHERE session_token=?",
                                    (session_key,)).fetchone()
                if (not session or session["company_id"] != company_id or session["inspector_id"] != inspector_id
                        or session["device_id"] != device_id):
                    raise
            inspection_session_id = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            if session:
                inspection_session_id = session["id"]
        if result == "ACCEPTED":
            gap_seconds = deps.get("minimum_point_gap", lambda _c: 0)(c)
            last = c.execute("SELECT COALESCE(NULLIF(client_created_at,''),scan_time) last_time FROM scans WHERE inspection_session_id=? AND result='ACCEPTED' ORDER BY id DESC LIMIT 1", (inspection_session_id,)).fetchone()
            if gap_seconds and last:
                try:
                    elapsed=(datetime.strptime(created_at,"%Y-%m-%d %H:%M:%S")-datetime.strptime(last["last_time"],"%Y-%m-%d %H:%M:%S")).total_seconds()
                    if elapsed < gap_seconds:
                        result="TOO_FAST"
                except ValueError:
                    result="TOO_FAST"
        session = c.execute("SELECT inspection_type,schedule_id,schedule_name,checkpoint_ids FROM inspection_sessions WHERE id=?",(inspection_session_id,)).fetchone()
        effective_type=session["inspection_type"] or inspection_type
        effective_schedule_id=session["schedule_id"]
        effective_schedule_name=session["schedule_name"] or schedule_name
        try: effective_checkpoint_ids=sorted(set(int(value) for value in json.loads(session["checkpoint_ids"] or "[]")))
        except (TypeError,ValueError,json.JSONDecodeError): effective_checkpoint_ids=[]
        if effective_checkpoint_ids and point["id"] not in effective_checkpoint_ids:
            return {"ok": False, "event_id": event_id, "message": "Checkpoint is not assigned to this inspection schedule"}
        offline_queue=bool(event.get("offline_queue")) or session_key.startswith("OFF-")
        sync_source="OFFLINE_QUEUE" if offline_queue else "LIVE"
        try:
            c.execute("""INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,
                scan_time,result,inspection_session_id,repeat_count,event_id,offline_session_key,client_created_at,server_received_at,time_source,sync_source)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (company_id, point["id"], point["point_code"], inspector_id, inspector["name"], device_id,
                 created_at, result, inspection_session_id, count, event_id, session_key, created_at, stamp, "DEVICE",sync_source))
        except sqlite3.IntegrityError:
            duplicate = c.execute("SELECT result,point_code FROM scans WHERE event_id=?", (event_id,)).fetchone()
            if duplicate:
                return {"ok": True, "duplicate": True, "event_id": event_id, "result": duplicate["result"], "point_code": duplicate["point_code"]}
            raise
        notify(c, company_id, "INSPECTION_SCAN", "Inspection scan received",
               f"{inspector['name']} scanned {point['point_code']} at {created_at}; server received it at {stamp}", f"scan:{event_id}")
        prior_session = c.execute("SELECT COUNT(*) n FROM scans WHERE offline_session_key=? AND event_id<>?", (session_key, event_id)).fetchone()["n"]
        if prior_session == 0:
            notify(c, company_id, "INSPECTION_STARTED", "Inspection started", f"{inspector['name']} began an inspection on {device_id}", f"session:{session_key}:STARTED")
        total = len(effective_checkpoint_ids) if effective_checkpoint_ids else c.execute("SELECT COUNT(*) n FROM points WHERE company_id=? AND status='ACTIVE'", (company_id,)).fetchone()["n"]
        scanned = c.execute("SELECT COUNT(DISTINCT point_id) n FROM scans WHERE company_id=? AND offline_session_key=? AND result='ACCEPTED'", (company_id, session_key)).fetchone()["n"]
        if effective_checkpoint_ids:
            marks=",".join("?" for _ in effective_checkpoint_ids)
            scanned=c.execute(f"SELECT COUNT(DISTINCT point_id) n FROM scans WHERE inspection_session_id=? AND result='ACCEPTED' AND point_id IN ({marks})",(inspection_session_id,*effective_checkpoint_ids)).fetchone()["n"]
        complete=bool(total and scanned>=total)
        if complete:
            notify(c, company_id, "INSPECTION_COMPLETED", "Inspection completed", f"{inspector['name']} completed all active checkpoints", f"session:{session_key}:COMPLETED")
            c.execute("UPDATE inspection_sessions SET status='COMPLETED',ended_at=? WHERE id=?", (stamp, inspection_session_id))
        return {"ok": True, "duplicate": False, "event_id": event_id, "result": result, "point_code": point["point_code"],
                "point_name": point["name"], "client_created_at": created_at, "server_received_at": stamp, "time_source": "DEVICE",
                "inspection_type":effective_type,"schedule_id":effective_schedule_id,"schedule_name":effective_schedule_name,
                "sync_source":sync_source,"inspection_complete":complete,"scanned_points":scanned,"total_points":total}

    @bp.get("/schedules")
    def schedules_page():
        user = get_user()
        if not user:
            return redirect(url_for("login"))
        if user.get("role") != "SUPER_ADMIN":
            return "Super Admin access required", 403
        return shell("Schedules & Client Access", ADMIN_SCHEDULES_BODY, user, "schedules")

    @bp.get("/api/admin/client-nodes")
    def admin_client_nodes():
        user, error = super_admin()
        if error:
            return error
        c = conn()
        try:
            rows = c.execute("""SELECT n.*,co.name company_name FROM client_nodes n JOIN companies co ON co.id=n.company_id
                WHERE co.status='ACTIVE' ORDER BY co.name,n.client_id""").fetchall()
            return jsonify([dict(row) for row in rows])
        finally:
            c.close()

    @bp.post("/api/admin/client-pairing")
    def admin_client_pairing():
        """Register a Client PC and return its private pairing file (tokens are shown only in this response)."""
        user, error = super_admin()
        if error:
            return error
        data = request.get_json(silent=True) or {}
        company_id = str(data.get("company_id", "")).strip()
        client_id = str(data.get("client_id", "")).strip()
        if not company_id.isdigit():
            return jsonify(ok=False, message="Choose the company"), 400
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", client_id):
            return jsonify(ok=False, message="Client PC ID may contain letters, numbers, dot, underscore and hyphen only (copy it from the Client PC setup page)"), 400
        raw_online = str(data.get("central_url", "")).strip()
        online = normalize_origin(raw_online) if raw_online else ""
        raw_lan = str(data.get("central_lan_url", "")).strip()
        lan = normalize_origin(raw_lan) if raw_lan else ""
        if online is None:
            return jsonify(ok=False, message="Online address must be https://your-domain (http works only for private LAN addresses)"), 400
        if lan is None:
            return jsonify(ok=False, message="LAN address must be a private network address such as http://192.168.1.10:5200"), 400
        if not online and not lan:
            return jsonify(ok=False, message="Enter the online address and/or the LAN address that this Client PC should use"), 400
        c = conn()
        try:
            company = c.execute("SELECT id,name,status FROM companies WHERE id=?", (int(company_id),)).fetchone()
        finally:
            c.close()
        if not company or company["status"] != "ACTIVE":
            return jsonify(ok=False, message="Company was not found or is not active"), 404
        sync_map = parse_token_map(os.getenv("RTI_CLIENT_SYNC_TOKENS", ""))
        node_map = parse_token_map(os.getenv("RTI_CLIENT_NODE_TOKENS", ""))
        placeholder = ("CHANGE-TO-A-LONG-RANDOM-SYNC-TOKEN", "CHANGE-TO-A-LONG-RANDOM-NODE-TOKEN")
        sync_token = sync_map.get(company_id, "")
        if not sync_token or sync_token in placeholder:
            sync_token = secrets.token_urlsafe(48)
            sync_map[company_id] = sync_token
        node_key = f"{company_id}/{client_id}"
        node_token = node_map.get(node_key, "")
        if not node_token or node_token in placeholder:
            node_token = secrets.token_urlsafe(48)
            node_map[node_key] = node_token
        try:
            persist_environment({
                "RTI_CLIENT_SYNC_TOKENS": ";".join(f"{k}:{sync_map[k]}" for k in sorted(sync_map)),
                "RTI_CLIENT_NODE_TOKENS": ";".join(f"{k}:{node_map[k]}" for k in sorted(node_map)),
            })
        except OSError as exc:
            return jsonify(ok=False, message="Could not save the Client PC credentials to the Central configuration file: " + str(exc)), 500
        deps["audit"](user["id"], int(company_id), "CLIENT_PAIRING", "CLIENT_PC", node_key, "Pairing file created")
        response = jsonify(ok=True, pairing={
            "format": "rti-client-pairing-v1", "central_url": online or lan, "central_lan_url": lan if online else "",
            "company_id": company_id, "client_id": client_id,
            "client_sync_token": sync_token, "client_node_token": node_token,
        }, company_name=company["name"])
        response.headers["Cache-Control"] = "no-store"
        return response

    @bp.put("/api/admin/client-nodes/<int:node_id>/permission")
    def admin_node_permission(node_id):
        user, error = super_admin()
        if error:
            return error
        data = request.get_json(silent=True) or {}
        allowed = 1 if data.get("schedule_permission") is True else 0
        c = conn()
        try:
            row = c.execute("SELECT * FROM client_nodes WHERE id=?", (node_id,)).fetchone()
            if not row:
                return jsonify(ok=False, message="Client PC not found"), 404
            c.execute("UPDATE client_nodes SET schedule_permission=? WHERE id=?", (allowed, node_id))
            c.commit()
        finally:
            c.close()
        deps["audit"](user["id"], row["company_id"], "SCHEDULE_PERMISSION", "CLIENT_PC", node_id, "Schedule permission " + ("granted" if allowed else "revoked"))
        return jsonify(ok=True, schedule_permission=bool(allowed))

    @bp.put("/api/admin/client-nodes/<int:node_id>")
    def admin_node_update(node_id):
        user, error = super_admin()
        if error:
            return error
        data = request.get_json(silent=True) or {}
        c = conn()
        try:
            row = c.execute("SELECT * FROM client_nodes WHERE id=?", (node_id,)).fetchone()
            if not row:
                return jsonify(ok=False, message="Client PC not found"), 404
            display_name = str(data.get("display_name", row["display_name"] or row["client_id"])).strip()
            status = str(data.get("status", row["status"])).strip().upper()
            if not display_name or len(display_name) > 100:
                return jsonify(ok=False, message="Client PC name must contain 1 to 100 characters"), 400
            if status not in ("ACTIVE", "DISABLED"):
                return jsonify(ok=False, message="Client PC status must be ACTIVE or DISABLED"), 400
            c.execute("UPDATE client_nodes SET display_name=?,status=? WHERE id=?", (display_name, status, node_id))
            c.commit()
        finally:
            c.close()
        action = "BLOCK" if status == "DISABLED" else "UPDATE"
        deps["audit"](user["id"], row["company_id"], action, "CLIENT_PC", node_id,
                      f"Client PC {row['client_id']} {('blocked' if status == 'DISABLED' else 'enabled')}; name={display_name}")
        return jsonify(ok=True, display_name=display_name, status=status,
                       message="Client PC blocked" if status == "DISABLED" else "Client PC settings saved")

    @bp.route("/api/schedules", methods=["GET", "POST"])
    def admin_schedules():
        user, error = super_admin()
        if error:
            return error
        c = conn()
        try:
            if request.method == "GET":
                company_id = request.args.get("company_id", type=int)
                query = "SELECT s.*,co.name company_name FROM schedules s JOIN companies co ON co.id=s.company_id"
                args = []
                if company_id:
                    query += " WHERE s.company_id=?"; args.append(company_id)
                rows = c.execute(query + " ORDER BY s.company_id,s.schedule_time,s.id", args).fetchall()
                return jsonify([serialize_schedule(row) for row in rows])
            data = request.get_json(silent=True) or {}
            try:
                company_id = int(data.get("company_id"))
            except (TypeError, ValueError):
                return jsonify(ok=False, message="Company is required"), 400
            client_id = str(data.get("client_id", "")).strip() or None
            normalized, error_message = schedule_payload(data, company_id, client_id)
            if error_message:
                return jsonify(ok=False, message=error_message), 400
            if not c.execute("SELECT id FROM companies WHERE id=? AND status='ACTIVE'", (company_id,)).fetchone():
                return jsonify(ok=False, message="Company is not active"), 404
            reference_error = validate_schedule_refs(c, normalized)
            if reference_error:
                return jsonify(ok=False, message=reference_error), 400
            if client_id and not c.execute("SELECT id FROM client_nodes WHERE company_id=? AND client_id=? AND status='ACTIVE'", (company_id, client_id)).fetchone():
                return jsonify(ok=False, message="Client PC must connect once before a schedule can be assigned to it"), 400
            stamp = now_str()
            normalized.update(created_by=user["id"], created_at=stamp, updated_at=stamp)
            columns = ",".join(normalized.keys()); marks = ",".join("?" for _ in normalized)
            c.execute(f"INSERT INTO schedules({columns}) VALUES({marks})", tuple(normalized.values()))
            schedule_id = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            c.commit()
            deps["audit"](user["id"], company_id, "CREATE", "SCHEDULE", schedule_id, normalized["name"])
            return jsonify(ok=True, id=schedule_id), 201
        finally:
            c.close()

    @bp.put("/api/schedules/<int:schedule_id>")
    def admin_schedule_update(schedule_id):
        user, error = super_admin()
        if error:
            return error
        data = request.get_json(silent=True) or {}
        c = conn()
        try:
            row = c.execute("SELECT * FROM schedules WHERE id=?", (schedule_id,)).fetchone()
            if not row:
                return jsonify(ok=False, message="Schedule not found"), 404
            normalized, error_message = schedule_payload(data, row["company_id"], row["client_id"], row)
            if error_message:
                return jsonify(ok=False, message=error_message), 400
            reference_error = validate_schedule_refs(c, normalized)
            if reference_error:
                return jsonify(ok=False, message=reference_error), 400
            normalized["updated_at"] = now_str()
            c.execute("UPDATE schedules SET name=?,inspector_id=?,schedule_time=?,days=?,grace_minutes=?,checkpoint_ids=?,enabled=?,updated_at=? WHERE id=?",
                      (normalized["name"], normalized["inspector_id"], normalized["schedule_time"], normalized["days"], normalized["grace_minutes"], normalized["checkpoint_ids"], normalized["enabled"], normalized["updated_at"], schedule_id))
            c.commit()
            deps["audit"](user["id"], row["company_id"], "UPDATE", "SCHEDULE", schedule_id, row["name"])
            return jsonify(ok=True)
        finally:
            c.close()

    @bp.delete("/api/schedules/<int:schedule_id>")
    def admin_schedule_delete(schedule_id):
        user, error = super_admin()
        if error:
            return error
        c = conn()
        try:
            row = c.execute("SELECT * FROM schedules WHERE id=?", (schedule_id,)).fetchone()
            if not row:
                return jsonify(ok=False, message="Schedule not found"), 404
            c.execute("DELETE FROM schedules WHERE id=?", (schedule_id,)); c.commit()
            deps["audit"](user["id"], row["company_id"], "DELETE", "SCHEDULE", schedule_id, row["name"])
            return jsonify(ok=True)
        finally:
            c.close()

    @bp.get("/api/notifications")
    def api_notifications():
        user, error = actor()
        if error:
            return error
        c = conn()
        try:
            generate_schedule_alerts(c)
            after_id = max(0, request.args.get("after_id", 0, type=int))
            if user["role"] == "SUPER_ADMIN":
                rows = c.execute("SELECT n.*,co.name company_name FROM notifications n JOIN companies co ON co.id=n.company_id WHERE n.id>? ORDER BY n.id DESC LIMIT 100", (after_id,)).fetchall()
            else:
                rows = c.execute("SELECT n.*,co.name company_name FROM notifications n JOIN companies co ON co.id=n.company_id WHERE n.company_id=? AND n.id>? ORDER BY n.id DESC LIMIT 100", (user["company_id"], after_id)).fetchall()
            return jsonify(ok=True, server_time_utc=server_time_utc(), notifications=[dict(row) for row in rows])
        finally:
            c.close()

    @bp.get("/api/client/bootstrap")
    def api_client_bootstrap():
        c = conn()
        try:
            identity, error = parse_company_client(c)
            if error:
                return error
            cid, client_id = identity["company_id"], identity["client_id"]
            points = [dict(r) for r in c.execute("SELECT id,point_code,name,location,qr_token FROM points WHERE company_id=? AND status='ACTIVE' ORDER BY id", (cid,)).fetchall()]
            schedules = [serialize_schedule(r) for r in c.execute("SELECT * FROM schedules WHERE company_id=? AND enabled=1 AND (client_id IS NULL OR client_id=?) ORDER BY schedule_time,id", (cid, client_id)).fetchall()]
            return jsonify(ok=True, company_id=cid, company_name=identity["company_name"], client_id=client_id,
                           schedule_permission=bool(identity["node"]["schedule_permission"]), points=points, schedules=schedules,
                           server_time_utc=server_time_utc())
        finally:
            c.close()

    @bp.route("/api/client/schedules", methods=["GET", "POST"])
    def api_client_schedules():
        data = request.get_json(silent=True) or {}
        c = conn()
        try:
            identity, error = parse_company_client(c, payload=data, require_permission=request.method == "POST")
            if error:
                return error
            cid, client_id = identity["company_id"], identity["client_id"]
            if request.method == "GET":
                rows = c.execute("SELECT * FROM schedules WHERE company_id=? AND (client_id IS NULL OR client_id=?) ORDER BY schedule_time,id", (cid, client_id)).fetchall()
                return jsonify(ok=True, schedule_permission=bool(identity["node"]["schedule_permission"]), schedules=[serialize_schedule(r) for r in rows])
            normalized, error_message = schedule_payload(data, cid, client_id)
            if error_message:
                return jsonify(ok=False, message=error_message), 400
            reference_error = validate_schedule_refs(c, normalized)
            if reference_error:
                return jsonify(ok=False, message=reference_error), 400
            stamp = now_str(); normalized.update(created_by=None, created_at=stamp, updated_at=stamp)
            columns = ",".join(normalized.keys()); marks = ",".join("?" for _ in normalized)
            c.execute(f"INSERT INTO schedules({columns}) VALUES({marks})", tuple(normalized.values()))
            schedule_id = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            c.commit()
            return jsonify(ok=True, id=schedule_id, schedule=serialize_schedule(c.execute("SELECT * FROM schedules WHERE id=?", (schedule_id,)).fetchone())), 201
        finally:
            c.close()

    @bp.route("/api/client/schedules/<int:schedule_id>", methods=["PUT", "DELETE"])
    def api_client_schedule_item(schedule_id):
        data = request.get_json(silent=True) or {}
        c = conn()
        try:
            identity, error = parse_company_client(c, payload=data, require_permission=True)
            if error:
                return error
            row = c.execute("SELECT * FROM schedules WHERE id=? AND company_id=? AND client_id=?", (schedule_id, identity["company_id"], identity["client_id"])).fetchone()
            if not row:
                return jsonify(ok=False, message="Client schedule not found"), 404
            if request.method == "DELETE":
                c.execute("DELETE FROM schedules WHERE id=?", (schedule_id,)); c.commit(); return jsonify(ok=True)
            normalized, error_message = schedule_payload(data, identity["company_id"], identity["client_id"], row)
            if error_message:
                return jsonify(ok=False, message=error_message), 400
            reference_error = validate_schedule_refs(c, normalized)
            if reference_error:
                return jsonify(ok=False, message=reference_error), 400
            c.execute("UPDATE schedules SET name=?,inspector_id=?,schedule_time=?,days=?,grace_minutes=?,checkpoint_ids=?,enabled=?,updated_at=? WHERE id=?",
                      (normalized["name"], normalized["inspector_id"], normalized["schedule_time"], normalized["days"], normalized["grace_minutes"], normalized["checkpoint_ids"], normalized["enabled"], now_str(), schedule_id))
            c.commit(); return jsonify(ok=True)
        finally:
            c.close()

    @bp.post("/api/client/events")
    def api_client_event_upload():
        data = request.get_json(silent=True) or {}
        c = conn()
        try:
            identity, error = parse_company_client(c, payload=data, token_kind="node")
            if error:
                return error
            events = data.get("events")
            if not isinstance(events, list) or len(events) > 100:
                return jsonify(ok=False, message="events must contain at most 100 records"), 400
            accepted, rejected = [], []
            c.execute("BEGIN IMMEDIATE")
            for event in events:
                c.execute("SAVEPOINT event_ingest")
                result = ingest_event(c, identity["company_id"], event)
                if result.get("ok"):
                    c.execute("RELEASE event_ingest"); accepted.append(result)
                else:
                    c.execute("ROLLBACK TO event_ingest"); c.execute("RELEASE event_ingest"); rejected.append(result)
            new_count = sum(1 for item in accepted if not item.get("duplicate"))
            if new_count:
                notify(c, identity["company_id"], "SYNC_RECOVERED", "Offline records synchronized", f"{new_count} offline record(s) reached the central server", f"sync:{identity['client_id']}:{now_str()}")
            c.commit()
            return jsonify(ok=True,accepted=accepted,rejected=rejected,server_time_utc=server_time_utc())
        finally:
            c.close()

    @bp.post("/api/mobile/sync")
    def api_mobile_sync():
        mobile_user = deps["mobile_auth"]()
        if not mobile_user:
            return jsonify(ok=False, message="Login required"), 401
        if not license_is_active(mobile_user["company_id"]):
            return jsonify(ok=False, message="Company license is not active"), 403
        data = request.get_json(silent=True) or {}
        events = data.get("events")
        if not isinstance(events, list) or len(events) > 100:
            return jsonify(ok=False, message="events must contain at most 100 records"), 400
        c = conn()
        try:
            accepted, rejected = [], []
            c.execute("BEGIN IMMEDIATE")
            for event in events:
                c.execute("SAVEPOINT mobile_event_ingest")
                result = ingest_event(c, mobile_user["company_id"], event, mobile_user)
                if result.get("ok"):
                    c.execute("RELEASE mobile_event_ingest"); accepted.append(result)
                else:
                    c.execute("ROLLBACK TO mobile_event_ingest"); c.execute("RELEASE mobile_event_ingest"); rejected.append(result)
            new_count = sum(1 for item in accepted if not item.get("duplicate"))
            if new_count:
                notify(c, mobile_user["company_id"], "SYNC_RECOVERED", "Offline records synchronized",
                       f"{new_count} inspection record(s) synchronized from {mobile_user.get('device_id', 'an inspector device')}",
                       f"mobile-sync:{mobile_user['id']}:{now_str()}")
            c.commit()
            return jsonify(ok=True,accepted=accepted,rejected=rejected,server_time_utc=server_time_utc())
        finally:
            c.close()

    app.register_blueprint(bp)

    # Unique notification source keys keep this loop safe if an app is started twice.
    scheduler_lock = threading.Lock()
    if not getattr(app, "_rti_schedule_worker_started", False):
        app._rti_schedule_worker_started = True
        def scheduler_worker():
            while True:
                if scheduler_lock.acquire(blocking=False):
                    c = None
                    try:
                        c = conn(); generate_schedule_alerts(c)
                    except Exception as exc:
                        app.logger.warning("Schedule notification worker: %s", type(exc).__name__)
                    finally:
                        if c:
                            c.close()
                        scheduler_lock.release()
                time.sleep(30)
        threading.Thread(target=scheduler_worker, name="rti-schedule-alerts", daemon=True).start()


ADMIN_SCHEDULES_BODY = r"""
<div class="notice">Manage registered Client PCs here. Blocking a PC immediately rejects its authenticated sync while keeping its inspection history. The generated Client PC ID stays fixed; edit the display name, schedule permission, or access status.</div>
<div class="panel"><h2>Client PC access and schedule permission</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>Client PC / ID</th><th>Last seen</th><th>Status</th><th>Schedule access</th><th>Actions</th></tr></thead><tbody id="nodeRows"><tr><td colspan="6" class="empty">Loading Client PCs…</td></tr></tbody></table></div></div>
<div class="panel"><h2>Pair a new Client PC</h2><div class="muted">On the Client PC open Setup and copy its generated <b>Client PC ID</b>. Enter it here, download the pairing file, then import that file on the Client PC (Setup → Import pairing file). The file holds private tokens: send it only to that PC and delete it afterwards.</div><div class="formgrid"><div class="field"><label for="pairCompany">Company</label><select id="pairCompany"></select></div><div class="field"><label for="pairClient">Client PC ID</label><input id="pairClient" maxlength="64" placeholder="CLIENT-1A2B3C4D" autocomplete="off"></div><div class="field"><label for="pairOnline">Online address of this Central (Internet)</label><input id="pairOnline" placeholder="https://rti.your-domain.com"></div><div class="field"><label for="pairLan">LAN address of this Central (same network, optional)</label><input id="pairLan" placeholder="http://192.168.1.10:5200"></div></div><button class="btn" id="pairButton" onclick="createPairing()">Create pairing file</button><div id="pairMessage" class="muted" role="status" aria-live="polite" style="margin-top:8px"></div></div>
<div class="panel"><h2 id="scheduleFormTitle">Create a scheduled inspection</h2><div class="formgrid"><div class="field"><label for="scheduleName">Schedule name</label><input id="scheduleName" maxlength="120" placeholder="Night patrol"></div><div class="field"><label for="scheduleCompany">Company</label><select id="scheduleCompany"></select></div><div class="field"><label for="scheduleClient">Client PC (optional)</label><select id="scheduleClient"><option value="">Available to all company clients</option></select><small class="muted">Leave this set to all company clients unless the schedule is for one PC.</small></div><div class="field"><label for="scheduleTime">Start time</label><input id="scheduleTime" type="time" required></div><div class="field full"><label>Inspection days</label><div id="scheduleDays" style="display:flex;gap:8px;flex-wrap:wrap"><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="MON" checked>Mon</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="TUE" checked>Tue</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="WED" checked>Wed</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="THU" checked>Thu</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="FRI" checked>Fri</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="SAT" checked>Sat</label><label style="display:flex;align-items:center;gap:6px;padding:8px 12px;border:1px solid #d7e0ee;border-radius:10px"><input style="width:auto;margin:0" type="checkbox" name="scheduleDay" value="SUN" checked>Sun</label></div><small class="muted">Choose one or more days. All days are selected by default.</small></div><div class="field"><label for="scheduleGrace">Schedule grace period (minutes)</label><input id="scheduleGrace" type="number" min="0" max="1440" value="15"><small class="muted">Edit this grace period whenever the allowed late-start window changes.</small></div><div class="field full"><label for="schedulePoints">Checkpoint IDs (comma separated; blank means all)</label><input id="schedulePoints" placeholder="Blank = every active checkpoint"></div></div><br><button id="scheduleSaveButton" class="btn" onclick="saveSchedule()">Create schedule</button> <button id="scheduleCancelButton" class="btn gray" style="display:none" onclick="cancelScheduleEdit()">Cancel edit</button><span id="scheduleMessage" class="sub" style="margin-left:10px" aria-live="polite"></span></div>
<div class="panel"><h2>Active schedules</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>Schedule</th><th>Time</th><th>Days</th><th>Client PC</th><th>Grace</th><th>Actions</th></tr></thead><tbody id="scheduleRows"><tr><td colspan="7" class="empty">Loading schedules…</td></tr></tbody></table></div></div>
<div class="panel"><h2>Live inspection alerts</h2><div id="notificationRows" class="muted">Waiting for alerts…</div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));const byId=id=>document.getElementById(id);let nodes=[],companies=[];
async function loadNodes(){let r=await fetch('/api/admin/client-nodes',{cache:'no-store'});if(!r.ok)throw new Error('Client PC list could not refresh (HTTP '+r.status+').');let data=await r.json();nodes=Array.isArray(data)?data:[];byId('nodeRows').innerHTML=nodes.map(n=>'<tr><td>'+esc(n.company_name)+'<br><span class="muted">Company ID '+esc(n.company_id)+'</span></td><td><b>'+esc(n.display_name||n.client_id)+'</b><br><span class="muted">'+esc(n.client_id)+'</span></td><td>'+esc(n.last_seen_at||'Not seen yet')+'</td><td><span class="badge '+(n.status==='ACTIVE'?'green':'gray')+'">'+(n.status==='ACTIVE'?'ACTIVE':'BLOCKED')+'</span></td><td><label><input style="width:auto" type="checkbox" '+(n.schedule_permission?'checked':'')+' '+(n.status==='ACTIVE'?'':'disabled')+' onchange="setPermission('+n.id+',this.checked)"> Allow schedule edits</label></td><td><button class="btn gray" onclick="editClientNode('+n.id+')">Edit</button> <button class="btn '+(n.status==='ACTIVE'?'red':'gray')+'" onclick="setClientNodeStatus('+n.id+',\''+(n.status==='ACTIVE'?'DISABLED':'ACTIVE')+'\')">'+(n.status==='ACTIVE'?'Block access':'Enable access')+'</button></td></tr>').join('')||'<tr><td colspan="6" class="empty">Client PCs appear after their first authenticated central sync.</td></tr>';const client=byId('scheduleClient'),selected=client.value;client.innerHTML='<option value="">Available to all active company clients</option>'+nodes.filter(n=>n.status==='ACTIVE').map(n=>'<option value="'+esc(n.client_id)+'">'+esc(n.company_name)+' · '+esc(n.client_id)+'</option>').join('');if(Array.from(client.options).some(option=>option.value===selected))client.value=selected}
async function loadCompanies(){let r=await fetch('/api/companies',{cache:'no-store'});if(!r.ok)throw new Error('Company list could not refresh (HTTP '+r.status+').');let data=await r.json();companies=Array.isArray(data)?data:[];const company=byId('scheduleCompany'),selected=company.value;company.innerHTML=companies.filter(c=>c.status==='ACTIVE').map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('');if(Array.from(company.options).some(option=>option.value===selected))company.value=selected;const pair=byId('pairCompany');if(pair){const pairSelected=pair.value;pair.innerHTML=company.innerHTML;if(Array.from(pair.options).some(option=>option.value===pairSelected))pair.value=pairSelected}}
async function createPairing(){const message=byId('pairMessage'),button=byId('pairButton'),d={company_id:byId('pairCompany').value,client_id:byId('pairClient').value.trim(),central_url:byId('pairOnline').value.trim(),central_lan_url:byId('pairLan').value.trim()};if(!d.company_id){message.textContent='Choose the company.';return}if(!d.client_id){message.textContent='Enter the Client PC ID shown on the Client PC setup page.';byId('pairClient').focus();return}button.disabled=true;message.textContent='Creating private pairing file…';try{const r=await fetch('/api/admin/client-pairing',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x;try{x=await r.json()}catch(_){throw new Error('Server returned an unreadable response (HTTP '+r.status+').')}if(!r.ok||!x.ok)throw new Error(x.message||'Pairing file could not be created (HTTP '+r.status+').');const blob=new Blob([JSON.stringify(x.pairing,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='Company-'+x.pairing.company_id+'_'+x.pairing.client_id.replace(/[^A-Za-z0-9._-]/g,'_')+'.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1000);message.textContent='Pairing file downloaded for '+x.company_name+' / '+x.pairing.client_id+'. Import it on that Client PC, then delete the file.'}catch(e){message.textContent=e.message}finally{button.disabled=false}}
async function setPermission(id,allowed){let r=await fetch('/api/admin/client-nodes/'+id+'/permission',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({schedule_permission:allowed})});let x=await r.json();if(!r.ok||!x.ok){alert(x.message||'Permission update failed');loadNodes();return}loadNodes()}
async function editClientNode(id){const node=nodes.find(x=>x.id===id);if(!node)return;const name=prompt('Client PC display name:',node.display_name||node.client_id);if(name===null)return;if(!name.trim())return alert('Enter a Client PC name.');const r=await fetch('/api/admin/client-nodes/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({display_name:name.trim()})}),x=await r.json();if(!r.ok||!x.ok)return alert(x.message||'Client PC update failed');await loadNodes()}
async function setClientNodeStatus(id,status){const node=nodes.find(x=>x.id===id);if(!node)return;const verb=status==='DISABLED'?'Block':'Enable';if(!confirm(verb+' '+(node.display_name||node.client_id)+'? Scan history will be kept.'))return;const r=await fetch('/api/admin/client-nodes/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({display_name:node.display_name||node.client_id,status})}),x=await r.json();if(!r.ok||!x.ok)return alert(x.message||'Client PC access update failed');await loadNodes();alert(x.message)}
let schedulesCache=[],editingScheduleId=null,refreshBusy=false;
async function loadSchedules(){let r=await fetch('/api/schedules',{cache:'no-store'});if(!r.ok)throw new Error('Schedule list could not refresh (HTTP '+r.status+').');let data=await r.json();schedulesCache=Array.isArray(data)?data:[];byId('scheduleRows').innerHTML=schedulesCache.map(s=>'<tr><td>'+esc(s.company_name||'')+'</td><td>'+esc(s.name)+'</td><td>'+esc(s.schedule_time)+'</td><td>'+esc((s.days||[]).join(', '))+'</td><td>'+esc(s.client_id||'All')+'</td><td>'+esc(s.grace_minutes)+' min</td><td><button class="btn gray" onclick="editSchedule('+s.id+')">Edit</button> <button class="btn gray" onclick="toggleSchedule('+s.id+','+(!s.enabled)+')">'+(s.enabled?'Disable':'Enable')+'</button> <button class="btn red" onclick="deleteSchedule('+s.id+')">Delete</button></td></tr>').join('')||'<tr><td colspan="7" class="empty">No schedules configured yet.</td></tr>'}
function setScheduleDays(days){const selected=new Set(days.map(day=>String(day).toUpperCase().slice(0,3)));document.querySelectorAll('input[name="scheduleDay"]').forEach(input=>input.checked=selected.has(input.value))}
function editSchedule(id){const s=schedulesCache.find(x=>x.id===id);if(!s)return;editingScheduleId=id;byId('scheduleName').value=s.name;byId('scheduleCompany').value=String(s.company_id);byId('scheduleClient').value=s.client_id||'';byId('scheduleTime').value=s.schedule_time;setScheduleDays(s.days||[]);byId('scheduleGrace').value=s.grace_minutes;byId('schedulePoints').value=(s.checkpoint_ids||[]).join(',');byId('scheduleFormTitle').textContent='Edit scheduled inspection';byId('scheduleSaveButton').textContent='Save schedule changes';byId('scheduleCancelButton').style.display='inline-block';byId('scheduleMessage').textContent='Edit the schedule details, then save.';byId('scheduleFormTitle').scrollIntoView({behavior:'smooth',block:'center'})}
function cancelScheduleEdit(){editingScheduleId=null;byId('scheduleName').value='';byId('scheduleClient').value='';byId('scheduleTime').value='';setScheduleDays(['MON','TUE','WED','THU','FRI','SAT','SUN']);byId('scheduleGrace').value='15';byId('schedulePoints').value='';byId('scheduleFormTitle').textContent='Create a scheduled inspection';byId('scheduleSaveButton').textContent='Create schedule';byId('scheduleCancelButton').style.display='none';byId('scheduleMessage').textContent=''}
async function saveSchedule(){const message=byId('scheduleMessage'),button=byId('scheduleSaveButton'),name=byId('scheduleName').value.trim(),companyId=byId('scheduleCompany').value,time=byId('scheduleTime').value,days=Array.from(document.querySelectorAll('input[name="scheduleDay"]:checked')).map(input=>input.value),grace=Number(byId('scheduleGrace').value);if(!name){message.textContent='Enter a schedule name.';byId('scheduleName').focus();return}if(!companyId){message.textContent='Select a company.';byId('scheduleCompany').focus();return}if(!time){message.textContent='Choose the schedule start time.';byId('scheduleTime').focus();return}if(!days.length){message.textContent='Choose at least one inspection day.';return}if(!Number.isInteger(grace)||grace<0||grace>1440){message.textContent='Grace period must be between 0 and 1440 minutes.';byId('scheduleGrace').focus();return}const d={name,company_id:companyId,client_id:byId('scheduleClient').value||null,schedule_time:time,days,grace_minutes:grace,checkpoint_ids:byId('schedulePoints').value?byId('schedulePoints').value.split(',').map(x=>x.trim()).filter(Boolean):[]},url=editingScheduleId?'/api/schedules/'+editingScheduleId:'/api/schedules',method=editingScheduleId?'PUT':'POST';button.disabled=true;button.textContent='Saving…';message.textContent='Saving schedule…';try{const r=await fetch(url,{method,headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x;try{x=await r.json()}catch(_){throw new Error(r.redirected?'Your admin session expired. Sign in again, then retry.':'Server returned an unreadable response (HTTP '+r.status+').')}if(!r.ok||x.ok===false)throw new Error(x.message||'Schedule could not be saved (HTTP '+r.status+').');const wasEditing=editingScheduleId!==null;cancelScheduleEdit();message.textContent=wasEditing?'Schedule updated successfully.':'Schedule created successfully.';try{await loadSchedules()}catch(refreshError){message.textContent+=' The schedule was saved, but the list could not refresh: '+refreshError.message}}catch(error){message.textContent=error.message||'Could not connect to Central to save this schedule. Retry when the connection is available.'}finally{button.disabled=false;button.textContent=editingScheduleId!==null?'Save schedule changes':'Create schedule'}}
async function toggleSchedule(id,enabled){try{let r=await fetch('/api/schedules/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled})}),x=await r.json();if(!r.ok||!x.ok)return alert(x.message||'Update failed');await loadSchedules()}catch(e){alert('Could not update schedule: '+e.message)}}
async function deleteSchedule(id){if(!confirm('Delete this schedule?'))return;try{let r=await fetch('/api/schedules/'+id,{method:'DELETE'}),x=await r.json();if(!r.ok||!x.ok)return alert(x.message||'Delete failed');await loadSchedules()}catch(e){alert('Could not delete schedule: '+e.message)}}
let latestAlertId=0;async function loadNotifications(){try{let r=await fetch('/api/notifications?after_id='+latestAlertId,{cache:'no-store'}),x=await r.json();if(!x.ok)return;const rows=x.notifications||[];if(rows.length){latestAlertId=Math.max(latestAlertId,...rows.map(n=>n.id));byId('notificationRows').innerHTML=rows.concat([]).reverse().map(n=>'<div class="notice"><b>'+esc(n.title)+'</b> · '+esc(n.company_name)+'<br><span>'+esc(n.body)+'</span><br><small>'+esc(n.occurred_at)+'</small></div>').join('')}}catch(_){}}
async function refreshSchedulesPage(){if(refreshBusy||document.visibilityState!=='visible')return;refreshBusy=true;try{await Promise.all([loadNodes(),loadSchedules(),loadNotifications()])}catch(error){const message=byId('scheduleMessage');if(!message.textContent)message.textContent='Live refresh paused: '+error.message}finally{refreshBusy=false}}
async function initializeSchedulesPage(){try{await Promise.all([loadCompanies(),loadNodes(),loadSchedules(),loadNotifications()])}catch(error){byId('scheduleMessage').textContent='Could not load schedule setup: '+error.message}}
initializeSchedulesPage();setInterval(refreshSchedulesPage,5000);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshSchedulesPage()});
</script>
"""
