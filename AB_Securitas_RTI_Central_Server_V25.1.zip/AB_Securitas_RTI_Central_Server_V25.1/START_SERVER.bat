@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "RTI_SETUP_NO_PAUSE=1"
call SERVER_SETUP.bat
set "RTI_SETUP_RESULT=%ERRORLEVEL%"
set "RTI_SETUP_NO_PAUSE="
if not "%RTI_SETUP_RESULT%"=="0" (
  pause
  exit /b 1
)

set "PATH=%ProgramFiles%\Tailscale;%PATH%"
where.exe tailscale.exe >nul 2>nul
if errorlevel 1 (
  echo Tailscale is installed but its command is not available yet. Restart Windows and try again.
  pause
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "scripts\start_server.ps1"
if errorlevel 1 goto :failed
timeout /t 3 /nobreak >nul

echo Starting the mobile API Funnel. The admin dashboard stays private on this PC.
tailscale.exe funnel --https=443 --bg http://127.0.0.1:5200
if errorlevel 1 (
  echo Central and its API proxy were started, but Tailscale Funnel needs sign-in or admin approval.
  echo Sign in to the correct Tailscale account, enable Funnel in its admin policy, then run START_SERVER.bat again.
  pause
  exit /b 1
)
echo.
echo Central dashboard: http://127.0.0.1:5000
echo Mobile API Funnel status:
tailscale.exe funnel status
echo Keep this PC on while Android and Client PCs need Central sync.
pause
exit /b 0

:failed
echo Could not start Central services. Read the error above.
pause
exit /b 1
