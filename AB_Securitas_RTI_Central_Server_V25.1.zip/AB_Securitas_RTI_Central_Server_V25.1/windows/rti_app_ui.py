"""Manager window page and icon for the AB Securitas RTI Server desktop app (embedded so the exe needs no data files)."""
import json

ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAZjUlEQVR42u1deXidVZn/ved83923LG3SZmmTtGnSpBSwdkFbnaIo"
    "0MGNyggM4iDOAKPiiFNHUYY6o4OjCOOMOA4Oijy41EHFUjoM8AAFKi0WuqQNbemStE3SNsndkrt83zln/viW3JsmXTBdQnOe53v6"
    "JOm9uXl/5/ze3/u+55yXcFJjOQdWCeeraO28eoJ2BaAWK6VmE1ErlJIAGM6PIUHElFLbiGg7QOsUzDWJjlf3jGaz0QadxM8JgCwr"
    "uyQsw+oSCPVZRWoRESuFAhQkoBTOy0EEAgMIUEr2kaL14PR9lqKXe3tfTtkTUtnPiOM4M/Yu58UyWjt/qQzKF6GwFoyuhEKpkqZU"
    "yhRQ56v1ASillDKFkqaEQqltm7UyKF+M1s5fCkBaNryLneoKYNaLZ3uiNaGHGNOuhRJQStpvSKzotUQg+zlP7G7Nu+K5pwAlARAR"
    "YyAOKc1HE53pTwHb80M2PSEA79GA581Q5YJmzUOriKhFSSGtxUBsyOYEYgxKKUjThJnLQZjG2x4EpRS4pkPzesE0DUQEJeUwIlAS"
    "IBDjTCnVZubV8nT3Kzsc2x4HAMtxlNbOny0Ve4YYVSppmgBpRcuDc5j5HIxMBkzT4I/GUDGzCZHKqZCGAbxdQVAKTNeR7D6Enl3t"
    "yCTikKYJ3e+H5vFCiuE+V5nENE1J1c1IXtrXsWH7cOdMw2hHlVTPa1HEniZiFUqJIuMTY1BSIptKIja1CrUXvhP1ixZjSlMrArES"
    "6D4/lJQndu3jFgDLBkY2g8F4P7rat2HP+nXoeH0j4ocOwheOuDYqAoG4ppTsISXf13/g1TZH2BQC4PyrYjXz24nxWUqYJmjI+Ixr"
    "yGcGwTjH/L/4JOZe+RGEJlVACgEpTBARuKafFz5AmAaUUmBcA+Mc6SM92PzEb7DhFz+FFAIefwBSmIUrxySuaUqKN+KdG5oK7U0F"
    "1COjVfMfYZxfq1Qx7TDOMdDXi8qmFnzwi1/DlJYLkEunwDiH7vMjm0wgcbgbXTu2gnHt7StLiSCFiSnNcxCdXAlfJAojm4EUAt5Q"
    "GF1tW7D2u99Ad3sbgqVlwyhJmUSaJoV4NHFww/XAcgasEuRwUqxm/mJi2gtKGgIgXmj83EAarR+8Cotvug3+aAmMbAa+cATd7W1o"
    "+9/fo+O1jUge6UEmEbec0ttV9ttO2B+NITKpArUXvRMtH/hzVDa1IJtKQvf5kUn0Y92P/wPb1j4ObzA0HARBTOdKmkvinRvWAcs5"
    "AXex0tInQyKg/kCMN0EJR2aCaRoG+o7iwquWY9lX/wmD8Th0fwCpIz146aEHsHPds8gmE9B9fnBNA9O08yMMNk0I07QmYiSKxsVL"
    "8a5P3YLwpAoYmUEEYjGs/uc78frjqxAsLYc0zSF1RJyUFO18kBb29V2eJgAUnbpoKdPpaSUMCbKMT4zBzGZROq0Oy7/9H9B9fjDO"
    "0d3ehqf/7R50tbchWFICYnwEGXY+BMG2DJcCA/39mNLUgvd9bgUqm1oghYCRzWDV39+Gvv17ofl8Q45ZKUlcZ9JQ70scWv8sBwBf"
    "ZOoPiKjeDiSY6/IBfHjldxCbWgPu8aCrbQsevf3TyKVT8Edj56Xhh8cEAOANhTHQewSb1/wWdfMWIVZdC83rQ2XTbLQ9tRrEqBA5"
    "QSAoJSpyqYOP8NLqhVUg9U0APtv4xDhHJpHAor+8GS2XLUN+cACZeD+e+OadyKXT0H3+ETTv+TuUlNA8HkApdLVvw4xFS0CMoaS6"
    "FsIwsOcPL8ITCDiAkeXOMSkQqXmECRLXEOcxW7oQiGDm84hNqcLcKz+KXDoFXziCFx96AF3tbfD4J4w/ol8QAh6/H13tbXjxoQfg"
    "C0eQS6cw98qPIjalCmY+7wSoBChFnMcEiWsYKVpg5zGUw/1GNoPai96J0KTJLu/vXPcMAiUlEKY5Ye1R4wMTgZIS7Fz3DLrb28A4"
    "R2jSZNRe9E4Y2QyIsaGQGlCkaAFThNlKSXLzPHaA0bBoCZQQ0H0+bHtqNbLJJBjjE1Y+wWCMI5tMYttTq6H7fFBCoGHRkmHxETGl"
    "JCnCbGYXU+DQjzBN+CNRVDa1QAgTmVQSHZs2WLwv5YSFT0RFUkL3+dGxaQMyqSSEMFHZ1AJ/JGqxh0NDSoGIWpldyXKllcjlUNHY"
    "BH+sBESEZE83Ukd6zhuNPyarQNOQOtKDZE83iAj+WAkqGpsgcrnibLFSkqGgKENEkKaBSOVUeHx+cE1H945tyCQT4Jp2/la+TjFj"
    "yjUNmWQC3Tu2gWs6PD6/lSk+Nl3P2Ej5DmEY7sIgPsH7bzlYs22nlIQYJU3PRovyChGdGG99NYxo0xMBMDHOoL+YMMEEABMATIwJ"
    "ACYAmBhnZ5wT4S0RgfNR5oICzLeQfeWMFefhT1o62nsJlTojqRftXDC+EAL9/QkUb6EkOJvwopHQKW34IiIk0wMw8vmh9znxq9xA"
    "lDGCrmnw+33gnEOexsKTdraNbxgGJpWX4v57vgKvx2PtvyNrBhIREokUVt7zAwwMZsA5P6EhGGNIpwfwmRs/jnctvAhCSnB2YqYV"
    "QmIwk8HR3jje3NOBHTv3oP2NN9HXH0c4HIJmA/G2AoAzhv6BQXzjzs/jxus+Mur/++9HHsPWtp0IBPgJA3OlFDjnuPG6j2DeRS1v"
    "+bMJIdG2YxceXfUEfvyz/0F6YBABv2/MQThrADBGSA9mMHdOM26+cTkM07QYh4boQEoJrnHUVk/Bps3bbRpSx11RpmmirCyG6qmT"
    "Ydqbtx36Oi6VkPV6Rsz1SRe0zsIFrbNwzUcvxw1/vQK793QiEBhbEM4eAMSQz+fxlS9+BsGAH0IIcI0Pm4XWKpk1sw5SSJxozyMR"
    "IZ83UFdbjYrJ5dYeJVWYAzu5xKJjYCklhJC4aG4zVj18H957xSeRyWZPigrPaQA4Z0ik0li6ZCGu/tBlkFKC2TxtmAKaxotcZ1Nj"
    "neUbTgiqBcCsxjrbuUtwztxVsOGPW7Bn3wF4PXoRlREjBAN+VE+tRPOsejB71zdjDIwxGIaJpsZ63Hj9R3DP9x5EWWkMYozq4mcF"
    "AIenv77iFjDGIIQEYwQpJX7+69W4/uN/DmIMZJu8fnoNgkE/xAmWvrPnYM7smYXfcVfBirvuxXNPvwhfJFT0XmQ7b4/Xg5amGfje"
    "t76MBfMugJQKjBEYY5BK4QNL34V7//0nY5ohZmd+9nPEEyl87Kr3Y/El8yCkdFXPlm078eBPVhVQClwAouEQTFMcV44qpaDrOubM"
    "bnRNa81kQjyZQlf3EYTLShAKBhAOBd0nFAoiEPBB4xzr1/8Rt31xJQYz2QI1Zq2u8vJSiy6lHLMN4GccANM0EY2EceeX/saamQX8"
    "/cOHfoE3du9DOj1Y9JpJ5aWYOqUChmmOevTAkrQmyktjaKivdb/ncHVnZxcOdR2GpjGYQkBKOeyxTr2Ulpdi776D6O456vqQIZ8k"
    "bP8wdvtfzygAmsaRSKbw6RuuRlNjPaRTdSPCG7v24Ve/WYtcLo+eI70FDlFB0zjq66qRz+ednZOjxhRVUytQNaXCVVoOAG1v7EYm"
    "k3F9zajyU0r4fF4EAj6Xn5wjSZ0Hu+x4hMYfBRERstk8ptVMxd999kbXMVr8TPj2fQ8imUzDNAX27j/gcrcD0oz6WkipRl36RIS8"
    "YaB5VgM4Z66ScWbqzl37AAC6pkHTePHDOTjnljg43It3L7oYFZPKLHFgryIiwpr/fR5KnowcOAedMOcM/fFBfONrn0Pl5HJLRdh6"
    "+4+vteGXv3kSJbEI+nrj2LPvgMvpDuU0NzZYM3pUAAApJFqbZ7grhzG4UfALL78KM57EYaVsSVv8YsYIuq7j8mWX4rvfXOGmMAzD"
    "gK7reH3rDvzysScRDgfHXxzAGGFgIIML5zTh5k9e7cpOhx6+ee+PkM3mEAoGIJXCXhuAwqBsZkOtlapQchTtruDxetBqO2AiFPmB"
    "dy24GHXTquHR9SINzzlDOBRETXUlLp47GwvmzXXBd2To9vbduPamLyGby8PvG4eBGBFDLm/YQVcAQggoZf3xzz7/Cp5Y+xyikTBM"
    "0wTXNezZ1+nmdRxb1VRNQXl5CfrjSeiaVmREJ6EXCQfRNLPO/Z2FP7/7K397ypTZH0/iV489iW98+wH09sftgHGcpSI4Z0im0li6"
    "ZAE+WhB0KaUghMS37v1PSNcfSOicY3/HoYLgzDJ0RUU5KiaV48iRPnh0rTiQIiCXN9BQV4spUyYVrQBnNjtpiZHom+Ccc7ZAT6YG"
    "8NNHf4v7H3gYe7bvQmzK5NNi/DPihKU907+24lZwe0Y7xl3zf89j3fpNKC2J2vkXDT6fF/2JFI72xV0nKqUCZwwz6mttKUojKqCG"
    "+hr4vF5IKYv+DxFB1zV4PDo8+rGPrmtF9Yhg0I/rPr4MP7p/JT788WVIDwzaznecpaM55+iPJ/CJ5cuw5JJ32Ia3rp/ojyfxhS9/"
    "C7n+BHpyOUBId9rGj/Ri774DmFxeCmXrc8Y4GmdMhxgJAFgUdEHLLHfGF45DXYeRHhgcUYJyzhCNhFFaEgW3N1JpnKOsNIZL37sQ"
    "l753Ib5817347vcfQjQaGk8URENB1x1/fcyMjceTuOETH4bPZ89YEBQsx5fN5lBeVjLkRG0aamyYBm0Y/1urxEpttDbPdFeNIx1N"
    "08TyG25HW/tuO52sjgHA7/ehpqoSH/vQZbjlpk+4+SNnJf3L3X+HN3bvxeq1zyEaDp0wJXJOAKBxhqN9Cdzx+ZvQ1Fh/TGGkbno1"
    "vr7i1pNSUJDWjG+cOR0er6fIiJaRBaKRMJoa69yknKPWD3Ydxq49++2CS3aENI5CIpXGgUM9eO6Zl/D6lnb86N/uBkDgnMMUAqQU"
    "/v7zN+GpZ16CHOPK2GnxAUSEXC6PaTVVuONvraCLFeTkrTSvQD5vjPjk8vmipe5QTk31FJSWxGAW0BABMAwTlRXlmFZbNbRq7Fn6"
    "xq69SCYH4PXqYIyB8+EPh0fXEQr6UTZlMn72i99hw6atYMzOpjKrPjB3ThOmT6tCLp93/5ZzFgDOGVIDg7j91htQMbncXcqF2ppz"
    "bjnFER6vx1PkFJ2/t7y0BNVVFcjnh3YZE2PI5fOYNWM6/D6vFS0XnFXe3v4mcrmcRXF2SmGkRwgrKWiYJvbs7XSpzZFNfp8X5WUl"
    "EKYY07swxpyCnKBr7pwm3Hzjckjb6M7M3Lv/IJKpFDjjI0a1ZOdjIqEg6qZXu98VQkLTOKbXTMXGV7cWrQAhJJpnNdiqS4KBu6ns"
    "zVvbwTg7ybK8RTslsQiGQkALBCmtqHisLyLRxp5+jq10OR+640AX3nP5XyKZSkPTRq4qETEMZjK4cE4z1q39WUH1SdnFmfqidLCy"
    "QZ/b2uQazbrHgUEIgd17OuD1eCy/MOJufAsqYgz98QSm11Zhwby5UApFqimZSqGr++iIIuCcAYBzjmQqjT9bshAfu+r9rt6Xtg+4"
    "999/is4Dh1BWVgpzlMN+RAqccXQe7EI8nkJZWawoqTZrZl3RJBRCIBQMYpbtgGEn+BhZDnjbjl0wTBPJdPoYB6zsvJCwKXJ67VT8"
    "8L5/RGlJ1P3sQggwxrBp8w50dR9GMBBwE4TnHABKWQHT11bcAs65Jdds47+xay8e+eXvEItGi0qQo6Wt0+kMOg91o6wsVlRYr59e"
    "g1AoCFMIMGY5++qplaibVjWkgOwTt319cTTPqne3uwyf+R5dRyQSRNWUCsy7qBWXv38xykpjrq9y/AMR4ccP/9pSRIwAcQ5SkBt0"
    "Xb0MSy6ZZ+1oKCg3/uv9/43+eAplJdET7nTjnCGRSKPzQBcunNPkGgQA6qZVIxYJI55IgnMP8nkTddOrEQmHXGM5YF3Q2oSXnvr5"
    "KdG2u2pttaZpGn7+6yfwP48/hWgkPGa14DFXQU7Q9dUvfcblSMv4DK9v3YFf/eZJxCKhk9pm6ARQhXUBZ5SWRFFdVYm8YYIzBsMw"
    "0Dp7pqtkhguC4xlfKQUhJQzDhGGYbr7IAVzTNDy6ajVu+cLd8Hm9p2V33JgAoHGORNyqdDU3NrjKx0lw3fO9BzE4mAU7yfNmyr6Z"
    "aveeDleGEllFe84Z6qfXIJ83AAIYZ2htnmnN+lMUKEQEzhh0XYOuW4UazjmICJu3teOm2+7EX936VXcTwekA4E+mICJCNpfDjBnT"
    "8MXPfcqiEHdbB+GFl1/F42ueRSQSOoXla/mSobQ0L3LEVsrZShUE/H7MaWl0f++pjnzeQHpgEL19cRw81IONm7biuRc34uVXXkMy"
    "lUY0Eh4xv3Tu+AClQHb+5qprbh2SnbYjPHK0F5yf2q8RQiIY9GPjpm2Y957lBftrrfdMptIIh4IwTQFd13DTbXfaibRTKxdaaWoT"
    "mWwOyWQK/YkUDMMA5xyhYAAlseiYc/6YA6AcCkqmceRo3zGZSmtpn7p2dtIZbTt2jejwdV1zjdi+a+9b3qtDRG5kHgoG3O2PTrrk"
    "dI8xUUEWRzIEg4ERf6b+BOMEAv4TvmfA5/0TIlTlYnc2rmIY0zjgdPwBJ/Oe8thbbMfNmDiiNAHABAATYwKACQAmxgQA5+cYv9dg"
    "EblVL4XxK0O18Wh4xhiEYcA0DSsy1nRwXbdihnEGxLgCgBiDtC8SDJVPRqisHACQ7j2K9NHD8ASDYFwbdn//BABjZnwjm4XH78f7"
    "Pv9l1C98N4KlFgADfUex5w8v4qWf/BD5TMa6LnKcgMDGB+sQjGwW5dMbcP0PHsY7rr4O4fIKKCGghEC4vALvuPo6XP+Dh1E+vQFG"
    "NjtuetmMCwCUUtC8XlzxDytRWlOHwXg/TCPvVGpgGnkMxvtRWlOHK/5hJbTTVL06LwFgnCOTSmL+NTegYmYTBuN94Hb3osIVwjUN"
    "g/E+VMxswvxrbkAmlTzpCtw5B4Aavvn+LCoeaZoIRGNoWLgYZu74ZU3GOcxcFg0LFyMQjVmNE87y5x/RpscFQClwXXdPmKizfFO6"
    "lBIefwDBMqsTxfG4nWzAgmXlViOds+yIHdsRMXBdH1Eia7DaKTEHJaZZfbLyWetIZ2Vzq3vvMTE2cY/oScx69/7t5lYI04CUEsnu"
    "Q2CaPnwlSFZ4mEopBe71omdnOzLxfiilEKmoRHhSRUEflDPqfS1uT/Sjr3M/uPf48lJJCe71oa9zPwYT/WftumVpmghPqkCkohJK"
    "KWTi/ejZ2Q4+XBwQMaaU2mZzlSq697i9DZxr8IcjqL14PozsiQ85ny79b+Zy2PH0Grd14vHUEjGGHU+vgZnLFdzXfwadqtN/4eL5"
    "8Icj4FxDd3vb8Pu3lbWFUm1jpLCdiDmNKN1eWW+ufwHEOYxsFq2XLYMvEoGUZ94fSCHgC0ewefVj2L3uWYQnl9vN44Y2UTlfhyeX"
    "Y/e6Z7F59WPwhSNnpdOHlAK+SAStly2z4hHO8eb6F6zGbq7/UpKIKVLYzhSpV2BfV+QsY93nR8drG5E+chhSCFQ2taBx8aUY7LeX"
    "9VmgIt3vx9rvrMSWNb+HLxyBPxKB5vFC83jhj0TgC0ewZc3vsfY7K6H7/WeFerimYbC/H42LL3W7KaWPHEbHaxuH2jwOySNSpF7h"
    "wUhth1Lyr0Dkc37KdR2po4fhDYVQv+DdyKaSqGqZi87Nf0S69yg0j+eMBzqMMQjTwI6nn0T/gf2u68omEzi49XWs/9mP8NJDPwQx"
    "Bsb4mf98NltMbpiJD97xdSil4AtHsPFXD2PnumfhDYYcAKzLc6RMcPDbCACiVfOfZJxfppSQbn6IAGkK/MV9/4WKmc0gxnBwyyY8"
    "evunoek6dH/gzDtm+0qxTCoBxjXoPmvOGNkspDDhD0etreNn2viaBiMzCNMwcO19D6LqgouhpETPrh34xe03g2m88KY1k4gzKcRT"
    "iYMbLucAyBeu7SJOn4QU7oEsYgzSMHBo+xY0LlkKAAhPrkDdvEXoam9DX8c+ePz+Mx5tKqXg8fuLdLXm8UD3+c6ojyIi+29XGOjr"
    "xeSGRnzorm9brV/yeeQGUnj87hXI9PcVxwBKWX2GBf1NLnVgHwfuYkF951GpiQ8T45Oso9XWKQfN60X/gf3IDw6g5bIrkM9kEKuu"
    "RcOiJTAyg+jt2Gf3j7TOfTFNs266Os2PYwD3ewXnxc7Eo6TVkCGXTkHz+tBy2ZX4wB1fR3n9TIh8HoFYDE/ffw92v/wcfJFoQTCr"
    "JBgnJc12nlErM5lPGxPNPE9l1uO0NPMEJtrZnkJuauzb2brgAhMNnU9qnIaGzm5ibqKl+XEVwOlraY4CKhKltfNnS8WeIUaVShbT"
    "kZv2zedgZDJgmgZ/NIaKmU1Wq6bTcJb23AFAgelWsrJnVzsyiTikaUL3+6F5vCNE3sokpmlKqm5G8tK+jg3bHRtjGPUUjPdowPNm"
    "qHJBs+ahVUTUoqSQ9uGHop5jTm5GmibMXA7i2D5Zb0MMFLimQ/N6LdVnX4tQHPgpCZAlN5VqM/Nqebr7lR2ObYc79tHqBBKY7YnW"
    "hB5iTLsWSkBZa8vpuF1Ykio6nfh2H+75hGKx4eTTiIgxEIeU5qOJzvSngO35IZseq6xGGXcx4G4JANHa+UsZ2PdAdIGTLwJGAeP8"
    "Gq7RAcbc7KtSWyTkFxIdG54dbstTAMD9OQGQZWWXhGVYXQKhPqtILSJipVa3CXn+FmmIQGD23aKyjxStB6fvsxS93Nv7csoRNjjO"
    "le8nOXOLHUe0dl49QbsCUIuVUrPtjqwF7dDf9kOCiCmlthHRdoDWKZhrEh2v7hnNZqON/wfj71ExQ9EefQAAAABJRU5ErkJggg=="
)

_MANAGER_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AB Securitas RTI Server</title>
<link rel="icon" href="data:image/png;base64,__ICON__">
<style>
:root{
  --navy:#101d36; --navy-2:#1a2b4c; --navy-3:#2b3f66; --sky:#79c8ef;
  --paper:#eef2f7; --white:#fff; --line:#cfd8e4; --ink:#17233a; --steel:#566882;
  --blue:#1f57c3; --blue-d:#18449c; --ok:#0f7a56; --ok-l:#4fcf98; --warn:#a85f00; --warn-l:#f3b24a; --bad:#b3261e; --bad-l:#ff8379;
  --sans:"Segoe UI Variable Text","Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;
  --mono:"Cascadia Mono",Consolas,"SFMono-Regular","Liberation Mono",monospace;
}
*{box-sizing:border-box}
html,body{margin:0}
body{background:var(--paper);color:var(--ink);font:15px/1.5 var(--sans);min-height:100vh;display:flex;flex-direction:column}
button{font:inherit;color:inherit}
:focus-visible{outline:3px solid var(--sky);outline-offset:2px}

/* ---------- status band: the one memorable element ---------- */
.band{background:var(--navy);color:#e8eef8;padding:18px 32px 14px}
.brand{display:flex;align-items:center;gap:12px;font-size:14px;color:#b7c5de}
.brand img{width:30px;height:30px;border-radius:7px}
.brand b{font-weight:600;color:#fff}
.band-main{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;flex-wrap:wrap;margin-top:18px}
.status{min-width:0;flex:1 1 420px}
.status h1{margin:0;font-size:34px;line-height:1.1;font-weight:600;letter-spacing:-.015em;color:#fff;display:flex;align-items:center;gap:14px}
.status p{margin:8px 0 0;color:#b7c5de;max-width:68ch}
.dot{width:14px;height:14px;border-radius:50%;flex:none;background:#52617c}
.dot.running{background:var(--ok-l);box-shadow:0 0 0 5px rgba(79,207,152,.18)}
.dot.starting{background:var(--warn-l);animation:beat 1.2s ease-in-out infinite}
.dot.error{background:var(--bad-l);box-shadow:0 0 0 5px rgba(255,131,121,.2)}
@keyframes beat{50%{opacity:.35}}
@media (prefers-reduced-motion:reduce){.dot.starting{animation:none}}
.pulse{display:flex;align-items:flex-end;gap:2px;height:30px;margin-top:22px}
.pulse i{flex:1 1 0;min-width:2px;border-radius:1px;background:#2b3f66;height:4px}
.pulse i.up{background:var(--ok-l);height:26px}
.pulse i.down{background:var(--bad-l);height:12px}
.pulse i.off{background:#52617c;height:6px}
.pulse-caption{display:flex;justify-content:space-between;gap:16px;margin-top:7px;font-size:12.5px;color:#9db0cd;flex-wrap:wrap}

/* ---------- buttons ---------- */
.btn{border:1px solid var(--line);background:var(--white);border-radius:5px;padding:7px 14px;cursor:pointer;font-weight:600;font-size:14px}
.btn:hover:not(:disabled){border-color:var(--steel)}
.btn:disabled{opacity:.5;cursor:default}
.btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}
.btn.primary:hover:not(:disabled){background:var(--blue-d);border-color:var(--blue-d)}
.btn.on-dark{background:var(--sky);border-color:var(--sky);color:var(--navy);padding:10px 22px;font-size:15px}
.btn.on-dark:hover:not(:disabled){background:#9ad7f5;border-color:#9ad7f5}
.btn.danger{color:var(--bad);border-color:#e4b4b0}
.btn.small{padding:4px 10px;font-size:13px}
.btn.quiet{border-color:transparent;background:transparent;color:var(--blue);padding-left:0;padding-right:0}

/* ---------- body ---------- */
main{flex:1;display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:0 48px;padding:26px 32px 8px;max-width:1180px;width:100%;margin:0 auto}
@media (max-width:820px){main{grid-template-columns:1fr;padding:20px 18px}.band{padding:16px 18px 12px}.status h1{font-size:27px}}
section{padding:6px 0 22px}
section+section{border-top:1px solid var(--line);padding-top:20px}
h2{margin:0 0 4px;font-size:17px;font-weight:600;letter-spacing:-.005em}
.lede{margin:0 0 14px;color:var(--steel);font-size:14px}
h3{margin:18px 0 6px;font-size:14px;font-weight:600;color:var(--steel)}
.addr{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:6px 0}
.addr code{font:600 18px/1.3 var(--mono);color:var(--ink);background:var(--white);border:1px solid var(--line);border-radius:5px;padding:6px 12px;word-break:break-all}
.help{margin:8px 0 0;color:var(--steel);font-size:14px;max-width:62ch}
.help strong{color:var(--ink);font-weight:600}
dl.facts{margin:6px 0 0;display:grid;grid-template-columns:1fr auto;gap:0}
dl.facts dt,dl.facts dd{margin:0;padding:7px 0;border-bottom:1px solid var(--line)}
dl.facts dd{font:600 17px var(--mono);text-align:right;font-variant-numeric:tabular-nums}
.pcs{list-style:none;margin:6px 0 0;padding:0}
.pcs li{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)}
.pcs .who{flex:1;min-width:0}
.pcs .who b{display:block;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pcs .who span{font-size:13px;color:var(--steel)}
.pcs .seen{font-size:13px;color:var(--steel);white-space:nowrap}
.pcs .d{width:10px;height:10px;border-radius:50%;background:#aab6c8;flex:none}
.pcs .d.ok{background:var(--ok-l)} .pcs .d.bad{background:var(--bad-l)}
.row{display:flex;gap:10px;flex-wrap:wrap}
.check{display:flex;gap:12px;align-items:flex-start;padding:9px 0}
.check input{width:18px;height:18px;margin-top:3px;accent-color:var(--blue)}
.check small{display:block;color:var(--steel);font-size:13.5px}
.empty{color:var(--steel);font-size:14px;margin:6px 0}

/* ---------- log ---------- */
.logwrap{max-width:1180px;width:100%;margin:0 auto;padding:0 32px 18px}
@media (max-width:820px){.logwrap{padding:0 18px 14px}}
details.log{border-top:1px solid var(--line);padding-top:14px}
details.log summary{cursor:pointer;font-weight:600;font-size:17px;list-style:none}
details.log summary::-webkit-details-marker{display:none}
details.log summary::before{content:"\25B8";display:inline-block;width:18px;color:var(--steel)}
details.log[open] summary::before{content:"\25BE"}
.tabs{display:flex;gap:6px;margin:12px 0 8px;align-items:center;flex-wrap:wrap}
.tab{border:1px solid var(--line);background:var(--white);border-radius:5px;padding:4px 12px;cursor:pointer;font-size:13.5px}
.tab[aria-selected=true]{background:var(--navy);border-color:var(--navy);color:#fff}
.spacer{flex:1}
pre.logbox{margin:0;background:var(--navy);color:#d5e0f2;border-radius:5px;padding:12px 14px;font:12.5px/1.5 var(--mono);height:230px;overflow:auto;white-space:pre-wrap;word-break:break-word}
footer{border-top:1px solid var(--line);padding:12px 32px;display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;color:var(--steel);font-size:13.5px;background:var(--white)}
@media (max-width:820px){footer{padding:12px 18px}}

/* ---------- toast + dialog ---------- */
#toast{position:fixed;left:32px;bottom:64px;max-width:min(640px,calc(100vw - 64px));background:var(--ink);color:#fff;border-radius:6px;padding:10px 16px;font-size:14px;box-shadow:0 6px 24px rgba(16,29,54,.28);display:none;word-break:break-word}
#toast.bad{background:var(--bad)}
#toast.show{display:block}
#lost{display:none;background:var(--bad);color:#fff;padding:10px 32px;font-weight:600}
#lost.show{display:block}
dialog{border:0;border-radius:8px;padding:0;max-width:460px;width:calc(100vw - 40px);box-shadow:0 18px 60px rgba(16,29,54,.4);color:var(--ink)}
dialog::backdrop{background:rgba(16,29,54,.55)}
dialog .in{padding:22px 24px 8px}
dialog h2{font-size:19px;margin-bottom:8px}
dialog p{margin:0 0 6px;color:var(--steel)}
dialog .acts{display:flex;justify-content:flex-end;gap:10px;padding:16px 24px 22px}
</style>
</head>
<body>
<div id="lost" role="alert">The manager lost contact with the AB Securitas RTI Server app. Close this window and open the app again.</div>

<header class="band">
  <div class="brand"><img alt="" src="data:image/png;base64,__ICON__"><span><b>AB Securitas RTI Server</b> <span id="ver"></span></span></div>
  <div class="band-main">
    <div class="status" aria-live="polite">
      <h1><span class="dot" id="dot"></span><span id="headline">Checking the server</span></h1>
      <p id="detail">One moment.</p>
    </div>
    <div class="band-actions"><button class="btn on-dark" id="btnDashboard" type="button">Open dashboard</button></div>
  </div>
  <div class="pulse" id="pulse" role="img" aria-label="Server availability over the last 10 minutes"></div>
  <div class="pulse-caption"><span>Last 10 minutes: tall green is answering, short red is not answering</span><span id="uptime"></span></div>
</header>

<main>
  <div>
    <section id="connect">
      <h2>Connect phones and Client PCs</h2>
      <p class="lede">Give these addresses to the Android app and to each Client PC.</p>
      <h3>On the office network</h3>
      <div id="lanList"></div>
      <p class="help">Android app: <strong>Settings, Central LAN address</strong>. Client PC: <strong>Central LAN address</strong> on its setup page. Phones must be on the same Wi-Fi as this PC.</p>
      <h3>Over the Internet</h3>
      <p class="help">Use an <strong>https://</strong> address from your own domain, Tailscale Funnel or a cloud server, and enter it as the <strong>Online address</strong> in the Android app and when pairing a Client PC. The README explains each option.</p>
      <div id="dashLan"></div>
    </section>
    <section id="first" hidden>
      <h2>Set up your first company</h2>
      <p class="lede">There are no companies yet. Open the dashboard, sign in as <strong>admin</strong> (password <strong>admin123</strong>, you will be asked to change it), then add a company, its inspectors and checkpoints.</p>
    </section>
  </div>

  <div>
    <section id="activity">
      <h2>Activity</h2>
      <div id="facts"></div>
      <h3>Client PCs</h3>
      <div id="pcs"></div>
    </section>
    <section id="controls">
      <h2>Server</h2>
      <div class="row" style="margin-top:10px">
        <button class="btn" id="btnToggle" type="button">Stop server</button>
        <button class="btn" id="btnRestart" type="button">Restart server</button>
        <button class="btn" id="btnBackup" type="button">Back up now</button>
      </div>
      <div class="row" style="margin-top:6px">
        <button class="btn quiet" id="openData" type="button">Open data folder</button>
        <button class="btn quiet" id="openBackups" type="button">Open backups</button>
        <button class="btn quiet" id="openConfig" type="button">Open settings file</button>
      </div>
    </section>
    <section id="settings">
      <h2>Settings</h2>
      <label class="check"><input type="checkbox" id="optAutostart"><span>Start the server when Windows starts<small id="autostartNote">Runs in the background; open this window from the notification area or the Start menu.</small></span></label>
      <label class="check"><input type="checkbox" id="optLan"><span>Open the dashboard from other PCs on this network<small>Off keeps the dashboard on this PC only. Turn it on only when every admin has a strong password. The server restarts.</small></span></label>
    </section>
  </div>
</main>

<div class="logwrap">
  <details class="log" id="logDetails">
    <summary>Log</summary>
    <div class="tabs" role="tablist">
      <button class="tab" role="tab" id="tabServer" aria-selected="true" type="button">Server</button>
      <button class="tab" role="tab" id="tabApp" aria-selected="false" type="button">This app</button>
      <span class="spacer"></span>
      <button class="btn small" id="logCopy" type="button">Copy</button>
      <button class="btn small" id="logOpen" type="button">Open log folder</button>
    </div>
    <pre class="logbox" id="logBox" tabindex="0" aria-live="off">Nothing logged yet.</pre>
  </details>
</div>

<footer>
  <span id="closeNote">Closing this window keeps the server running.</span>
  <button class="btn danger" id="btnQuit" type="button">Quit and stop server</button>
</footer>

<div id="toast" role="status" aria-live="polite"></div>
<dialog id="dlg"><div class="in"><h2 id="dlgTitle"></h2><p id="dlgText"></p></div><div class="acts"><button class="btn" id="dlgNo" type="button">Cancel</button><button class="btn primary" id="dlgYes" type="button">OK</button></div></dialog>

<script>
"use strict";
const TOKEN = __TOKEN__;
const $ = id => document.getElementById(id);
let state = null, logTab = "server", busy = false, lastOk = Date.now();

async function api(path, options) {
  const r = await fetch(path, Object.assign({headers: {"X-RTI-Token": TOKEN, "Content-Type": "application/json"}}, options || {}));
  let j; try { j = await r.json(); } catch (e) { j = {ok: false, message: "Unreadable answer (HTTP " + r.status + ")"}; }
  if (!r.ok || !j.ok) throw new Error(j.message || ("HTTP " + r.status));
  return j;
}
const act = (name, body) => api("/api/action/" + name, {method: "POST", body: JSON.stringify(body || {})});

let toastTimer = 0;
function toast(text, bad) {
  const t = $("toast"); t.textContent = text; t.className = "show" + (bad ? " bad" : "");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = ""; }, bad ? 9000 : 5000);
}
function ask(title, text, yes) {
  return new Promise(resolve => {
    const d = $("dlg"); $("dlgTitle").textContent = title; $("dlgText").textContent = text; $("dlgYes").textContent = yes || "OK";
    const done = v => { d.close(); resolve(v); };
    $("dlgYes").onclick = () => done(true); $("dlgNo").onclick = () => done(false); d.oncancel = () => resolve(false);
    d.showModal();
  });
}
function ago(s) {
  if (s === null || s === undefined) return "not seen yet";
  if (s < 5) return "just now";
  if (s < 60) return s + " s ago";
  if (s < 3600) return Math.floor(s / 60) + " min ago";
  if (s < 86400) return Math.floor(s / 3600) + " h ago";
  return Math.floor(s / 86400) + " d ago";
}
function span(s) {
  if (s === null || s === undefined) return "";
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return d ? d + " d " + h + " h" : h ? h + " h " + m + " min" : m ? m + " min" : s + " s";
}
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch (e) { const a = document.createElement("textarea"); a.value = text; document.body.appendChild(a); a.select(); document.execCommand("copy"); a.remove(); }
  toast("Copied " + text);
}
function addressRow(url) {
  const row = el("div", "addr"); row.appendChild(el("code", "", url));
  const b = el("button", "btn small", "Copy"); b.type = "button"; b.setAttribute("aria-label", "Copy " + url);
  b.onclick = () => copyText(url); row.appendChild(b); return row;
}

const HEAD = {
  running: ["The server is running", "dot running"], starting: ["The server is starting", "dot starting"],
  stopped: ["The server is stopped", "dot"], error: ["The server needs attention", "dot error"]
};
function render(s) {
  state = s;
  const h = HEAD[s.state] || HEAD.stopped;
  $("headline").textContent = h[0]; $("dot").className = h[1];
  $("detail").textContent = s.state === "stopped" ? "Inspectors' phones keep scanning offline and send their scans when the server is back." : s.message;
  $("ver").textContent = "version " + s.version;
  $("uptime").textContent = (s.uptime_seconds !== null ? "Up " + span(s.uptime_seconds) : "") + (s.restarts ? (s.uptime_seconds !== null ? " · " : "") + "restarted " + s.restarts + (s.restarts === 1 ? " time" : " times") : "");
  const pulse = $("pulse"), N = 120, data = s.pulse.slice(-N);
  const cls = ["down", "up", "off"];
  pulse.replaceChildren();
  for (let i = 0; i < N - data.length; i++) pulse.appendChild(el("i"));
  data.forEach(v => pulse.appendChild(el("i", cls[v] || "off")));
  $("btnToggle").textContent = s.state === "stopped" || s.state === "error" ? "Start server" : "Stop server";
  $("btnDashboard").disabled = s.state === "stopped";

  const lan = $("lanList"); lan.replaceChildren();
  if (!s.addresses.api_lan_enabled) lan.appendChild(el("p", "empty", "The mobile API is limited to this PC, so phones and Client PCs on the network cannot reach it. Open the settings file and set RTI_MOBILE_PROXY_HOST=0.0.0.0, then restart the server."));
  else if (s.addresses.lan.length) s.addresses.lan.forEach(u => lan.appendChild(addressRow(u)));
  else lan.appendChild(el("p", "empty", "No network address found. Connect this PC to the office network, then reopen this window."));
  const dl = $("dashLan"); dl.replaceChildren();
  if (s.addresses.dashboard_lan.length) {
    dl.appendChild(el("h3", "", "Dashboard from other PCs"));
    s.addresses.dashboard_lan.forEach(u => dl.appendChild(addressRow(u)));
  }

  const o = s.overview, facts = $("facts"), pcs = $("pcs");
  facts.replaceChildren(); pcs.replaceChildren();
  $("first").hidden = !(o.available && o.companies === 0);
  if (!o.available) {
    facts.appendChild(el("p", "empty", "Figures appear after the server has started for the first time."));
    pcs.appendChild(el("p", "empty", "No Client PCs yet."));
  } else {
    const dlist = el("dl", "facts");
    [["Active companies", o.companies], ["Active inspectors", o.inspectors], ["Active phones", o.devices], ["Schedules", o.schedules], ["Scans today", o.scans_today]].forEach(([k, v]) => {
      dlist.appendChild(el("dt", "", k)); dlist.appendChild(el("dd", "", v === null ? "-" : String(v)));
    });
    facts.appendChild(dlist);
    if (!o.client_pcs.length) pcs.appendChild(el("p", "empty", "No Client PCs yet. In the dashboard open Schedules & Client Access, then Pair a new Client PC."));
    else {
      const ul = el("ul", "pcs");
      o.client_pcs.forEach(c => {
        const li = el("li"); const live = !c.blocked && c.seen_seconds_ago !== null && c.seen_seconds_ago <= 120;
        li.appendChild(el("span", "d" + (c.blocked ? " bad" : live ? " ok" : "")));
        const who = el("div", "who"); who.appendChild(el("b", "", c.name)); who.appendChild(el("span", "", c.company ? c.company + " · " + c.client_id : c.client_id)); li.appendChild(who);
        li.appendChild(el("span", "seen", c.blocked ? "blocked" : ago(c.seen_seconds_ago))); ul.appendChild(li);
      });
      pcs.appendChild(ul);
    }
  }
  const a = $("optAutostart"), l = $("optLan");
  if (document.activeElement !== a) a.checked = !!s.settings.autostart;
  if (document.activeElement !== l) l.checked = !!s.settings.lan_dashboard;
  a.disabled = !s.settings.autostart_supported;
  $("autostartNote").textContent = s.settings.autostart_supported ? "Runs in the background; open this window from the notification area or the Start menu." : "Available in the installed program.";
  $("closeNote").textContent = s.settings.tray ? "Closing this window keeps the server running. Find it again in the notification area." : "Closing this window stops the server.";
}

async function refresh() {
  try { const s = await api("/api/state"); lastOk = Date.now(); $("lost").className = ""; render(s); }
  catch (e) { if (Date.now() - lastOk > 6000) $("lost").className = "show"; }
}
async function refreshLog() {
  if (!$("logDetails").open) return;
  try {
    const j = await api("/api/log?which=" + logTab + "&lines=300"), box = $("logBox"), stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 30;
    box.textContent = j.text || "Nothing logged yet."; if (stick) box.scrollTop = box.scrollHeight;
  } catch (e) { /* the banner already tells the story */ }
}

async function run(label, fn) {
  if (busy) return; busy = true;
  document.querySelectorAll("button").forEach(b => b.disabled = true);
  try { const j = await fn(); if (j && j.message) toast(j.message); }
  catch (e) { toast(label + ": " + e.message, true); }
  finally { busy = false; document.querySelectorAll("button").forEach(b => b.disabled = false); await refresh(); await refreshLog(); }
}

$("btnDashboard").onclick = () => run("Could not open the dashboard", () => act("open", {what: "dashboard"}));
$("btnToggle").onclick = async () => {
  if (state && (state.state === "stopped" || state.state === "error")) return run("Could not start the server", () => act("start"));
  if (await ask("Stop the server?", "Phones and Client PCs cannot send or receive until it is started again. Phones keep scans offline and send them later.", "Stop server")) run("Could not stop the server", () => act("stop"));
};
$("btnRestart").onclick = async () => { if (await ask("Restart the server?", "It is unavailable for a few seconds.", "Restart")) run("Could not restart the server", () => act("restart")); };
$("btnBackup").onclick = () => run("Backup failed", () => act("backup"));
$("openData").onclick = () => run("Could not open the folder", () => act("open", {what: "data"}));
$("openBackups").onclick = () => run("Could not open the folder", () => act("open", {what: "backups"}));
$("openConfig").onclick = () => run("Could not open the file", () => act("open", {what: "config"}));
$("logOpen").onclick = () => run("Could not open the folder", () => act("open", {what: "logs"}));
$("logCopy").onclick = () => copyText($("logBox").textContent);
$("optAutostart").onchange = e => run("Could not change the setting", () => act("settings", {autostart: e.target.checked}));
$("optLan").onchange = async e => {
  const on = e.target.checked;
  const ok = await ask(on ? "Open the dashboard to other PCs?" : "Keep the dashboard on this PC only?", on ? "Anyone on this network can reach the sign-in page. Use strong admin passwords. The server restarts now." : "Other PCs can no longer open the dashboard. The server restarts now.", on ? "Turn on" : "Turn off");
  if (!ok) { e.target.checked = !on; return; }
  run("Could not change the setting", () => act("settings", {lan_dashboard: on}));
};
$("btnQuit").onclick = async () => {
  if (!await ask("Quit and stop the server?", "Phones and Client PCs cannot reach the server until you start the app again.", "Quit")) return;
  try { await act("quit"); } catch (e) { /* the app closes the connection while quitting */ }
  document.body.replaceChildren(el("p", "", "The server has stopped and the app has quit. You can close this window."));
  document.body.firstChild.style.cssText = "padding:40px;font-size:18px"; setTimeout(() => window.close(), 800);
};
function pickTab(t) { logTab = t; $("tabServer").setAttribute("aria-selected", t === "server"); $("tabApp").setAttribute("aria-selected", t === "app"); refreshLog(); }
$("tabServer").onclick = () => pickTab("server"); $("tabApp").onclick = () => pickTab("app");
$("logDetails").addEventListener("toggle", refreshLog);

refresh(); setInterval(() => { if (!document.hidden && !busy) refresh(); }, 2000); setInterval(refreshLog, 3000);
</script>
</body>
</html>
'''


def render_manager(token: str) -> str:
    """The page, with this run's secret token and the icon filled in."""
    return _MANAGER_HTML.replace("__TOKEN__", json.dumps(token)).replace("__ICON__", ICON_PNG_B64)
