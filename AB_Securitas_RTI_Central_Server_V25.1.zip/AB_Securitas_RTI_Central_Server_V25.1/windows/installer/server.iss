; Inno Setup script - AB Securitas Real Time Inspector, Central Server desktop application for Windows.
; Build (done by GitHub Actions):  iscc /DMyAppVersion=25.1.0 windows\installer\server.iss
#ifndef MyAppVersion
  #define MyAppVersion "0.0.0"
#endif
#define MyAppName "AB Securitas RTI Central Server"
#define MyExe "rti-server.exe"

[Setup]
AppId={{189CD2EA-0B64-465A-95D9-1CFB903BA214}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=AB Securitas
DefaultDirName={autopf}\AB Securitas\RTI Central Server
DefaultGroupName=AB Securitas
DisableProgramGroupPage=yes
OutputDir=..\..\dist-installers
OutputBaseFilename=AB-Securitas-RTI-Server-Setup-{#MyAppVersion}
SetupIconFile=..\assets\rti-server.ico
UninstallDisplayIcon={app}\{#MyExe}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "firewall"; Description: "Allow phones and Client PCs on my private (home/office) network to connect - adds Windows Firewall rules for Private networks only"; GroupDescription: "Network:"
Name: "autostart"; Description: "Start the server automatically when I sign in to Windows (it runs in the notification area)"; GroupDescription: "Startup:"; Flags: unchecked

[Files]
Source: "..\..\dist\rti-server\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\AB Securitas\RTI Central Server"; Filename: "{app}\{#MyExe}"
Name: "{autoprograms}\AB Securitas\RTI Server settings and data folder"; Filename: "{localappdata}\AB Securitas\Real Time Inspector"
Name: "{autodesktop}\RTI Central Server"; Filename: "{app}\{#MyExe}"; Tasks: desktopicon

[Registry]
; Same value the program's own "Start the server when Windows starts" switch uses, so the two always agree.
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "ABSecuritasRTIServer"; ValueData: """{app}\{#MyExe}"" --background"; Tasks: autostart

[InstallDelete]
; Start-up shortcut written by earlier builds (the program now manages start-up itself).
Type: files; Name: "{commonstartup}\RTI Central Server.lnk"

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""AB Securitas RTI Server (Private network)"""; Flags: runhidden; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""AB Securitas RTI Server (Private network)"" dir=in action=allow program=""{app}\{#MyExe}"" enable=yes profile=private"; Flags: runhidden; Tasks: firewall
Filename: "{app}\{#MyExe}"; Description: "Open the RTI Central Server now"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""AB Securitas RTI Server (Private network)"""; Flags: runhidden; RunOnceId: "DelRtiServerFirewall"

; Settings, secrets and the database live in %LOCALAPPDATA%\AB Securitas\Real Time Inspector and are
; deliberately kept when the program is updated or uninstalled.

[Code]
// The server runs as a few background copies of rti-server.exe; stop them so the files can be replaced or removed.
procedure StopRunningServer();
var
  ResultCode: Integer;
begin
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/F /T /IM {#MyExe}', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  StopRunningServer();
  Result := '';
end;

function InitializeUninstall(): Boolean;
begin
  StopRunningServer();
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
    RegDeleteValue(HKEY_CURRENT_USER, 'Software\Microsoft\Windows\CurrentVersion\Run', 'ABSecuritasRTIServer');
end;
