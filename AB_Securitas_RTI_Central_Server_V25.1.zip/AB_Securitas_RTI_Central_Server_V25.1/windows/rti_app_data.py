"""Read-only facts for the manager window (counts, Client PCs, log tail) and the "Back up now" action.

The desktop app never writes to the live database; backups use SQLite's online backup into a new file.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path


def _connect_readonly(db_path: str | Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{Path(db_path).resolve().as_posix()}?mode=ro", uri=True, timeout=2)


def _count(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> int | None:
    try:
        return int(connection.execute(sql, params).fetchone()[0])
    except sqlite3.Error:
        return None


def _seconds_ago(stamp: str | None) -> int | None:
    if not stamp:
        return None
    for pattern in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return max(0, int((datetime.now() - datetime.strptime(stamp[:19], pattern)).total_seconds()))
        except ValueError:
            continue
    return None


def build_overview(db_path: str | Path | None) -> dict:
    """Numbers shown under "Activity". `available` is False until the server has created its database."""
    if not db_path or not Path(db_path).is_file():
        return {"available": False}
    try:
        connection = _connect_readonly(db_path)
    except sqlite3.Error:
        return {"available": False}
    try:
        today = datetime.now().strftime("%Y-%m-%d")
        overview = {
            "available": True,
            "companies": _count(connection, "SELECT COUNT(*) FROM companies WHERE status='ACTIVE'"),
            "inspectors": _count(connection, "SELECT COUNT(*) FROM inspectors WHERE status='ACTIVE'"),
            "devices": _count(connection, "SELECT COUNT(*) FROM devices WHERE status='ACTIVE' AND deleted_at IS NULL"),
            "schedules": _count(connection, "SELECT COUNT(*) FROM schedules WHERE enabled=1"),
            "scans_today": _count(connection, "SELECT COUNT(*) FROM scans WHERE scan_time>=?", (today,)),
            "client_pcs": [],
        }
        try:
            rows = connection.execute(
                "SELECT n.client_id, n.display_name, n.status, n.last_seen_at, COALESCE(c.name,'') "
                "FROM client_nodes n LEFT JOIN companies c ON c.id=n.company_id "
                "ORDER BY COALESCE(n.last_seen_at,'') DESC, n.client_id LIMIT 12").fetchall()
        except sqlite3.Error:
            rows = []
        for client_id, display_name, status, last_seen, company in rows:
            overview["client_pcs"].append({
                "client_id": client_id, "name": (display_name or client_id), "company": company,
                "blocked": status != "ACTIVE", "seen_seconds_ago": _seconds_ago(last_seen),
            })
        return overview
    except sqlite3.Error:
        return {"available": False}
    finally:
        connection.close()


def backup_folder(db_path: str | Path, default_folder: str | Path) -> Path:
    """The folder the Super Admin chose in the dashboard, otherwise the server's default backup folder."""
    try:
        connection = _connect_readonly(db_path)
        try:
            row = connection.execute(
                "SELECT setting_value FROM settings WHERE company_id=0 AND setting_key='backup_directory'").fetchone()
        finally:
            connection.close()
        if row and str(row[0]).strip():
            return Path(str(row[0])).expanduser().resolve()
    except sqlite3.Error:
        pass
    return Path(default_folder).expanduser().resolve()


def backup_now(db_path: str | Path, default_folder: str | Path) -> Path:
    """Write central_<timestamp>.db (the name the dashboard's restore list recognises) and verify it."""
    db_path = Path(db_path).resolve()
    if not db_path.is_file():
        raise FileNotFoundError("The database does not exist yet. Start the server first.")
    folder = backup_folder(db_path, default_folder)
    if folder == db_path.parent:
        raise ValueError("Choose a backup folder other than the live database folder (dashboard > Backups).")
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / f"central_{datetime.now().strftime('%Y%m%dT%H%M%S.%f')}.db"
    temporary = destination.with_name(destination.name + ".tmp")
    source = _connect_readonly(db_path)
    target = sqlite3.connect(str(temporary), timeout=30)
    try:
        source.backup(target, pages=256, sleep=0.05)
        if target.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise sqlite3.DatabaseError("The new backup failed its integrity check.")
        target.commit()
    except Exception:
        target.close()
        source.close()
        temporary.unlink(missing_ok=True)
        raise
    target.close()
    source.close()
    temporary.replace(destination)
    return destination


def tail_text(path: str | Path, lines: int = 300, max_bytes: int = 200_000) -> str:
    """Last lines of a log file (empty text when it does not exist yet)."""
    try:
        with open(path, "rb") as handle:
            handle.seek(0, 2)
            size = handle.tell()
            handle.seek(max(0, size - max_bytes))
            data = handle.read()
    except OSError:
        return ""
    text = data.decode("utf-8", errors="replace")
    return "\n".join(text.splitlines()[-lines:])
