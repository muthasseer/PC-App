"""AB Securitas Real Time Inspector - Central Server engine for Windows.

Runs the Central dashboard/API (port 5000) and the allow-list mobile API proxy (port 5200) in one
process. Phones and Client PCs on the same network use the proxy directly (LAN); publish the same
port online with a domain, reverse proxy, Tailscale Funnel or a cloud VM (online).

In the packaged program this is the *engine* that the desktop application (rti_server_app.py:
manager window, notification-area icon) starts and watches. It can still be run on its own:

    python rti_server_launcher.py                 console-only server, opens the dashboard
    python rti_server_launcher.py --no-browser    console-only server without opening a browser
    python rti_server_launcher.py --selftest      start on temporary ports, verify, exit 0
"""
from __future__ import annotations

import argparse
import atexit
import os
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rti_common as common  # noqa: E402

PRODUCT = "Real Time Inspector"
DEFAULTS_HEADER = (
    "# AB Securitas Real Time Inspector - Central Server configuration.\n"
    "# Edit with Notepad, then restart the server. Never share or upload this file: it holds private secrets."
)


def default_settings() -> dict[str, str]:
    return {
        "RTI_SECRET_KEY": common.new_secret(48),
        # Dashboard: this PC only. Use 0.0.0.0 to open it from other PCs on the LAN or behind a reverse proxy.
        "RTI_WEB_HOST": "127.0.0.1",
        "RTI_WEB_PORT": "5000",
        # Mobile API: 0.0.0.0 lets Android phones and Client PCs on the same Wi-Fi/LAN connect directly.
        "RTI_MOBILE_PROXY_HOST": "0.0.0.0",
        "RTI_MOBILE_PROXY_PORT": "5200",
        "RTI_MIN_POINT_GAP": "8",
        "RTI_COOKIE_SECURE": "0",
        "RTI_TRUST_PROXY": "0",
        # Private Client PC credentials are added automatically by Central > Schedules & Client Access > Pair a new Client PC.
        "RTI_CLIENT_SYNC_TOKENS": "",
        "RTI_CLIENT_NODE_TOKENS": "",
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="AB Securitas RTI Central Server")
    parser.add_argument("--no-browser", action="store_true", help="do not open the dashboard in a browser")
    parser.add_argument("--selftest", action="store_true", help="start on temporary ports, verify, then exit")
    parser.add_argument("--version", action="store_true", help="print the version and exit")
    args = parser.parse_args(argv)

    if args.selftest:
        scratch = Path(tempfile.mkdtemp(prefix="rti-server-selftest-"))
        os.environ["RTI_CONFIG_DIR"] = str(scratch / "config")
        os.environ["RTI_DATA_DIR"] = str(scratch / "data")
        os.environ["RTI_BACKUP_DIR"] = str(scratch / "backups")
        os.environ["RTI_WEB_HOST"] = "127.0.0.1"
        os.environ["RTI_WEB_PORT"] = "5090"
        os.environ["RTI_MOBILE_PROXY_HOST"] = "127.0.0.1"
        os.environ["RTI_MOBILE_PROXY_PORT"] = "5290"
        args.no_browser = True

    config_dir = common.config_directory(PRODUCT)
    env_file = config_dir / "server.env"
    created = common.ensure_env_file(env_file, default_settings(), DEFAULTS_HEADER)
    os.environ["RTI_ENV_FILE"] = str(env_file)
    log_path = common.start_logging(config_dir / "logs", "server")

    # Environment variables set above (selftest) win over the file; the file wins over built-in defaults.
    from dotenv import load_dotenv
    load_dotenv(env_file)

    web_dir = HERE.parent / "Web"
    proxy_dir = HERE.parent / "MobileApiProxy"
    for folder in (web_dir, proxy_dir):
        if folder.is_dir():
            sys.path.insert(0, str(folder))

    import app as central  # noqa: E402  (Web/app.py)
    import proxy  # noqa: E402  (MobileApiProxy/proxy.py)

    if args.version:
        print(central.APP_VERSION)
        return 0

    web_host = os.environ.get("RTI_WEB_HOST", "127.0.0.1")
    web_port = int(os.environ.get("RTI_WEB_PORT", "5000"))
    proxy_host, proxy_port = proxy.HOST, proxy.PORT

    print(f"AB Securitas Real Time Inspector - Central Server {central.APP_VERSION}")
    print(f"Configuration: {env_file}{'  (created now)' if created else ''}")
    print(f"Data folder  : {central.DATA_DIR}")
    print(f"Log file     : {log_path}")

    for label, host, port in (("Dashboard", web_host, web_port), ("Mobile API", proxy_host, proxy_port)):
        if common.port_in_use(host, port):
            common.pause_before_exit(f"ERROR: {label} port {port} is already in use. Is the server already running? "
                                     f"Close the other copy or change the port in {env_file}.")
            return 2

    # Tell the desktop app (and anyone else) which engine is running and where its files are.
    engine_file = config_dir / "engine.json"
    common.write_json_atomic(engine_file, {
        "pid": os.getpid(), "version": central.APP_VERSION, "started_at": time.time(),
        "web_host": web_host, "web_port": web_port, "proxy_host": proxy_host, "proxy_port": proxy_port,
        "data_dir": str(central.DATA_DIR), "db_path": str(central.DB), "backup_dir": str(central.DEFAULT_BACKUP_DIR),
        "log_file": str(log_path), "config_file": str(env_file),
    })

    def _forget_engine():
        if common.read_json(engine_file).get("pid") == os.getpid():
            try:
                engine_file.unlink()
            except OSError:
                pass

    atexit.register(_forget_engine)

    common.start_thread(common.serve_wsgi, "rti-web", central.app, web_host, web_port)

    server = proxy.ThreadingHTTPServer((proxy_host, proxy_port), proxy.MobileApiProxy)
    server.daemon_threads = True
    common.start_thread(server.serve_forever, "rti-mobile-proxy")

    dashboard_url = f"http://127.0.0.1:{web_port}/"
    if not common.wait_for_http(dashboard_url + "api/mobile/health"):
        common.pause_before_exit("ERROR: the dashboard did not start. See the log file above.")
        return 3

    if args.selftest:
        ok = common.wait_for_http(f"http://127.0.0.1:{proxy_port}/api/mobile/health", 10, accept_any_answer=False)
        print("SELFTEST OK" if ok else "SELFTEST FAILED: mobile proxy did not answer")
        return 0 if ok else 4

    print()
    print(f"Dashboard (this PC) : {dashboard_url}")
    if web_host not in ("127.0.0.1", "localhost"):
        for address in common.lan_addresses():
            print(f"Dashboard (network) : http://{address}:{web_port}/")
    if proxy_host not in ("127.0.0.1", "localhost"):
        for address in common.lan_addresses():
            print(f"LAN address for phones / Client PCs : http://{address}:{proxy_port}")
    print("Online access: publish port", proxy_port, "with your domain / reverse proxy / Tailscale Funnel (see the guide).")
    print("First sign-in: user 'admin' - follow the on-screen password change. Keep this window open; close it to stop the server.")
    if not args.no_browser:
        common.open_browser_later(dashboard_url)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("Stopping...")
    finally:
        server.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
