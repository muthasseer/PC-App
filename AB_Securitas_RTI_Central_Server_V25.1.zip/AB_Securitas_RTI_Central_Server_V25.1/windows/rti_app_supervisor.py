"""Keeps the Central Server engine (a child process of the desktop app) running and reports its health.

The engine is the existing server (dashboard on the web port + mobile API proxy). Running it as a separate process means
a crash never takes the window down, Stop/Restart are exact, and an engine left running by an earlier app window is
adopted instead of started twice.
"""
from __future__ import annotations

import collections
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import rti_common as common

START_TIMEOUT_SECONDS = 90
PROBE_SECONDS = 5
MAX_QUICK_FAILURES = 5
BACKOFF_SECONDS = (2, 5, 10, 20, 30)
PULSE_LENGTH = 120  # 10 minutes of 5-second samples

STOPPED, STARTING, RUNNING, ERROR = "stopped", "starting", "running", "error"


def runtime_endpoints(env_file: Path) -> dict:
    """Ports/hosts the engine will use: process environment first, then server.env, then the built-in defaults."""
    values = common.read_env_values(env_file)

    def pick(key: str, default: str) -> str:
        return os.environ.get(key, "").strip() or values.get(key, "").strip() or default

    def port(key: str, default: int) -> int:
        try:
            return int(pick(key, str(default)))
        except ValueError:
            return default

    return {
        "web_host": pick("RTI_WEB_HOST", "127.0.0.1"), "web_port": port("RTI_WEB_PORT", 5000),
        "proxy_host": pick("RTI_MOBILE_PROXY_HOST", "127.0.0.1"), "proxy_port": port("RTI_MOBILE_PROXY_PORT", 5200),
    }


def probe(port: int, timeout: float = 2.0) -> bool:
    """The Central health endpoint must answer 200 JSON with ok=true."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/mobile/health", timeout=timeout) as response:
            return response.status == 200 and b'"ok"' in response.read(2048)
    except (urllib.error.URLError, OSError, ValueError):
        return False


class EngineSupervisor:
    def __init__(self, config_dir: Path, command: list[str], env: dict | None = None, log=print):
        self.config_dir = Path(config_dir)
        self.env_file = self.config_dir / "server.env"
        self.engine_file = self.config_dir / "engine.json"
        self.command = list(command)
        self.env = dict(env) if env is not None else dict(os.environ)
        self.log = log
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._stop_thread = threading.Event()
        self._thread: threading.Thread | None = None
        self._proc: subprocess.Popen | None = None
        self._adopted_pid = 0
        self.desired_running = False
        self.state = STOPPED
        self.message = "The server is stopped."
        self.started_at = 0.0
        self.restarts = 0
        self._quick_failures = 0
        self._next_spawn_at = 0.0
        self.pulse: collections.deque[int] = collections.deque(maxlen=PULSE_LENGTH)
        self._pulse_at = 0.0
        self._health_at = 0.0
        self._web_ok = False
        self._api_ok = False

    # ----- public control -------------------------------------------------------------------------------------
    def start_thread(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_thread.clear()
        self._thread = threading.Thread(target=self._loop, name="rti-engine-supervisor", daemon=True)
        self._thread.start()

    def start(self) -> None:
        with self._lock:
            self.desired_running = True
            self._quick_failures = 0
            self._next_spawn_at = 0.0
            if self.state in (STOPPED, ERROR):
                self.state, self.message = STARTING, "Starting the server..."
        self._wake.set()

    def stop(self, wait: bool = True) -> None:
        with self._lock:
            self.desired_running = False
            self._terminate_locked()
            self.state, self.message = STOPPED, "The server is stopped."
            self._web_ok = self._api_ok = False
        self._wake.set()

    def restart(self) -> None:
        self.stop()
        self.start()

    def shutdown(self) -> None:
        """Stop the engine and the supervisor thread (application exit)."""
        self.stop()
        self._stop_thread.set()
        self._wake.set()
        if self._thread:
            self._thread.join(timeout=5)

    def wait_until(self, state: str, timeout: float) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.state == state:
                return True
            time.sleep(0.2)
        return self.state == state

    # ----- status ---------------------------------------------------------------------------------------------
    def snapshot(self) -> dict:
        with self._lock:
            uptime = int(time.time() - self.started_at) if self.state == RUNNING and self.started_at else None
            return {
                "state": self.state, "message": self.message, "uptime_seconds": uptime, "restarts": self.restarts,
                "pulse": list(self.pulse), "web_ok": self._web_ok, "api_ok": self._api_ok,
                "adopted": bool(self._adopted_pid),
            }

    def engine_info(self) -> dict:
        return common.read_json(self.engine_file)

    # ----- internals ------------------------------------------------------------------------------------------
    def _alive_locked(self) -> bool:
        if self._proc is not None:
            return self._proc.poll() is None
        if self._adopted_pid:
            return common.pid_alive(self._adopted_pid)
        return False

    def _terminate_locked(self) -> None:
        proc, pid = self._proc, self._adopted_pid
        self._proc, self._adopted_pid = None, 0
        if proc is not None:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=5)
        elif pid:
            common.terminate_pid(pid)
            deadline = time.time() + 8
            while common.pid_alive(pid) and time.time() < deadline:
                time.sleep(0.1)

    def _adopt_locked(self) -> bool:
        info = self.engine_info()
        pid = info.get("pid")
        endpoints = runtime_endpoints(self.env_file)
        if isinstance(pid, int) and common.pid_alive(pid) and probe(endpoints["web_port"]):
            self._adopted_pid = pid
            self.started_at = float(info.get("started_at") or time.time())
            self.log(f"Adopted the server that is already running (process {pid}).")
            return True
        return False

    def _spawn_locked(self) -> None:
        kwargs = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL, "env": self.env}
        if os.name == "nt":
            kwargs["creationflags"] = 0x08000000 | 0x00000200  # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
        self._proc = subprocess.Popen(self.command, **kwargs)
        self.started_at = time.time()
        self.state, self.message = STARTING, "Starting the server..."
        self.log(f"Server engine started (process {self._proc.pid}).")

    def _last_error_line(self) -> str:
        log_file = self.engine_info().get("log_file") or str(self.config_dir / "logs" / "server.log")
        try:
            lines = Path(log_file).read_text(encoding="utf-8", errors="replace").splitlines()[-60:]
        except OSError:
            return ""
        for line in reversed(lines):
            if "ERROR" in line or "Traceback" in line or "Error:" in line:
                return line.strip()[:300]
        return ""

    def _loop(self) -> None:
        while not self._stop_thread.is_set():
            try:
                self._tick()
            except Exception as error:  # the supervisor must never die
                self.log(f"Supervisor error: {error}")
            self._wake.wait(1.0)
            self._wake.clear()

    def _tick(self) -> None:
        with self._lock:
            if not self.desired_running:
                self._sample(2)
                return
            if not self._alive_locked():
                self._on_not_alive_locked()
                return
        self._check_health()

    def _sample(self, code: int) -> None:
        now = time.time()
        if now - self._pulse_at >= PROBE_SECONDS:
            self._pulse_at = now
            self.pulse.append(code)

    def _on_not_alive_locked(self) -> None:
        was_running = self._proc is not None or self._adopted_pid
        exit_code = self._proc.returncode if self._proc is not None else None
        self._proc, self._adopted_pid = None, 0
        now = time.time()
        if was_running:
            ran_for = now - self.started_at
            reason = self._last_error_line() or f"The server stopped unexpectedly (exit code {exit_code})."
            self.log(f"Server engine ended after {int(ran_for)} s: {reason}")
            if ran_for < 30:
                self._quick_failures += 1
            else:
                self._quick_failures = 0
            self.restarts += 1
            self.message = reason
            self._web_ok = self._api_ok = False
            self._sample(0)
            if self._quick_failures >= MAX_QUICK_FAILURES:
                self.state = ERROR
                self.desired_running = False
                self.message = f"{reason} The server will not restart by itself; fix the problem, then press Start."
                return
            delay = BACKOFF_SECONDS[min(self._quick_failures, len(BACKOFF_SECONDS) - 1)]
            self._next_spawn_at = now + delay
            self.state = STARTING
            return
        if now < self._next_spawn_at:
            return
        if self._adopt_locked():
            self.state, self.message = RUNNING, "The server is running."
            return
        self._spawn_locked()

    def _check_health(self) -> None:
        now = time.time()
        interval = 1.0 if self.state != RUNNING else PROBE_SECONDS
        if now - self._health_at < interval:
            return
        self._health_at = now
        endpoints = runtime_endpoints(self.env_file)
        web_ok = probe(endpoints["web_port"])
        api_ok = probe(endpoints["proxy_port"])
        with self._lock:
            if not self.desired_running:
                return
            self._web_ok, self._api_ok = web_ok, api_ok
            if web_ok and api_ok:
                if self.state != RUNNING:
                    self.log("The server is running.")
                self.state, self.message = RUNNING, "The dashboard and the mobile API are answering."
                self._quick_failures = 0 if now - self.started_at > 30 else self._quick_failures
                self._sample(1)
            else:
                self._sample(0)
                waiting = now - self.started_at
                if self.state == RUNNING:
                    self.state = STARTING
                    self.message = "The server is not answering."
                elif waiting > START_TIMEOUT_SECONDS:
                    self.state = ERROR
                    self.message = (self._last_error_line()
                                    or "The server started but is not answering. Open the log for details.")


def engine_command(app_script: Path) -> list[str]:
    """Command that starts the engine: the packaged exe itself, or this Python with the app script."""
    if common.is_frozen():
        return [sys.executable, "--engine"]
    return [sys.executable, str(app_script), "--engine"]
