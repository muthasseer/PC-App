"""Version shown by the desktop app. Keep equal to APP_VERSION in Web/app.py (a unit test checks this)."""
APP_VERSION = "25.1.0"
