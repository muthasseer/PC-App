"""Tiny local web server behind the manager window (127.0.0.1 only, random port, per-run secret token).

It is separate from the Central Server on purpose: nothing here is reachable from the network, and the Central
Server's own ports and routes are not touched.
"""
from __future__ import annotations

import hmac
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

MAX_BODY = 16 * 1024
PAGE_CSP = ("default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; "
            "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")


class ControlServer:
    def __init__(self, token: str, render_page, get_state, get_log, actions: dict, port: int = 0):
        self.token = token
        self._render_page, self._get_state, self._get_log, self._actions = render_page, get_state, get_log, actions
        server = self
        # the allowed Host header values are filled in once the real port is known
        self.allowed_hosts: set[str] = set()

        class Handler(BaseHTTPRequestHandler):
            server_version = "RTIManager"
            protocol_version = "HTTP/1.0"

            def log_message(self, *args):  # keep the app quiet
                pass

            # ----- helpers -----
            def _send(self, status: int, body: bytes, content_type: str, extra: dict | None = None):
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                for key, value in (extra or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)

            def _json(self, status: int, payload: dict):
                self._send(status, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

            def _host_ok(self) -> bool:
                return (self.headers.get("Host") or "").lower() in server.allowed_hosts

            def _token_ok(self, supplied: str | None) -> bool:
                return bool(supplied) and hmac.compare_digest(str(supplied), server.token)

            # ----- routes -----
            def do_GET(self):
                if not self._host_ok():
                    return self._json(403, {"ok": False, "message": "Unexpected host."})
                parts = urlsplit(self.path)
                query = parse_qs(parts.query)
                if parts.path == "/":
                    if not self._token_ok((query.get("t") or [""])[0]):
                        return self._json(403, {"ok": False, "message": "Open this page from the AB Securitas RTI Server app."})
                    page = server._render_page(server.token).encode("utf-8")
                    return self._send(200, page, "text/html; charset=utf-8", {"Content-Security-Policy": PAGE_CSP})
                if not self._token_ok(self.headers.get("X-RTI-Token")):
                    return self._json(403, {"ok": False, "message": "Not allowed."})
                if parts.path == "/api/ping":
                    return self._json(200, {"ok": True})
                if parts.path == "/api/state":
                    return self._json(200, {"ok": True, **server._get_state()})
                if parts.path == "/api/log":
                    which = (query.get("which") or ["server"])[0]
                    try:
                        lines = max(20, min(1000, int((query.get("lines") or ["300"])[0])))
                    except ValueError:
                        lines = 300
                    text = server._get_log(which, lines)
                    return self._json(200, {"ok": True, "text": text})
                return self._json(404, {"ok": False, "message": "Unknown request."})

            def do_POST(self):
                if not self._host_ok() or not self._token_ok(self.headers.get("X-RTI-Token")):
                    return self._json(403, {"ok": False, "message": "Not allowed."})
                parts = urlsplit(self.path)
                prefix = "/api/action/"
                if not parts.path.startswith(prefix):
                    return self._json(404, {"ok": False, "message": "Unknown request."})
                name = parts.path[len(prefix):]
                action = server._actions.get(name)
                if action is None:
                    return self._json(404, {"ok": False, "message": "Unknown action."})
                try:
                    length = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    length = 0
                if length > MAX_BODY:
                    return self._json(413, {"ok": False, "message": "Request too large."})
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw.decode("utf-8")) if raw else {}
                    if not isinstance(body, dict):
                        raise ValueError("Send a JSON object.")
                except ValueError:
                    return self._json(400, {"ok": False, "message": "Send a JSON object."})
                try:
                    result = action(body) or {}
                except ValueError as error:
                    return self._json(400, {"ok": False, "message": str(error)})
                except Exception as error:  # report the reason in the window instead of a blank failure
                    return self._json(500, {"ok": False, "message": str(error) or error.__class__.__name__})
                return self._json(200, {"ok": True, **result})

        self._httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self._httpd.daemon_threads = True
        self.port = self._httpd.server_address[1]
        self.allowed_hosts = {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/?t={self.token}"

    def start(self) -> None:
        self._thread = threading.Thread(target=self._httpd.serve_forever, name="rti-manager-control", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        try:
            if self._thread is not None:  # shutdown() waits for serve_forever, so only call it when that is running
                self._httpd.shutdown()
            self._httpd.server_close()
        except OSError:
            pass
