"""Shared helpers for the packaged Windows apps (Central Server and Client PC)."""
from __future__ import annotations

import json
import os
import secrets
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

VENDOR_DIR_NAME = "AB Securitas"


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def app_directory() -> Path:
    """Folder that holds the .exe (or the repository root when run from source)."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def config_directory(product: str) -> Path:
    """Per-user, writable configuration folder (never inside Program Files)."""
    override = os.environ.get("RTI_CONFIG_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    return (root / VENDOR_DIR_NAME / product).resolve()


def read_env_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key, value = stripped.split("=", 1)
            values[key.strip()] = value.strip()
    return values


def ensure_env_file(path: Path, defaults: dict[str, str], header: str) -> bool:
    """Create the env file on first run, and add any missing keys later without touching existing values."""
    path.parent.mkdir(parents=True, exist_ok=True)
    created = not path.exists()
    existing = read_env_values(path)
    missing = {key: value for key, value in defaults.items() if key not in existing}
    if created:
        lines = [header, ""] + [f"{key}={value}" for key, value in defaults.items()]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif missing:
        with path.open("a", encoding="utf-8") as handle:
            handle.write("\n# Added by an update\n")
            for key, value in missing.items():
                handle.write(f"{key}={value}\n")
    if os.name != "nt":
        path.chmod(0o600)
    return created


def update_env_values(path: Path, updates: dict[str, str]) -> None:
    """Set keys in an env file in place (comments and other lines are kept); missing keys are appended."""
    for key, value in updates.items():
        if not key.replace("_", "").isalnum() or any(ch in str(value) for ch in "\r\n"):
            raise ValueError(f"Invalid environment setting: {key}")
    path = Path(path)
    lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    remaining = {key: str(value) for key, value in updates.items()}
    output: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in remaining:
                output.append(f"{key}={remaining.pop(key)}")
                continue
        output.append(line)
    output.extend(f"{key}={value}" for key, value in remaining.items())
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text("\n".join(output) + "\n", encoding="utf-8")
    if os.name != "nt":
        temporary.chmod(0o600)
    os.replace(temporary, path)


def write_json_atomic(path: Path, data: dict, private: bool = True) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
    if private and os.name != "nt":
        temporary.chmod(0o600)
    os.replace(temporary, path)


def read_json(path: Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def pid_alive(pid: int) -> bool:
    """True while a process with this id is running (never signals it on Windows)."""
    if not isinstance(pid, int) or pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            return bool(kernel32.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    # A zombie child still answers signal 0; treat it as gone.
    try:
        with open(f"/proc/{pid}/stat", encoding="utf-8") as handle:
            return handle.read().rsplit(")", 1)[-1].split()[0] != "Z"
    except OSError:
        return True


def terminate_pid(pid: int) -> None:
    import signal
    try:
        os.kill(pid, signal.SIGTERM)  # on Windows this ends the process
    except (OSError, ValueError):
        pass


def new_secret(length: int = 48) -> str:
    return secrets.token_urlsafe(length)


class _Tee:
    """Mirror console output into the log file so problems can be diagnosed after the window closes."""

    def __init__(self, stream, handle):
        self._stream, self._handle = stream, handle

    def write(self, text):
        for target in (self._stream, self._handle):
            try:
                if target:
                    target.write(text)
            except (OSError, ValueError):
                pass
        return len(text)

    def flush(self):
        for target in (self._stream, self._handle):
            try:
                if target:
                    target.flush()
            except (OSError, ValueError):
                pass

    def isatty(self):
        return False


def start_logging(log_dir: Path, name: str) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{name}.log"
    try:
        if log_path.exists() and log_path.stat().st_size > 2 * 1024 * 1024:
            log_path.replace(log_dir / f"{name}.previous.log")
    except OSError:
        pass
    handle = open(log_path, "a", encoding="utf-8", buffering=1)
    handle.write(f"\n===== {datetime.now():%Y-%m-%d %H:%M:%S} {name} started =====\n")
    sys.stdout = _Tee(sys.stdout, handle)
    sys.stderr = _Tee(sys.stderr, handle)
    return log_path


def port_in_use(host: str, port: int) -> bool:
    probe_host = "127.0.0.1" if host in ("0.0.0.0", "", "::") else host
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.7)
        return probe.connect_ex((probe_host, port)) == 0


def lan_addresses() -> list[str]:
    found: set[str] = set()
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("192.0.2.1", 80))
            found.add(probe.getsockname()[0])
        finally:
            probe.close()
    except OSError:
        pass
    try:
        for result in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
            address = result[4][0]
            if not address.startswith("127."):
                found.add(address)
    except OSError:
        pass
    return sorted(found)


def wait_for_http(url: str, timeout: float = 25.0, accept_any_answer: bool = True) -> bool:
    """Wait until the URL answers. With accept_any_answer=False only a 2xx response counts."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                response.read(256)
                return True
        except urllib.error.HTTPError:
            if accept_any_answer:
                return True  # any HTTP answer proves the server is up
            time.sleep(0.4)
        except (urllib.error.URLError, OSError, TimeoutError):
            time.sleep(0.4)
    return False


def serve_wsgi(wsgi_app, host: str, port: int, threads: int = 8) -> None:
    """Production WSGI server (waitress); falls back to Flask's built-in server if waitress is missing."""
    try:
        from waitress import serve
    except ImportError:
        import logging

        class _QuietHealth(logging.Filter):
            def filter(self, record):
                return "/api/mobile/health" not in record.getMessage()

        logging.getLogger("werkzeug").addFilter(_QuietHealth())
        wsgi_app.run(host=host, port=port, debug=False, use_reloader=False, threaded=True)
        return
    serve(wsgi_app, host=host, port=port, threads=threads, ident="AB-Securitas-RTI", channel_timeout=60)


def start_thread(target, name: str, *args) -> threading.Thread:
    thread = threading.Thread(target=target, name=name, args=args, daemon=True)
    thread.start()
    return thread


def open_browser_later(url: str, delay: float = 1.5) -> None:
    def _open():
        time.sleep(delay)
        try:
            webbrowser.open(url, new=2)
        except webbrowser.Error:
            pass

    start_thread(_open, "open-browser")


def pause_before_exit(message: str) -> None:
    """Keep a double-clicked console window readable when startup fails."""
    print(message)
    if is_frozen() and sys.stdin and sys.stdin.isatty():
        try:
            input("Press Enter to close this window...")
        except EOFError:
            pass
