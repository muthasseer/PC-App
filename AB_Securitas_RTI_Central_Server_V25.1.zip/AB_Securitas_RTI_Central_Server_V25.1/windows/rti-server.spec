# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec: AB Securitas Real Time Inspector - Central Server desktop application
# (manager window + notification-area icon + the server engine: dashboard and mobile API proxy).
# Build:  pyinstaller --noconfirm --clean windows/rti-server.spec     ->  dist/rti-server/rti-server.exe
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules

ROOT = Path(SPECPATH).resolve().parent

a = Analysis(
    [str(ROOT / "windows" / "rti_server_app.py")],
    pathex=[str(ROOT / "windows"), str(ROOT / "Web"), str(ROOT / "MobileApiProxy")],
    binaries=[],
    datas=[],
    hiddenimports=["app", "rti_v15", "proxy", "dotenv", "qrcode", "PIL.Image", "PIL.ImageDraw",
                   "rti_common", "rti_server_launcher", "rti_version", "rti_app_control", "rti_app_data",
                   "rti_app_supervisor", "rti_app_system", "rti_app_ui",
                   "pystray", "pystray._base", "pystray._util", "pystray._util.win32", "pystray._win32", "six"]
    + collect_submodules("waitress") + collect_submodules("qrcode") + collect_submodules("pystray"),
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="rti-server",
    debug=False,
    strip=False,
    upx=False,
    console=False,  # a normal Windows program: no black console window
    icon=str(ROOT / "windows" / "assets" / "rti-server.ico"),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="rti-server")
