"""AB Securitas Real Time Inspector - Central Server desktop application.

A normal Windows program for the server PC:
  * a manager window (status, phone/Client PC addresses, activity, start/stop/restart, backup, log),
  * the admin dashboard in its own application window (Edge or Chrome without tabs or an address bar),
  * a notification-area icon so the server keeps running when the windows are closed,
  * the server itself (dashboard + mobile API) runs as a separate engine process that is restarted if it ever stops.

    rti-server.exe               open the manager window (starts the server if it is not running)
    rti-server.exe --background  start the server without a window (Start with Windows)
    rti-server.exe --engine      internal: run the server engine in this process
    rti-server.exe --selftest    start on temporary ports, check everything, exit 0 (used by the build pipeline)
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rti_app_control as control  # noqa: E402
import rti_app_data as data  # noqa: E402
import rti_app_supervisor as supervisor_module  # noqa: E402
import rti_app_system as system  # noqa: E402
import rti_app_ui as ui  # noqa: E402
import rti_common as common  # noqa: E402
import rti_server_launcher as launcher  # noqa: E402
from rti_version import APP_VERSION  # noqa: E402

LOOPBACK = ("127.0.0.1", "localhost", "::1")


class DesktopApp:
    def __init__(self, background: bool = False):
        self.background = background
        self.config_dir = common.config_directory(launcher.PRODUCT)
        self.env_file = self.config_dir / "server.env"
        self.app_file = self.config_dir / "app.json"
        common.ensure_env_file(self.env_file, launcher.default_settings(), launcher.DEFAULTS_HEADER)
        self.token = secrets.token_urlsafe(24)
        self.quit_event = threading.Event()
        self._lock = threading.Lock()
        self.manager_proc = None
        self.manager_opened_at = 0.0
        self.dashboard_procs: list = []
        self._overview_cache = (0.0, {"available": False})
        self.supervisor = supervisor_module.EngineSupervisor(
            self.config_dir, supervisor_module.engine_command(Path(__file__).resolve()), log=self.log)
        self.control = control.ControlServer(
            self.token, ui.render_manager, self.state, self.log_text,
            {"start": self.a_start, "stop": self.a_stop, "restart": self.a_restart, "open": self.a_open,
             "backup": self.a_backup, "settings": self.a_settings, "quit": self.a_quit, "show": self.a_show})
        self.tray = system.Tray(system.decode_png(ui.ICON_PNG_B64), "AB Securitas RTI Server",
                                self.open_manager, self.open_dashboard, self.restart_async, self.request_quit)

    # ----- logging ----------------------------------------------------------------------------------------------
    def log(self, message: str) -> None:
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {message}", flush=True)

    def log_text(self, which: str, lines: int) -> str:
        if which == "app":
            path = self.config_dir / "logs" / "app.log"
        else:
            path = Path(self.supervisor.engine_info().get("log_file") or (self.config_dir / "logs" / "server.log"))
        return data.tail_text(path, lines)

    # ----- facts for the window ---------------------------------------------------------------------------------
    def endpoints(self) -> dict:
        return supervisor_module.runtime_endpoints(self.env_file)

    def info_paths(self) -> dict:
        info = self.supervisor.engine_info()
        data_dir = Path(info.get("data_dir") or os.environ.get("RTI_DATA_DIR") or (self.config_dir / "data"))
        db_path = info.get("db_path") or str(data_dir / "inspector.db")
        backup_dir = info.get("backup_dir") or os.environ.get("RTI_BACKUP_DIR") or str(Path(db_path).parent / "backups")
        return {"data_dir": data_dir, "db_path": db_path, "backup_dir": backup_dir}

    def overview(self) -> dict:
        stamp, cached = self._overview_cache
        if time.time() - stamp < 2:
            return cached
        fresh = data.build_overview(self.info_paths()["db_path"])
        self._overview_cache = (time.time(), fresh)
        return fresh

    def state(self) -> dict:
        snapshot = self.supervisor.snapshot()
        endpoints = self.endpoints()
        api_lan = endpoints["proxy_host"] not in LOOPBACK
        web_lan = endpoints["web_host"] not in LOOPBACK
        addresses = common.lan_addresses()
        return {
            **snapshot, "version": APP_VERSION,
            "addresses": {
                "dashboard": f"http://127.0.0.1:{endpoints['web_port']}/",
                "api_lan_enabled": api_lan,
                "lan": [f"http://{address}:{endpoints['proxy_port']}" for address in addresses] if api_lan else [],
                "dashboard_lan": [f"http://{address}:{endpoints['web_port']}/" for address in addresses] if web_lan else [],
            },
            "ports": {"dashboard": endpoints["web_port"], "api": endpoints["proxy_port"]},
            "overview": self.overview(),
            "settings": {"autostart": system.autostart_enabled(), "autostart_supported": system.autostart_supported(),
                         "lan_dashboard": web_lan, "tray": self.tray.available},
            "paths": {"config": str(self.env_file), "data": str(self.info_paths()["data_dir"])},
        }

    # ----- windows ----------------------------------------------------------------------------------------------
    def open_manager(self) -> None:
        with self._lock:
            if self.manager_proc is not None and self.manager_proc.poll() is None and system.focus_window():
                return
            # No window to bring forward (closed, or hidden by a lingering browser process): open a fresh one.
            self.manager_proc = system.open_app_window(self.control.url, self.config_dir / "window-manager", (1100, 800))
            self.manager_opened_at = time.time()

    def open_dashboard(self) -> None:
        url = self.state()["addresses"]["dashboard"]
        proc = system.open_app_window(url, self.config_dir / "window-dashboard", (1320, 880))
        if proc is not None:
            self.dashboard_procs = [p for p in self.dashboard_procs if p.poll() is None] + [proc]

    # ----- actions (called from the manager window) ------------------------------------------------------------
    def a_start(self, body) -> dict:
        self.supervisor.start()
        return {"message": "Starting the server."}

    def a_stop(self, body) -> dict:
        self.supervisor.stop()
        return {"message": "The server is stopped."}

    def a_restart(self, body) -> dict:
        self.supervisor.restart()
        return {"message": "Restarting the server."}

    def a_open(self, body) -> dict:
        what = str(body.get("what", ""))
        paths = self.info_paths()
        if what == "dashboard":
            self.open_dashboard()
        elif what == "data":
            Path(paths["data_dir"]).mkdir(parents=True, exist_ok=True)
            if not system.open_path(Path(paths["data_dir"])):
                raise RuntimeError("Could not open the data folder.")
        elif what == "backups":
            folder = data.backup_folder(paths["db_path"], paths["backup_dir"])
            folder.mkdir(parents=True, exist_ok=True)
            if not system.open_path(folder):
                raise RuntimeError("Could not open the backups folder.")
        elif what == "logs":
            (self.config_dir / "logs").mkdir(parents=True, exist_ok=True)
            if not system.open_path(self.config_dir / "logs"):
                raise RuntimeError("Could not open the log folder.")
        elif what == "config":
            if not system.open_in_editor(self.env_file):
                raise RuntimeError("Could not open the settings file.")
        else:
            raise ValueError("Unknown item.")
        return {}

    def a_backup(self, body) -> dict:
        paths = self.info_paths()
        destination = data.backup_now(paths["db_path"], paths["backup_dir"])
        self.log(f"Backup written: {destination}")
        return {"message": f"Backup saved: {destination}"}

    def a_settings(self, body) -> dict:
        changed = []
        if "autostart" in body:
            system.set_autostart(bool(body["autostart"]))
            changed.append("Start with Windows " + ("on" if body["autostart"] else "off"))
        if "lan_dashboard" in body:
            wanted = "0.0.0.0" if body["lan_dashboard"] else "127.0.0.1"
            common.update_env_values(self.env_file, {"RTI_WEB_HOST": wanted})
            self.supervisor.restart()
            changed.append("Dashboard " + ("open to the network" if body["lan_dashboard"] else "limited to this PC"))
        if not changed:
            raise ValueError("Nothing to change.")
        return {"message": "Saved: " + "; ".join(changed) + "."}

    def a_quit(self, body) -> dict:
        threading.Timer(0.3, self.request_quit).start()
        return {"message": "Quitting."}

    def a_show(self, body) -> dict:
        self.open_manager()
        return {}

    def restart_async(self) -> None:
        threading.Thread(target=self.supervisor.restart, daemon=True).start()

    def request_quit(self) -> None:
        self.quit_event.set()

    # ----- lifecycle --------------------------------------------------------------------------------------------
    def another_instance_running(self) -> bool:
        existing = common.read_json(self.app_file)
        port, token, pid = existing.get("port"), existing.get("token"), existing.get("pid")
        if not (isinstance(port, int) and isinstance(token, str) and common.pid_alive(pid)):
            return False
        try:
            request = urllib.request.Request(f"http://127.0.0.1:{port}/api/action/show", data=b"{}", method="POST",
                                             headers={"X-RTI-Token": token, "Content-Type": "application/json"})
            if self.background:
                request = urllib.request.Request(f"http://127.0.0.1:{port}/api/ping", headers={"X-RTI-Token": token})
            with urllib.request.urlopen(request, timeout=4) as response:
                return response.status == 200
        except (urllib.error.URLError, OSError, ValueError):
            return False

    def start_services(self) -> None:
        self.control.start()
        common.write_json_atomic(self.app_file, {"pid": os.getpid(), "port": self.control.port, "token": self.token,
                                                 "started_at": time.time()})
        self.supervisor.start_thread()
        self.supervisor.start()

    def shutdown(self) -> None:
        self.log("Quitting: stopping the server.")
        self.tray.stop()
        self.supervisor.shutdown()
        self.control.stop()
        for proc in [self.manager_proc, *self.dashboard_procs]:
            if proc is not None and proc.poll() is None:
                proc.terminate()
        try:
            if common.read_json(self.app_file).get("pid") == os.getpid():
                self.app_file.unlink()
        except OSError:
            pass

    def run(self) -> int:
        if self.another_instance_running():
            return 0
        self.start_services()
        self.log(f"AB Securitas RTI Server {APP_VERSION} is running. Manager: port {self.control.port}.")
        tray_ok = self.tray.start()
        if not self.background or not tray_ok:
            self.open_manager()
        try:
            while not self.quit_event.wait(0.5):
                proc = self.manager_proc
                if proc is not None and proc.poll() is not None:
                    self.manager_proc = None
                    # A window that vanished within seconds was handed to an already running browser: keep going.
                    if time.time() - self.manager_opened_at > 3 and not self.tray.available:
                        self.log("The manager window was closed and there is no notification-area icon: quitting.")
                        break
        except KeyboardInterrupt:
            pass
        finally:
            self.shutdown()
        return 0


# ----- self test (build pipeline) --------------------------------------------------------------------------------
def selftest() -> int:
    scratch = Path(tempfile.mkdtemp(prefix="rti-server-app-selftest-"))
    os.environ.update({
        "RTI_CONFIG_DIR": str(scratch / "config"), "RTI_DATA_DIR": str(scratch / "data"),
        "RTI_BACKUP_DIR": str(scratch / "backups"), "RTI_WEB_HOST": "127.0.0.1", "RTI_WEB_PORT": "5091",
        "RTI_MOBILE_PROXY_HOST": "127.0.0.1", "RTI_MOBILE_PROXY_PORT": "5291",
    })
    results: list[str] = []
    out_file = os.environ.get("RTI_SELFTEST_OUT", "").strip()

    def say(line: str) -> None:
        results.append(line)
        print(line, flush=True)
        if out_file:
            try:
                Path(out_file).write_text("\n".join(results) + "\n", encoding="utf-8")
            except OSError:
                pass

    def fetch(app, path, method="GET", body=None, token=None):
        request = urllib.request.Request(f"http://127.0.0.1:{app.control.port}{path}", method=method,
                                         data=json.dumps(body or {}).encode() if method == "POST" else None,
                                         headers={"X-RTI-Token": token if token is not None else app.token,
                                                  "Host": f"127.0.0.1:{app.control.port}",
                                                  "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                return response.status, response.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as error:
            return error.code, error.read().decode("utf-8", "replace")

    app = DesktopApp(background=True)
    common.start_logging(app.config_dir / "logs", "app")
    failures = 0

    def check(name: str, ok: bool, detail: str = "") -> None:
        nonlocal failures
        say(("PASS  " if ok else "FAIL  ") + name + (f" ({detail})" if detail and not ok else ""))
        failures += 0 if ok else 1

    try:
        app.start_services()
        check("server engine starts", app.supervisor.wait_until("running", 90), app.supervisor.snapshot()["message"])
        status, body = fetch(app, "/api/state")
        state = json.loads(body) if status == 200 else {}
        check("manager API answers", status == 200 and state.get("state") == "running", f"HTTP {status}")
        check("manager API rejects a wrong token", fetch(app, "/api/state", token="wrong")[0] == 403)
        status, page = fetch(app, f"/?t={app.token}")
        check("manager page is served", status == 200 and "AB Securitas RTI Server" in page, f"HTTP {status}")
        time.sleep(1)
        status, body = fetch(app, "/api/state")
        overview = json.loads(body).get("overview", {}) if status == 200 else {}
        check("activity figures are read from the database", overview.get("available") is True, str(overview)[:80])
        status, body = fetch(app, "/api/action/backup", "POST")
        check("backup now writes a verified copy", status == 200 and "Backup saved" in body, body[:120])
        status, body = fetch(app, "/api/action/restart", "POST")
        check("restart brings the server back", status == 200 and app.supervisor.wait_until("running", 90))
        status, body = fetch(app, "/api/action/stop", "POST")
        endpoints = app.endpoints()
        check("stop closes the server ports", status == 200 and not supervisor_module.probe(endpoints["web_port"], 1)
              and not supervisor_module.probe(endpoints["proxy_port"], 1))
        say(f"INFO  browser for app windows: {system.find_browser() or 'none found (default browser is used)'}")
        try:
            import pystray  # noqa: F401
            say("INFO  notification-area icon library: available")
        except Exception as error:
            say(f"INFO  notification-area icon library: missing ({error.__class__.__name__}); the app still works")
    except Exception as error:  # never leave the pipeline hanging
        check("self test ran to the end", False, f"{error.__class__.__name__}: {error}")
    finally:
        app.shutdown()
    say("SELFTEST OK" if failures == 0 else f"SELFTEST FAILED ({failures} check(s) failed)")
    return 0 if failures == 0 else 4


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="AB Securitas RTI Central Server")
    parser.add_argument("--background", action="store_true", help="start without opening a window")
    parser.add_argument("--engine", action="store_true", help="internal: run the server engine in this process")
    parser.add_argument("--selftest", action="store_true", help="start on temporary ports, check, exit")
    parser.add_argument("--version", action="store_true", help="print the version and exit")
    args = parser.parse_args(argv)

    if args.version:
        print(APP_VERSION)
        out_file = os.environ.get("RTI_SELFTEST_OUT", "").strip()  # the windowed exe has no console to print to
        if out_file:
            try:
                Path(out_file).write_text(APP_VERSION + "\n", encoding="utf-8")
            except OSError:
                pass
        return 0
    if args.engine:
        return launcher.main(["--no-browser"])
    if args.selftest:
        return selftest()

    app = DesktopApp(background=args.background)
    common.start_logging(app.config_dir / "logs", "app")
    return app.run()


if __name__ == "__main__":
    exit_code = main()
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.flush()
        except Exception:
            pass
    # Leave at once: a helper thread (notification-area icon) must never keep the finished program alive.
    os._exit(exit_code)
