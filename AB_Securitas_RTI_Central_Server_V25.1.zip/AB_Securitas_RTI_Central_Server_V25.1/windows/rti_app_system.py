"""Operating-system helpers for the desktop app: app-style browser window, Start-with-Windows, folders, tray icon.

Everything here is best effort: when something is not available (no Edge/Chrome, no tray library, not Windows) the
function reports it and the app carries on.
"""
from __future__ import annotations

import base64
import io
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

AUTOSTART_VALUE = "ABSecuritasRTIServer"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
WINDOW_TITLE = "AB Securitas RTI Server"


# ----- Edge / Chrome in "app" mode (a window without tabs or an address bar) ---------------------------------------
def find_browser() -> str | None:
    override = os.environ.get("RTI_BROWSER_PATH", "").strip()
    if override and Path(override).is_file():
        return override
    candidates: list[Path] = []
    if os.name == "nt":
        roots = [os.environ.get(name) for name in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData")]
        for root in filter(None, roots):
            base = Path(root)
            candidates += [base / "Microsoft" / "Edge" / "Application" / "msedge.exe",
                           base / "Google" / "Chrome" / "Application" / "chrome.exe"]
    else:
        for name in ("microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
            found = shutil.which(name)
            if found:
                candidates.append(Path(found))
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def app_window_command(browser: str, url: str, profile_dir: Path, size: tuple[int, int] = (1060, 780)) -> list[str]:
    return [browser, f"--app={url}", f"--user-data-dir={profile_dir}", f"--window-size={size[0]},{size[1]}",
            "--no-first-run", "--no-default-browser-check", "--disable-sync", "--disable-features=Translate,msEdgeSidebarV2",
            "--disable-extensions"]


def open_app_window(url: str, profile_dir: Path, size: tuple[int, int] = (1060, 780)):
    """Open `url` in its own application window. Returns the browser process, or None when the default browser was used."""
    browser = find_browser()
    if browser:
        try:
            profile_dir.mkdir(parents=True, exist_ok=True)
            return subprocess.Popen(app_window_command(browser, url, profile_dir, size),
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
    try:
        webbrowser.open(url, new=1)
    except webbrowser.Error:
        pass
    return None


def focus_window(title: str = WINDOW_TITLE) -> bool:
    """Bring an already open window to the front (Windows only)."""
    if os.name != "nt":
        return False
    try:
        import ctypes
        user32 = ctypes.windll.user32
        handle = user32.FindWindowW(None, title)
        if not handle:
            return False
        user32.ShowWindow(handle, 9)  # SW_RESTORE
        user32.SetForegroundWindow(handle)
        return True
    except Exception:
        return False


# ----- folders and files -------------------------------------------------------------------------------------------
def open_path(path: Path) -> bool:
    try:
        if os.name == "nt":
            os.startfile(str(path))  # noqa: S606  (a folder or file chosen by this app, never user text)
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except (OSError, AttributeError):
        return False


def open_in_editor(path: Path) -> bool:
    """Open a text settings file in Notepad (Windows) or the default editor."""
    try:
        if os.name == "nt":
            subprocess.Popen(["notepad.exe", str(path)])
            return True
    except OSError:
        return False
    return open_path(path)


# ----- Start with Windows ------------------------------------------------------------------------------------------
def autostart_supported() -> bool:
    return os.name == "nt" and getattr(sys, "frozen", False)


def autostart_command() -> str:
    return f'"{sys.executable}" --background'


def autostart_enabled() -> bool:
    if os.name != "nt":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            value, _ = winreg.QueryValueEx(key, AUTOSTART_VALUE)
        return bool(value)
    except OSError:
        return False


def set_autostart(enabled: bool) -> None:
    if not autostart_supported():
        raise RuntimeError("Start with Windows is available in the installed program only.")
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            winreg.SetValueEx(key, AUTOSTART_VALUE, 0, winreg.REG_SZ, autostart_command())
        else:
            try:
                winreg.DeleteValue(key, AUTOSTART_VALUE)
            except FileNotFoundError:
                pass


# ----- system tray -------------------------------------------------------------------------------------------------
class Tray:
    """Notification-area icon (needs the optional `pystray` package; silently unavailable without it)."""

    def __init__(self, icon_png: bytes, title: str, on_open, on_dashboard, on_restart, on_quit):
        self.available = False
        self._icon = None
        self._handlers = (on_open, on_dashboard, on_restart, on_quit)
        self._png = icon_png
        self._title = title

    def start(self) -> bool:
        if os.name != "nt" and not os.environ.get("RTI_FORCE_TRAY"):
            return False
        try:
            import pystray
            from PIL import Image
        except Exception:
            return False
        on_open, on_dashboard, on_restart, on_quit = self._handlers
        try:
            image = Image.open(io.BytesIO(self._png)).convert("RGBA")
            menu = pystray.Menu(
                pystray.MenuItem("Open server manager", lambda *_: on_open(), default=True),
                pystray.MenuItem("Open dashboard", lambda *_: on_dashboard()),
                pystray.MenuItem("Restart server", lambda *_: on_restart()),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Quit and stop the server", lambda *_: on_quit()),
            )
            self._icon = pystray.Icon("ab-securitas-rti-server", image, self._title, menu)
            self._icon.run_detached()
            self.available = True
        except Exception:
            self._icon = None
            self.available = False
        return self.available

    def stop(self) -> None:
        if self._icon is not None:
            try:
                self._icon.stop()
            except Exception:
                pass
            self._icon = None
        self.available = False

    def notify(self, message: str) -> None:
        if self._icon is not None:
            try:
                self._icon.notify(message, self._title)
            except Exception:
                pass


def decode_png(data_uri_or_b64: str) -> bytes:
    return base64.b64decode(data_uri_or_b64.split(",", 1)[-1])


def wait_for_process_exit(process, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process.poll() is not None:
            return True
        time.sleep(0.1)
    return process.poll() is not None


__all__ = ["find_browser", "app_window_command", "open_app_window", "focus_window", "open_path", "open_in_editor", "autostart_supported",
           "autostart_enabled", "set_autostart", "Tray", "decode_png", "WINDOW_TITLE"]
