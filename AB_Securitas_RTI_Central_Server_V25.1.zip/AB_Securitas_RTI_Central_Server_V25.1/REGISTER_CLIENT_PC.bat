@echo off
setlocal
cd /d "%~dp0"
if not exist Web\.venv\Scripts\python.exe (
  echo Run SERVER_SETUP.bat first.
  pause
  exit /b 1
)
Web\.venv\Scripts\python.exe scripts\register_client_pc.py
if errorlevel 1 (
  pause
  exit /b 1
)
echo.
pause
