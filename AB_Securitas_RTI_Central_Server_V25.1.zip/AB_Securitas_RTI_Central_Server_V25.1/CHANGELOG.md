# Changelog

## V25.1.0 - LAN + Online build

**Fixes**
- Offline sessions synced from phones / Client PCs are stored as `ENDED` (they stayed `ACTIVE` forever); old `OFF-*` sessions are closed once at start-up and hidden from the live mobile state.
- A new or edited schedule no longer reports a week of "MISSED" alerts for times before it existed.
- QR point update API: deleted point -> 404, bad/empty code -> 400, bad status -> 400, duplicate code -> 409 (was HTTP 500).
- Mobile/Client API calls no longer create a session cookie/CSRF session.
- Mobile proxy follows `RTI_WEB_PORT`, forwards `X-RTI-Client-ID`, reads the same env file as Central.

**New**
- Works on LAN **and** online: public `GET /api/mobile/health` (also through the proxy); proxy can bind to the LAN (`RTI_MOBILE_PROXY_HOST`); secure headers, optional `ProxyFix` (`RTI_TRUST_PROXY`) and secure cookies (`RTI_COOKIE_SECURE`) for reverse-proxy / online use.
- One-click Client PC onboarding: dashboard **Schedules & Client Access -> Pair a new Client PC** creates the company/node tokens, saves them to Central immediately (no restart) and downloads the pairing JSON.
- **Windows PC application** `rti-server.exe` (a normal windowed program, no console): **Server Manager window** (status + 10-minute health strip, LAN address for phones / Client PCs with Copy, activity figures, Client PCs seen / blocked, Start / Stop / Restart, *Back up now*, open data / backups / settings folders, log viewer), **notification-area icon** (server keeps running when the window is closed), the **dashboard in its own app window** (Edge / Chrome app mode), **Start the server when Windows starts**, one copy only (a second start brings the first window forward), automatic restart of the server engine if it ever stops, `--background`, `--selftest`, `--version`.
- Installer (Inno Setup): desktop icon, Private-network firewall rule, optional start at sign-in (the same switch the app has), stops a running copy before an update or uninstall.
- Quiet logs: successful 5-second health checks are no longer written to the server log.
- GitHub Actions: `build-windows-server.yml` (tests -> PyInstaller -> self-test of the packaged exe -> starts the packaged app, checks it and quits it -> installer + portable zip + checksums -> optional Release) and `build-web-docker.yml` (image build, smoke test, optional push to ghcr.io). Both find the project whether it is committed as files or as the uploaded ZIP.
- `deploy/docker` (Dockerfile, Compose, Caddy automatic HTTPS) for a cloud VM.
- Version 25.1.0.
