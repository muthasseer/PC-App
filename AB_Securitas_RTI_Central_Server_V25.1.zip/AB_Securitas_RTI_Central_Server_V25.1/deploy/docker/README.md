# Central Server online (Docker + automatic HTTPS)

Runs the Central dashboard and the allow-listed mobile API on any Linux server / cloud VM. Caddy fetches and renews the HTTPS certificate for your domain.

## One-time setup
1. Create a small Linux VM (Ubuntu 22.04+, 1 GB RAM is enough) and install Docker (`curl -fsSL https://get.docker.com | sh`).
2. Point a DNS **A record** (for example `rti.your-domain.com`) to the VM's public IP. Open inbound TCP **80** and **443** in the VM/cloud firewall.
3. Copy this project (or only `deploy/docker`, `Web`, `MobileApiProxy`, `windows/rti_common.py`, `windows/rti_server_launcher.py`) to the VM.
4. ```bash
   cd deploy/docker
   cp .env.example .env        # edit: RTI_DOMAIN=rti.your-domain.com
   docker compose up -d --build
   docker compose logs -f rti  # wait for "Dashboard (this PC) ..."
   ```
5. Open `https://rti.your-domain.com`, sign in as `admin` / `admin123` and change the password immediately.

Use `https://rti.your-domain.com` as the **Online address** in the Android app and as the *online* Central address when you pair Client PCs (dashboard → Schedules & Client Access → Pair a new Client PC).

## What runs
| Container | Role |
|---|---|
| `rti` | dashboard (`:5000`) + allow-listed mobile API proxy (`:5200`), data in volume `rti-data` (`/data`: database, daily backups, generated secrets, Client PC tokens) |
| `caddy` | HTTPS on 443. `/api/mobile/*` and `/api/client/*` → `rti:5200`, everything else → `rti:5000` |

## Operations
* Update: copy the new project over, `docker compose up -d --build` (data volume is kept).
* Backup: `docker run --rm -v ab-securitas-rti_rti-data:/data -v "$PWD":/out alpine tar czf /out/rti-data.tgz -C /data .`
* Logs: `docker compose logs --tail=200 rti caddy`
* Prebuilt image: the GitHub workflow *Build Central Server for online use (Docker image)* can push `ghcr.io/<owner>/ab-securitas-rti-central`; replace the `build:` block in `docker-compose.yml` by `image: ghcr.io/<owner>/ab-securitas-rti-central:latest` to use it.

## Security
In this setup the dashboard is reachable from the Internet, so keep strong Super Admin passwords.

To keep the dashboard private and expose only the device API: in `Caddyfile` replace the last block `handle { reverse_proxy rti:5000 }` with `handle { respond 404 }`; in `docker-compose.yml` add `ports: ["127.0.0.1:5000:5000"]` to the `rti` service and set `RTI_COOKIE_SECURE: "0"`; restart, then open the dashboard through an SSH tunnel: `ssh -L 5000:127.0.0.1:5000 <user>@<vm>` and browse `http://localhost:5000`.
