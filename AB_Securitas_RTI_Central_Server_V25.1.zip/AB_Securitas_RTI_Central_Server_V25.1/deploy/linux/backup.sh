#!/usr/bin/env bash
set -euo pipefail

DB_PATH="/var/lib/ab-securitas-rti/inspector.db"
DEFAULT_BACKUP_DIR="/var/lib/ab-securitas-rti/backups"
if [[ -n "${RTI_BACKUP_DIR:-}" ]]; then
  BACKUP_DIR="$RTI_BACKUP_DIR"
else
  BACKUP_DIR="$(python3 - "$DB_PATH" "$DEFAULT_BACKUP_DIR" <<'PY'
import sqlite3
import sys
try:
    connection = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True, timeout=10)
    row = connection.execute("SELECT setting_value FROM settings WHERE company_id=0 AND setting_key='backup_directory'").fetchone()
    print(row[0] if row and row[0].strip() else sys.argv[2])
except sqlite3.Error:
    print(sys.argv[2])
finally:
    try:
        connection.close()
    except UnboundLocalError:
        pass
PY
  )"
fi
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DEST="$BACKUP_DIR/rti-$STAMP.db"

if [[ ! -f "$DB_PATH" ]]; then
  echo "Database not found yet: $DB_PATH" >&2
  exit 1
fi

install -d -m 0700 "$BACKUP_DIR"
python3 - "$DB_PATH" "$DEST" <<'PY'
import os
import sqlite3
import sys
source = sqlite3.connect(sys.argv[1], timeout=30)
temporary = sys.argv[2] + ".tmp"
target = sqlite3.connect(temporary)
try:
    source.backup(target)
    if target.execute("PRAGMA quick_check").fetchone()[0] != "ok":
        raise sqlite3.DatabaseError("SQLite backup integrity check failed")
    target.commit()
finally:
    target.close()
    source.close()
os.replace(temporary, sys.argv[2])
PY
chmod 0600 "$DEST"
echo "Created SQLite backup: $DEST"
