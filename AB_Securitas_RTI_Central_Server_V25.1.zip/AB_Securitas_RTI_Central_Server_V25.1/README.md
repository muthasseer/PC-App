# AB Securitas RTI — Central Server V25.1
**Windows PC application (server manager window + notification-area icon) + Web application (admin dashboard + mobile API)** — works on the office **LAN** and over the **Internet**.

Ithu *Server PC-ku mattum*. Client PC-ku vera zip (`AB_Securitas_RTI_Client_PC_V25.1.zip`), Android app-ku vera zip (`AB_Securitas_RTI_Android_App_V25.1.zip`).

| Part | Where |
|---|---|
| Admin web dashboard (companies, inspectors, checkpoints, schedules, reports, history) | `Web/` — port **5000** |
| Allow-listed mobile API for phones and Client PCs | `MobileApiProxy/` — port **5200** |
| **Windows PC application** `rti-server.exe` (manager window, tray icon, runs the server) + setup installer | `windows/` — built by GitHub |
| Online hosting with automatic HTTPS (cloud VM) | `deploy/docker/`, `deploy/linux/` |
| GitHub build files | `.github/workflows/build-windows-server.yml`, `build-web-docker.yml` |

---

## 1. GitHub-la build panna (Windows installer)

1. github.com → **New repository** → *Private* → Create.
2. Repository-la **Add file → Upload files** → indha zip-ai **appadiyea** (or unzip panni ulla irukkura files) drag & drop → **Commit changes**.
3. Zip-ai appadiyea upload pannina, workflow file-ai thani-ya add pannanum: **Add file → Create new file** → name: `.github/workflows/build-windows-server.yml` → `build-windows-server.yml` file-oda full text-ai paste → **Commit changes**. (Files-ai unzip panni `.github` folder-oda upload panninaa, ithu thevai illa.)
4. **Actions** tab → **Build Windows Central Server (PC application + Web dashboard)** → **Run workflow**.
5. ~5–10 min. Mudinja run-ai thirandhu keela **Artifacts → `AB-Securitas-RTI-Server-Windows`** download:
   * `AB-Securitas-RTI-Server-Setup-<version>.exe` (installer)
   * `AB-Securitas-RTI-Server-Portable-<version>.zip` (install illama run)
   * `.sha256` checksums
6. Cloud VM-la web app online-ah vida: **Build Central Server for online use (Docker image)** workflow (`build-web-docker.yml`) — same maari add pannunga (section 5).

Edhavadhu step fail aana: failed step-ai click panni red error text-ai copy panni anuppunga.

## 2. Server PC-la install — PC application

1. `AB-Securitas-RTI-Server-Setup-<version>.exe` run pannunga (Windows SmartScreen "Unknown publisher" kaatinaa **More info → Run anyway**).
2. Options: *desktop shortcut*, **firewall rule (Private network mattum)** — phones/Client PCs LAN-la connect aaga idhu venum, *start automatically when I sign in*. Portable zip-ai install illama run pannina, Windows Firewall kekkum pothu **Private networks** allow pannunga.
3. **AB Securitas RTI Central Server** start pannunga. Oru normal Windows program mari **Server Manager window** thirakkum (black console window illa). Server thaane start aagum; `server.env` (secrets-oda) `%LOCALAPPDATA%\AB Securitas\Real Time Inspector\` folder-la create aagum.

**Manager window-la irukkiradhu**
* **Status** — *The server is running / starting / stopped / needs attention*, uptime, last 10 minutes health strip. Server nindru pona thaane restart aagum (error irundha reason kaattum).
* **Open dashboard** — admin dashboard-ai thani application window-la thirakkum (Edge / Chrome app mode; browser tab/address bar illa).
* **Connect phones and Client PCs** — `http://192.168.x.x:5200` pola **LAN address** (Copy button). Idhu dhaan Android app / Client PC-ku **Central LAN address**. Internet option-um kaattum.
* **Activity** — active companies, inspectors, phones, schedules, today's scans, **Client PCs** (last seen / blocked).
* **Server** — Stop / Start, Restart, **Back up now** (verified database copy), Open data folder, Open backups, Open settings file.
* **Settings** — *Start the server when Windows starts*; *Open the dashboard from other PCs on this network* (restart aagum).
* **Log** — server log / app log paarkka, Copy.

**Window-ai close panna?** Notification area (clock pakkam) icon irundha — **server odikittey irukkum**; icon-ai click = manager window. Icon right-click: *Open server manager, Open dashboard, Restart server, Quit and stop the server*. Icon support illaina (rare), window-ai close panna server-um nikkum — footer-la ezhuthi irukkum. **Quit and stop server** = muzhusa nikkum.

4. Dashboard: manager-la **Open dashboard** (`http://127.0.0.1:5000`) — first login **admin / admin123** → udane pudhu password kettum.
5. Vera PC-la irundhu dashboard thirakka: manager → Settings → *Open the dashboard from other PCs* (strong password munnadi vainga).
6. PC restart aana pinnaiyum server-um odanum-na: manager → **Start the server when Windows starts** tick (or installer-la tick pannirukkalaam). Idhu *indha Windows user-ku*; background-la start aagum, window thirakkaadhu.
7. Data (database, backups, logs) `%LOCALAPPDATA%\AB Securitas\Real Time Inspector\` — install folder-ku veliya, update/uninstall panna azhiyaadhu. Super Admin dashboard-la backup folder select panni daily backups edukkalaam.
8. Manager window-ku **Microsoft Edge** (Windows-la already irukkum) or **Google Chrome** venum. Rendum illaina default browser-la thirakkum — server-ku vera paathippu illa.

## 3. Client PC-ai pair panna (command line illa)
1. Client PC-la Client PC app install pannunga (vera zip) → setup page-la **Client PC ID** theriyum.
2. Dashboard → **Schedules & Client Access → Pair a new Client PC**: Company select, Client PC ID, **Online address** (https://…) and/or **LAN address** (`http://192.168.x.x:5200`) → button. Private `Company-<id>_<ClientID>.json` download aagum; tokens Central-la thaanaa save aagum, **restart thevai illa**.
3. JSON-ai Client PC-ku private-ah kudungal; Client PC setup page-la **Import pairing file**. Import aana pin JSON-ai delete pannunga.

## 4. Android phones
Android app → ⚙ Settings → **Central LAN address** = step 2.4 address, **Online address** = step 5 address. LAN mudhalla, kidaikkalana online — automatic.

## 5. Online (Internet) — oru option select pannunga
**A. Cloud VM + Docker + automatic HTTPS (recommended — office PC off-la irundhaalum work aagum)**
```bash
cd deploy/docker
cp .env.example .env          # RTI_DOMAIN=rti.your-domain.com
docker compose up -d --build
```
Domain DNS A record → VM IP; ports 80/443 open. Details: `deploy/docker/README.md`. Online address = `https://rti.your-domain.com`.

**B. Tailscale Funnel (server PC-la irundhu)**: Tailscale install + sign in + Funnel enable → `tailscale funnel --https=443 --bg http://127.0.0.1:5200` (legacy `START_SERVER.bat` idhaiyum seyyum). Dashboard private-ah thaan irukkum.

**C. Linux VM (systemd)**: `deploy/linux/install.sh`.

Reverse proxy / HTTPS-oda use pannum pothu `RTI_TRUST_PROXY=1`, `RTI_COOKIE_SECURE=1` (Docker setup-la already set).

## 6. Source-lendhu run (developers)
```bash
python -m pip install -r Web/requirements.txt waitress
python windows/rti_server_app.py                 # the PC application (manager window + server)
python windows/rti_server_app.py --background    # server only, no window
python windows/rti_server_app.py --selftest      # starts on temporary ports, checks, prints SELFTEST OK
python windows/rti_server_launcher.py            # console-only server (no window)
python -m unittest discover -s tests
```
Legacy Windows scripts (Python auto-install): `SERVER_SETUP.bat`, `START_SERVER.bat`, `STOP_SERVER.bat`, `REGISTER_CLIENT_PC.bat` — still work.

## 7. Security
* Default `admin` password-ai udane maatrunga; Super Admin-ku strong password.
* `server.env`, `*.db`, pairing JSON, keystore — GitHub-la **commit pannaadhinga** (`.gitignore` already thaduppum). Repository *Private*.
* Plain `http://` LAN private addresses-ku mattum; Internet address `https://` mattum.
* Dashboard-ai (5000) Internet-la HTTPS illama expose pannaadhinga.

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| Phone LAN test fail | Same Wi-Fi? Server install-la *firewall rule* tick pannina? Illaina Windows Firewall-la TCP 5200 (Private) allow. |
| Manager says *needs attention* / *Port 5000 is already in use* | Innoru program/copy andha port-ai use pannuthu. **Quit** pannitu innoru copy close pannunga, illaina manager → *Open settings file* → port maathi Restart. |
| Manager window varala | Notification area-la icon paarunga (hidden icons ^). Illaina Start menu → *AB Securitas RTI Central Server*. |
| Server odala (PC restart-ku pinnaal) | Manager → *Start the server when Windows starts* tick. |
| Log paarkka | Manager → **Log**. File: `%LOCALAPPDATA%\AB Securitas\Real Time Inspector\logs\server.log` / `app.log`. |
| Client PC 401 | Pairing file thirumba create panni import. |
| Online address open aagala | DNS → VM IP, 80/443 open, `docker compose logs caddy rti`. |

Version history: `CHANGELOG.md`.
