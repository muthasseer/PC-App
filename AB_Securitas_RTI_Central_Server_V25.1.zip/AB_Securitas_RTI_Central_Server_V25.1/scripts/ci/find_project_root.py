"""Locate the AB Securitas project root inside a GitHub Actions workspace.

Handles both layouts people use on GitHub:
  1. the project files committed directly (Android/, Web/, ClientPC/, ... at the repository root or in one sub-folder);
  2. a source ZIP committed to the repository (the newest ZIP that contains the project is extracted).

Usage: python find_project_root.py <marker-file> [<marker-file> ...]
Prints the project root (POSIX style) and, when running in Actions, writes `root=<path>` to $GITHUB_OUTPUT.

NOTE: the same logic is embedded inline in the workflows (a workflow must be able to run before any other file
of the repository is available, e.g. when only a ZIP was uploaded). Keep both copies in sync.
"""
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

SKIP_DIRS = {".git", ".gradle", ".venv", "build", "node_modules", "__pycache__"}


def find_roots(base, markers):
    for current, dirs, files in os.walk(base):
        dirs[:] = [name for name in dirs if name not in SKIP_DIRS]
        root = Path(current)
        if all((root / marker).is_file() for marker in markers):
            yield root.resolve()
            dirs[:] = []  # do not descend into a project we already found


def version_key(path):
    numbers = [int(value) for value in re.findall(r"\d+", path.name)]
    return (numbers, path.name.lower())


def extract_safely(archive, destination):
    for info in archive.infolist():
        member = PurePosixPath(info.filename.replace("\\", "/"))
        if member.is_absolute() or ".." in member.parts:
            raise ValueError(f"Unsafe ZIP member path: {info.filename}")
        target = (destination / Path(*member.parts)).resolve()
        if destination != target and destination not in target.parents:
            raise ValueError(f"Unsafe ZIP member path: {info.filename}")
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def main(markers):
    workspace = Path(os.environ.get("GITHUB_WORKSPACE", ".")).resolve()
    root = next(find_roots(workspace, markers), None)
    if root is None:
        archives = sorted((p for p in workspace.rglob("*.zip") if ".git" not in p.parts), key=version_key, reverse=True)
        for archive_path in archives:
            try:
                with zipfile.ZipFile(archive_path) as archive:
                    names = {name.replace("\\", "/") for name in archive.namelist()}
                    if not any(name.endswith(markers[0]) for name in names):
                        continue
                    destination = Path(tempfile.mkdtemp(prefix="ab-securitas-source-", dir=workspace)).resolve()
                    extract_safely(archive, destination)
                root = next(find_roots(destination, markers), None)
                if root is not None:
                    print(f"Project files extracted from {archive_path}", file=sys.stderr)
                    break
            except (OSError, zipfile.BadZipFile, ValueError) as error:
                print(f"Skipping {archive_path}: {error}", file=sys.stderr)
    if root is None:
        print("Could not find the AB Securitas project files (looked for: " + ", ".join(markers) + ").", file=sys.stderr)
        print("Commit the unzipped project to the repository root, or commit the complete project ZIP, then run again.", file=sys.stderr)
        return 1
    value = root.as_posix()
    if os.environ.get("GITHUB_OUTPUT"):
        with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as output:
            output.write(f"root={value}\n")
    print(value)
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(main(sys.argv[1:]))
