$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$pythonPath = Join-Path $projectRoot 'Web\.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw 'Central Python environment is missing. Run SERVER_SETUP.bat first.'
}

$services = @(
    @{ Port = 5000; Script = (Join-Path $projectRoot 'Web\app.py') },
    @{ Port = 5200; Script = (Join-Path $projectRoot 'MobileApiProxy\proxy.py') }
)
foreach ($service in $services) {
    $scriptPath = $service.Script
    $leaf = [System.IO.Path]::GetFileName($scriptPath)
    $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $service.Port -ErrorAction SilentlyContinue)
    if ($listeners.Count -gt 0) {
        foreach ($listener in ($listeners | Sort-Object OwningProcess -Unique)) {
            $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)"
            $isExpected = $process -and $process.ExecutablePath -and $process.CommandLine -and
                $process.ExecutablePath.Equals($pythonPath, [StringComparison]::OrdinalIgnoreCase) -and
                $process.CommandLine.IndexOf($scriptPath, [StringComparison]::OrdinalIgnoreCase) -ge 0
            if (-not $isExpected) {
                throw "Port $($service.Port) is already used by another program. Stop that program before starting RTI Server."
            }
        }
        Write-Host "RTI service is already listening on port $($service.Port)." -ForegroundColor Green
    } else {
        Write-Host "Starting $leaf on port $($service.Port)..." -ForegroundColor Cyan
        Start-Process -FilePath $pythonPath -ArgumentList ('"{0}"' -f $scriptPath) -WorkingDirectory (Split-Path -Parent $scriptPath) -PassThru | Out-Null
    }
}

$deadline = (Get-Date).AddSeconds(20)
foreach ($service in $services) {
    do {
        Start-Sleep -Milliseconds 500
        $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $service.Port -ErrorAction SilentlyContinue)
    } while ($listeners.Count -eq 0 -and (Get-Date) -lt $deadline)
    if ($listeners.Count -eq 0) {
        throw "RTI service did not open port $($service.Port). Check the Python window for its startup error."
    }
}
Write-Host 'Central Web and the mobile API proxy are ready.' -ForegroundColor Green
