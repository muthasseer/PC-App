"""Register a Client PC on Central and create a private onboarding file."""

from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import re
import secrets
import shutil
import sys
from urllib.parse import urlsplit


ROOT = Path(__file__).resolve().parent.parent
WEB_ENV = ROOT / "Web" / ".env"
PAIRING_DIR = ROOT / "private-client-pairings"
SYNC_PLACEHOLDER = "CHANGE-TO-A-LONG-RANDOM-SYNC-TOKEN"
NODE_PLACEHOLDER = "CHANGE-TO-A-LONG-RANDOM-NODE-TOKEN"
FORMAT = "rti-client-pairing-v1"
ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}")
DEFAULT_CENTRAL_URL = "https://lkabsatml005.tail6bfc97.ts.net"


PRIVATE_NAME_SUFFIXES = (".local", ".lan", ".home", ".internal", ".home.arpa", ".localdomain")


def valid_origin(value: str, allow_private_http: bool = True) -> bool:
    """https works for any host (Tailscale Funnel, own domain, cloud VM); plain http only for private/LAN hosts."""
    try:
        parsed = urlsplit(value)
        host = (parsed.hostname or "").lower()
        parsed.port  # raises ValueError for an invalid port
        if (not host or parsed.username or parsed.password or parsed.path not in ("", "/")
                or parsed.query or parsed.fragment):
            return False
        if parsed.scheme == "https":
            return True
        if parsed.scheme == "http" and allow_private_http:
            try:
                address = ipaddress.ip_address(host)
                return bool(address.is_private or address.is_loopback or address.is_link_local)
            except ValueError:
                return "." not in host or host.endswith(PRIVATE_NAME_SUFFIXES)
        return False
    except ValueError:
        return False


def read_env(path: Path):
    lines = path.read_text(encoding="utf-8").splitlines()
    values = {}
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key, value = stripped.split("=", 1)
            values[key.strip()] = value.strip()
    return lines, values


def set_value(lines, key: str, value: str):
    prefix = key + "="
    for index, line in enumerate(lines):
        if line.strip().startswith(prefix):
            lines[index] = prefix + value
            return
    lines.append(prefix + value)


def parse_map(raw: str):
    result = {}
    for entry in raw.split(";"):
        key, separator, value = entry.partition(":")
        if separator and key.strip() and value.strip():
            result[key.strip()] = value.strip()
    return result


def main() -> int:
    if not WEB_ENV.is_file():
        print("Web/.env is missing. Run SERVER_SETUP.bat first.", file=sys.stderr)
        return 1
    try:
        lines, values = read_env(WEB_ENV)
        company_id = input("Numeric Company ID from Central Company Directory: ").strip()
        client_id = input("Client PC ID shown by CLIENT_PC_SETUP.bat: ").strip()
        default_url = values.get("RTI_CENTRAL_FUNNEL_URL", "").strip().rstrip("/")
        if not default_url or default_url.lower() == "https://your-device.tailnet.ts.net":
            default_url = DEFAULT_CENTRAL_URL
        central_url = input(f"Central HTTPS Funnel origin [{default_url}]: ").strip().rstrip("/") or default_url
        if not company_id.isdigit():
            raise ValueError("Company ID must be numeric. Do not enter the company code.")
        if not ID_PATTERN.fullmatch(client_id):
            raise ValueError("Client PC ID may contain letters, numbers, dot, underscore, and hyphen only.")
        if not valid_origin(central_url):
            raise ValueError("Enter the Central online origin, such as https://server.tailnet.ts.net or https://rti.your-domain.com (no path, query, or fragment).")
        try:
            lan_url = input("Central LAN address on the same network, optional, e.g. http://192.168.1.10:5200 [skip]: ").strip().rstrip("/")
        except EOFError:
            lan_url = ""
        if lan_url and not valid_origin(lan_url):
            raise ValueError("The Central LAN address must be a private network address such as http://192.168.1.10:5200.")

        sync_map = parse_map(values.get("RTI_CLIENT_SYNC_TOKENS", ""))
        sync_token = sync_map.get(company_id, "")
        if not sync_token or sync_token == SYNC_PLACEHOLDER:
            sync_token = secrets.token_urlsafe(48)
            sync_map[company_id] = sync_token
        node_map = parse_map(values.get("RTI_CLIENT_NODE_TOKENS", ""))
        node_key = f"{company_id}/{client_id}"
        node_token = node_map.get(node_key, "")
        if not node_token or node_token == NODE_PLACEHOLDER:
            node_token = secrets.token_urlsafe(48)
            node_map[node_key] = node_token

        set_value(lines, "RTI_CLIENT_SYNC_TOKENS", ";".join(f"{key}:{sync_map[key]}" for key in sorted(sync_map, key=lambda item: (not item.isdigit(), int(item) if item.isdigit() else item))))
        set_value(lines, "RTI_CLIENT_NODE_TOKENS", ";".join(f"{key}:{node_map[key]}" for key in sorted(node_map)))
        set_value(lines, "RTI_CENTRAL_FUNNEL_URL", central_url)
        PAIRING_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        backup_dir = ROOT / "private-config-backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(WEB_ENV, backup_dir / f"Web.env.before-pairing.{stamp}.bak")
        temporary_env = WEB_ENV.with_name(".env.tmp")
        temporary_env.write_text("\n".join(lines) + "\n", encoding="utf-8")
        temporary_env.replace(WEB_ENV)

        safe_id = re.sub(r"[^A-Za-z0-9._-]", "_", client_id)
        pairing_path = PAIRING_DIR / f"Company-{company_id}_{safe_id}.json"
        pairing_data = {
            "format": FORMAT,
            "central_url": central_url,
            "central_lan_url": lan_url,
            "company_id": company_id,
            "client_id": client_id,
            "client_sync_token": sync_token,
            "client_node_token": node_token,
        }
        temporary_pairing = pairing_path.with_suffix(".json.tmp")
        temporary_pairing.write_text(json.dumps(pairing_data, indent=2) + "\n", encoding="utf-8")
        temporary_pairing.replace(pairing_path)
    except (OSError, ValueError) as exc:
        print(f"Client PC registration failed: {exc}", file=sys.stderr)
        return 1

    print(f"Registered Company {company_id}, Client PC {client_id} in Central configuration.")
    print(f"Private onboarding file created: {pairing_path}")
    print("Keep that file private and transfer it only to the intended Client PC.")
    print("Restart the Central server, then import the pairing file on the Client PC.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
