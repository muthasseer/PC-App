$ErrorActionPreference = 'SilentlyContinue'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$targets = @{
    5000 = (Join-Path $projectRoot 'Web\app.py')
    5200 = (Join-Path $projectRoot 'MobileApiProxy\proxy.py')
}

foreach ($port in $targets.Keys) {
    $expectedScript = $targets[$port]
    $expectedPython = (Join-Path $projectRoot 'Web\.venv\Scripts\python.exe')
    $expectedLeaf = [System.IO.Path]::GetFileName($expectedScript)
    $connections = @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
    foreach ($processId in ($connections | Select-Object -ExpandProperty OwningProcess -Unique)) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$processId"
        if ($process -and $process.ExecutablePath -and $process.CommandLine -and
            $process.ExecutablePath.Equals($expectedPython, [StringComparison]::OrdinalIgnoreCase) -and
            $process.CommandLine.IndexOf($expectedLeaf, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
            Write-Host "Stopped this RTI service on port $port." -ForegroundColor Green
        }
    }
}

$tailscale = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
if (Test-Path -LiteralPath $tailscale) {
    & $tailscale funnel --https=443 http://127.0.0.1:5200 off | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host 'Stopped the RTI mobile API Funnel.' -ForegroundColor Green
    } else {
        Write-Host 'Tailscale Funnel could not be stopped; confirm this PC is signed in to Tailscale.' -ForegroundColor Yellow
    }
}
Write-Host 'RTI Central Server stop routine finished.'
