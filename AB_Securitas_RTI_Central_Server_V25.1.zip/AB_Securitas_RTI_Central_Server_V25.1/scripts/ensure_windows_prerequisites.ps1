param(
    [switch]$PythonOnly,
    [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Test-PythonCommand {
    param(
        [string]$CommandPath,
        [string[]]$PrefixArguments
    )

    if (-not (Test-Path -LiteralPath $CommandPath)) { return $false }
    try {
        $probe = @(& $CommandPath @PrefixArguments -c 'import struct,sys; print(str(sys.version_info.major)+chr(46)+str(sys.version_info.minor)+chr(46)+str(sys.version_info.micro),struct.calcsize(chr(80))*8,sys.executable,sep=chr(124))' 2>$null)
        if ($LASTEXITCODE -ne 0 -or $probe.Count -eq 0) { return $false }
        $parts = ([string]$probe[-1]).Trim().Split('|')
        if ($parts.Count -lt 3) { return $false }
        $version = [version]$parts[0]
        if ($version -ge [version]'3.11' -and $parts[1] -eq '64' -and (Test-Path -LiteralPath $parts[2])) {
            return $parts[2]
        }
        return $null
    } catch {
        return $false
    }
}

function Get-UsablePython {
    $launcherCandidates = @()
    $launcher = Get-Command py.exe -CommandType Application -ErrorAction SilentlyContinue
    if ($launcher) { $launcherCandidates += $launcher.Source }
    $launcherCandidates += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Launcher\py.exe')
    $launcherCandidates += (Join-Path $env:WINDIR 'py.exe')
    foreach ($candidate in ($launcherCandidates | Select-Object -Unique)) {
        $usable = Test-PythonCommand -CommandPath $candidate -PrefixArguments @('-3')
        if ($usable) { return $usable }
    }

    $pythonCandidates = @()
    $python = Get-Command python.exe -CommandType Application -ErrorAction SilentlyContinue
    if ($python) { $pythonCandidates += $python.Source }
    $pythonCandidates += (Join-Path $env:LOCALAPPDATA 'Python\bin\python.exe')
    $pythonCandidates += (Join-Path $env:LOCALAPPDATA 'Python\bin\python3.exe')
    $pythonCandidates += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe')
    $pythonRoots = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
        (Join-Path $env:ProgramFiles 'Python'),
        (Join-Path $env:LOCALAPPDATA 'Python')
    )
    foreach ($root in $pythonRoots) {
        if (Test-Path -LiteralPath $root) {
            $pythonCandidates += Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                ForEach-Object { Join-Path $_.FullName 'python.exe' }
        }
    }
    foreach ($candidate in ($pythonCandidates | Select-Object -Unique)) {
        $usable = Test-PythonCommand -CommandPath $candidate -PrefixArguments @()
        if ($usable) { return $usable }
    }
    return $null
}

function Assert-ValidPublisher {
    param(
        [string]$Path,
        [string]$PublisherPattern
    )

    $signature = Get-AuthenticodeSignature -LiteralPath $Path
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch $PublisherPattern) {
        throw "Downloaded installer signature check failed. The file was not run: $Path"
    }
}

function Install-Python {
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'This installer supports 64-bit Windows only. Install Python 3.11+ manually on this PC.'
    }

    Write-Host 'Python 3.11+ x64 was not found. Looking for the latest stable Python 3.13 installer on python.org...' -ForegroundColor Yellow
    $listing = Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/' -UseBasicParsing -TimeoutSec 30
    $versions = @(
        [regex]::Matches([string]$listing.Content, 'href=["''](?<version>3\.13\.\d+)/["'']') |
        ForEach-Object { [version]$_.Groups['version'].Value } |
        Sort-Object -Descending -Unique
    )
    if ($versions.Count -eq 0) { throw 'Could not find a stable Python 3.13 release on python.org.' }

    $versionText = $versions[0].ToString()
    $installerName = "python-$versionText-amd64.exe"
    $installerUrl = "https://www.python.org/ftp/python/$versionText/$installerName"
    $installerPath = Join-Path $env:TEMP $installerName
    try {
        Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing -TimeoutSec 180
        Assert-ValidPublisher -Path $installerPath -PublisherPattern 'Python Software Foundation'
        Write-Host "Installing Python $versionText for this Windows account..." -ForegroundColor Cyan
        $arguments = @('/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=1', 'Include_pip=1', 'Include_test=0', 'Include_doc=0', 'Shortcuts=0')
        $process = Start-Process -FilePath $installerPath -ArgumentList $arguments -Wait -PassThru
        if ($process.ExitCode -ne 0) { throw "Python installer exited with code $($process.ExitCode)." }
    } finally {
        Remove-Item -LiteralPath $installerPath -Force -ErrorAction SilentlyContinue
    }

    $usable = Get-UsablePython
    if (-not $usable) { throw 'Python installation finished, but a working 64-bit Python 3.11+ could not be detected. Restart this setup and try again.' }
    Write-Host "Python is ready: $usable" -ForegroundColor Green
    return $usable
}

function Get-TailscaleExecutable {
    $command = Get-Command tailscale.exe -CommandType Application -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $knownPath = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (Test-Path -LiteralPath $knownPath) { return $knownPath }
    return $null
}

function Install-Tailscale {
    $architecture = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
    Write-Host 'Tailscale was not found. Downloading its current stable Windows installer...' -ForegroundColor Yellow
    $index = Invoke-WebRequest -Uri 'https://dl.tailscale.com/stable/' -UseBasicParsing -TimeoutSec 30
    $pattern = 'href=["''](?<file>tailscale-setup-(?<version>\d+(?:\.\d+)+)-' + $architecture + '\.msi)["'']'
    $matches = @([regex]::Matches([string]$index.Content, $pattern))
    if ($matches.Count -eq 0) { throw "Could not find the stable Tailscale $architecture installer." }
    $latest = $matches | Sort-Object { [version]$_.Groups['version'].Value } -Descending | Select-Object -First 1
    $fileName = $latest.Groups['file'].Value
    $downloadUrl = 'https://dl.tailscale.com/stable/' + $fileName
    $installerPath = Join-Path $env:TEMP $fileName
    $hashPath = $installerPath + '.sha256'
    try {
        Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath -UseBasicParsing -TimeoutSec 180
        Invoke-WebRequest -Uri ($downloadUrl + '.sha256') -OutFile $hashPath -UseBasicParsing -TimeoutSec 30
        $expectedHash = [regex]::Match((Get-Content -LiteralPath $hashPath -Raw), '[A-Fa-f0-9]{64}').Value.ToLowerInvariant()
        if (-not $expectedHash) { throw 'Tailscale checksum could not be read; installer will not run.' }
        $actualHash = (Get-FileHash -LiteralPath $installerPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $expectedHash) { throw 'Tailscale installer checksum verification failed; installer will not run.' }
        Assert-ValidPublisher -Path $installerPath -PublisherPattern 'Tailscale'
        Write-Host 'Installing Tailscale. Windows may ask you to approve the administrator prompt...' -ForegroundColor Cyan
        $msiexec = Join-Path $env:WINDIR 'System32\msiexec.exe'
        $arguments = '/i "{0}" /qn /norestart' -f $installerPath
        $process = Start-Process -FilePath $msiexec -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        if ($process.ExitCode -notin @(0, 1641, 3010)) { throw "Tailscale installer exited with code $($process.ExitCode)." }
    } finally {
        Remove-Item -LiteralPath $installerPath, $hashPath -Force -ErrorAction SilentlyContinue
    }

    $tailscale = Get-TailscaleExecutable
    if (-not $tailscale) { throw 'Tailscale installation could not be detected after setup. Restart Windows and run INSTALL_SETUP.bat again.' }
    Write-Host "Tailscale is ready: $tailscale" -ForegroundColor Green
    Write-Host 'Sign in to your Tailscale account and approve Funnel once before starting the services.' -ForegroundColor Yellow
}

try {
    $python = Get-UsablePython
    if ($CheckOnly) {
        if (-not $python) { throw 'No supported Python was found; check-only mode will not install software.' }
        Write-Host "Python check passed: $python" -ForegroundColor Green
        $pythonFile = Join-Path (Split-Path -Parent $PSScriptRoot) '.rti-python-executable'
        [System.IO.File]::WriteAllText($pythonFile, [string]$python, [System.Text.Encoding]::Default)
        exit 0
    }
    if ($python) {
        Write-Host "Python 3.11+ x64 is already installed: $python" -ForegroundColor Green
    } else {
        $python = Install-Python
    }

    if (-not $PythonOnly) {
        $tailscale = Get-TailscaleExecutable
        if ($tailscale) {
            Write-Host "Tailscale is already installed: $tailscale" -ForegroundColor Green
        } else {
            Install-Tailscale
        }
    }

    $pythonFile = Join-Path (Split-Path -Parent $PSScriptRoot) '.rti-python-executable'
    [System.IO.File]::WriteAllText($pythonFile, [string]$python, [System.Text.Encoding]::Default)

    exit 0
} catch {
    Write-Host ''
    Write-Host "Prerequisite setup failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
