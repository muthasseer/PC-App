@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ==========================================
echo AB SECURITAS RTI - CENTRAL SERVER SETUP
echo ==========================================
echo Python, Tailscale and server libraries will be checked.
echo Missing installers are downloaded from official publishers and verified.
echo Tailscale may ask for Windows administrator approval.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "scripts\ensure_windows_prerequisites.ps1"
if errorlevel 1 goto :failed
if not exist .rti-python-executable goto :failed
for /f "usebackq delims=" %%P in (".rti-python-executable") do set "RTI_PYTHON=%%P"
if not exist "!RTI_PYTHON!" goto :failed
"!RTI_PYTHON!" -c "import struct,sys; assert sys.version_info >= (3,11) and struct.calcsize('P') == 8" >nul 2>nul
if errorlevel 1 goto :failed

if not exist Web\.env copy Web\.env.example Web\.env >nul
if not exist Web\.venv\Scripts\python.exe "!RTI_PYTHON!" -m venv Web\.venv
if errorlevel 1 goto :failed
Web\.venv\Scripts\python.exe -m pip install --disable-pip-version-check -r Web\requirements.txt
if errorlevel 1 goto :failed
Web\.venv\Scripts\python.exe -c "import flask, dotenv, qrcode, PIL" >nul 2>nul
if errorlevel 1 goto :failed

findstr /c:"RTI_SECRET_KEY=CHANGE-TO-A-LONG-RANDOM-SECRET" Web\.env >nul
if not errorlevel 1 (
  for /f "delims=" %%G in ('Web\.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(48))"') do set "RTI_NEW_SECRET=%%G"
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$p='Web\.env'; $s=[System.IO.File]::ReadAllText($p); $s=$s.Replace('RTI_SECRET_KEY=CHANGE-TO-A-LONG-RANDOM-SECRET', 'RTI_SECRET_KEY=!RTI_NEW_SECRET!'); [System.IO.File]::WriteAllText($p,$s,[System.Text.Encoding]::ASCII)"
  if errorlevel 1 goto :failed
  echo A strong Central session secret was generated locally.
)

echo.
echo Central Server setup completed. Python, Tailscale and Flask libraries are ready.
echo Sign in to the Central owner's Tailscale account on this PC before START_SERVER.bat.
echo Run REGISTER_CLIENT_PC.bat to provision a private connection file for each Client PC.
if not defined RTI_SETUP_NO_PAUSE pause
exit /b 0

:failed
echo.
echo Central Server setup failed. Read the error above and run SERVER_SETUP.bat again.
if not defined RTI_SETUP_NO_PAUSE pause
exit /b 1
